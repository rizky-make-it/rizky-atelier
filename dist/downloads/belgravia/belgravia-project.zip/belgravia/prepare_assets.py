"""Package original native renders, 22 models, room references and rebuild."""
from pathlib import Path
import sys,json,shutil,hashlib,struct,zipfile
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'.local/catalogue-review/packages'))
import pymupdf as fitz
DIST=ROOT/'sites/rizky-atelier/dist';ASSET=DIST/'assets/collections/belgravia';DOWN=DIST/'downloads/belgravia'
ASSET.mkdir(parents=True,exist_ok=True);DOWN.mkdir(parents=True,exist_ok=True)
source=json.loads((BASE/'reference/products.json').read_text(encoding='utf8'));scene=json.loads((BASE/'scene.json').read_text());proof={};copies=[]
render_run=json.loads((BASE/'render-run-audit.json').read_text());assert render_run['ok'] and not render_run['shadowErrors'] and len(render_run['completed'])==11
export_run=json.loads((BASE/'export-run-audit.json').read_text());assert export_run['ok'] and not export_run['issues']
models=json.loads((ASSET/'products.json').read_text(encoding='utf8'))
for p in models:p['referenceNote']=next(x for x in source['products'] if x['sku']==p['sku']).get('reference_note','')
(ASSET/'products.json').write_text(json.dumps(models,indent=2),encoding='utf8')
def record(dst):
    raw=dst.read_bytes();copies.append({'destination':dst.relative_to(DIST).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);record(dst)
names=('living','living-wide','dining','dining-pedestal','bedroom','vanity','office','office-wide','detail-burl','detail-upholstery','detail-tufting')
for name in names:
    filename=name+('.png' if name.startswith('detail') else '-4k.png');src=BASE/'renders'/filename;raw=src.read_bytes();w,h=struct.unpack('>II',raw[16:24])
    assert (w,h)==((1600,1600) if name.startswith('detail') else (3840,2160))
    settings=json.loads((BASE/'renders'/(name+'-settings.json')).read_text())
    assert settings['originalBlenderRender'] and settings['walls'] and settings['roof']
    copy(src,DOWN/filename);pix=fitz.Pixmap(str(src))
    if w>1920:pix=fitz.Pixmap(pix,1920,round(h*1920/w))
    pix.save(str(ASSET/(name+'.jpg')),jpg_quality=94)
    proof[name]={'file':filename,'width':w,'height':h,'sha256':hashlib.sha256(raw).hexdigest(),'engine':settings['engine'],'nativeScene':'belgravia-interior.blend','originalBlenderRender':True,'walls':True,'roof':True}
for p in source['products']:
    src=BASE/'reference/catalogue'/(p['sku']+'.jpg');assert hashlib.sha256(src.read_bytes()).hexdigest()==p['image']['sha256'];copy(src,ASSET/'catalogue'/src.name)
for key in ('living','dining','bedroom','office'):copy(BASE/'reference'/('room-'+key+'.jpg'),ASSET/('original-room-'+key+'.jpg'))
copy(BASE/'belgravia-interior.blend',DOWN/'belgravia-interior.blend');copy(BASE/'native-audit.json',DOWN/'native-audit.json');copy(BASE/'render-run-audit.json',DOWN/'render-run-audit.json');copy(BASE/'export-run-audit.json',DOWN/'export-run-audit.json');copy(BASE/'reference/products.json',ASSET/'source-reference.json')
(DOWN/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8');record(DOWN/'render-proof.json')
doc=fitz.open(source['source_pdf']);subset=fitz.open()
for page in source['source_pdf_pages']:subset.insert_pdf(doc,from_page=page-1,to_page=page-1)
subset.save(str(DOWN/'BELGRAVIA-reference-pages.pdf'),garbage=4,deflate=True);subset.close();doc.close();record(DOWN/'BELGRAVIA-reference-pages.pdf')
sources=('core.py','geometry.py','sofas.py','casegoods.py','build_scene.py','export_web.py','render_scene.py','validate_native.py','prepare_assets.py','scene.json','build-report.json','export-report.json','native-audit.json','README.md','sofas_audit.py','sofas-audit.json','casegoods_audit.py','casegoods-audit.json')
with zipfile.ZipFile(DOWN/'belgravia-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for filename in sources:z.write(BASE/filename,'belgravia/'+filename)
    for folder in ('textures','reference'):
        for p in (BASE/folder).rglob('*'):
            if p.is_file():z.write(p,'belgravia/'+p.relative_to(BASE).as_posix())
    for filename in ('scripts/read_catalogue.py','scripts/render_verified.mjs','scripts/export_verified.mjs','render-run-audit.json','export-run-audit.json','sofas-preview.png','casegoods-contactsheet.png','belgravia-interior.blend'):z.write(BASE/filename,'belgravia/'+filename)
    z.write(DOWN/'BELGRAVIA-reference-pages.pdf','belgravia/BELGRAVIA-reference-pages.pdf')
with zipfile.ZipFile(DOWN/'belgravia-project.zip') as z:assert z.testzip() is None
record(DOWN/'belgravia-project.zip')
for p in DOWN.iterdir():assert p.stat().st_size<95*1024*1024,('GitHub file too large',p)
prefix='assets/collections/belgravia';url='https://rizky-make-it.github.io/rizky-atelier/'
def render(name,title,caption):return {'image':prefix+'/'+name+'.jpg','title':title,'caption':caption,'request':'the original BELGRAVIA Blender interior render: '+title,'sourceUrl':url+'downloads/belgravia/'+proof[name]['file']}
def file(title,ext,desc,request,p):return {'title':title,'extension':ext,'description':desc,'request':request,'sourceUrl':url+p}
collection={'id':'belgravia','name':'BELGRAVIA','number':'08','referenceYear':2023,'kind':'Furnished catalogue interior','layout':'furnished-interior','title':'An elegant life, in ivory.','tagline':'Walnut burl. Ivory lacquer. Gilded detail.',
 'description':'Twenty-two distinct MARINER references inhabit an arched-window salon, a walnut dining room, a soft ivory bedroom and a classical office. Dark walnut burl, white lacquer, sycamore-tone marquetry, carved gilt columns and faceted diamond aprons follow the supplied BELGRAVIA pages. Crystal lighting, pleated curtains, panel mouldings and pale textiles interpret the original room compositions. The connected plan, unseen construction and exact finish calibration remain authored interpretations, not certified manufacturer CAD or a measured source building.',
 'finish':'BEL. / OF (488/55); high-back stool BEL. (488); ornate mirror POE. (380)','hero':prefix+'/living-wide.jpg','exhibition':prefix+'/belgravia-interior.glb','scene':prefix+'/scene.json','placementCount':len(scene['placements']),'movingParts':0,'sourceSite':url+'#/collections/belgravia','sourceRepo':'https://github.com/rizky-make-it/rizky-atelier','productCount':22,'palette':['#473024','#ded9ca','#b28b42','#444742'],
 'roomReferences':[{'image':prefix+'/original-room-'+k+'.jpg','title':title,'caption':'MARINER classic catalogue, PDF page '+str(page)+'. Original supplied room composition, separate from the authored Blender render.'} for k,title,page in [('living','The original arched-window salon',36),('dining','The original dining room',102),('bedroom','The original ivory bedroom',125),('office','The original classic office',132)]],
 'renders':[
 render('living','The arched-window salon','Damask seating, crystal-stem lamps, grey oak flooring and white arch-top windows. Native enclosed-room Blender render, 3840 × 2160.'),
 render('living-wide','An ivory conversation','Individually modelled gilt columns, a square walnut coffee table and white-lacquer seating within charcoal architecture. Native Blender render, 3840 × 2160.'),
 render('dining','The walnut dining room','The distinct six-legged dining table, striped chairs, scroll-arm chairs, three-drawer sideboard, broad mirror and glazed cabinet. Native Blender render, 3840 × 2160.'),
 render('dining-pedestal','The twin-pedestal setting','A separately specified dining table with two white/burl pedestals and splayed gilt claw feet. Not a colour variant of the six-leg table. Native Blender render, 3840 × 2160.'),
 render('bedroom','The ivory bedroom','One broad tufted headboard field, faceted friezes, paired nightstands, raised rolled-end bench and cream/gold rug. Native Blender render, 3840 × 2160.'),
 render('vanity','The dressing corner','A separate dressing table and portrait mirror with the catalogue\'s 800 mm high-back, skirted vanity chair. Native Blender render, 3840 × 2160.'),
 render('office','The classic office','Walnut-burl writing desk, floral armchair, fluted pilasters, shutters and olive-brown drapes. Native Blender render, 3840 × 2160.'),
 render('office-wide','A room for thought','The reverse desk panels, marble fireplace and pale floral rug interpret the supplied office composition. Native Blender render, 3840 × 2160.'),
 render('detail-burl','Walnut, diamonds & gilt','Authored walnut-burl PBR and physical diamond frieze with carved-column geometry. Actual native Blender detail, 1600 × 1600.'),
 render('detail-upholstery','Damask & carved framing','Authored acanthus textile, fine thread normal, cushion seams and gilded front uprights. Not a scanned or calibrated manufacturer fabric. Native detail, 1600 × 1600.'),
 render('detail-tufting','A single field of tufting','Physical diamond-button recesses, faceted white frieze and gilt framing on the broad headboard. Native Blender detail, 1600 × 1600.')],
 'materials':[{'image':prefix+'/detail-burl.jpg','title':'Walnut burl & diamond relief','description':'Dark authored walnut-burl veneer, fine inlay lines, white lacquer and actual raised diamond geometry. Digital interpretation, not a physical sample.'},{'image':prefix+'/detail-upholstery.jpg','title':'Ivory acanthus damask','description':'Reference-inspired pale botanical weave, packed micro-thread normals and modelled seams. Exact manufacturer fabric is not certified.'},{'image':prefix+'/detail-tufting.jpg','title':'Tufting & gilt columns','description':'Recessed buttons, soft tufted geometry, gilded framing and a faceted white-lacquer frieze, rendered from the editable scene.'}],
 'files':[file('Native Belgravia residence','.BLEND','22 unique references, four complete rooms, packed PBR maps and eleven cameras.','the BELGRAVIA editable Blender furnished-interior master (.blend)','downloads/belgravia/belgravia-interior.blend'),
 file('Interior & individual models','.GLB','An enclosed furnished residence and 22 full-detail individual product models.','the BELGRAVIA furnished residence GLB and 22 individual product GLBs',prefix+'/belgravia-interior.glb'),
 file('Complete rebuild project','.ZIP','Native scene, source geometry, PBR maps, reference provenance and audits.','the complete BELGRAVIA Blender project, textures, reference evidence and rebuild scripts','downloads/belgravia/belgravia-project.zip'),
 file('Original room & product references','.PDF','Twelve supplied MARINER spreads across living, dining, bedroom and office.','the BELGRAVIA living, dining, bedroom and office source catalogue reference pages','downloads/belgravia/BELGRAVIA-reference-pages.pdf'),
 file('Original 4K interior renders','4K PNG','Eight genuine 4K Blender room renders and three 1600-square details.','all BELGRAVIA original 4K Blender interior renders and detailed material images','downloads/belgravia/render-proof.json')]}

(ASSET/'collection.json').write_text(json.dumps(collection,indent=2),encoding='utf8')
(ASSET/'asset-audit.json').write_text(json.dumps({'collection':'BELGRAVIA','sourcePDFSHA256':source['source_pdf_sha256'],'files':copies,'renderProof':proof},indent=2),encoding='utf8')
print('BELGRAVIA_PACKAGED',json.dumps({'renders':len(proof),'products':len(models),'placements':len(scene['placements']),'nativeBytes':(DOWN/'belgravia-interior.blend').stat().st_size,'zipBytes':(DOWN/'belgravia-project.zip').stat().st_size}),flush=True)
