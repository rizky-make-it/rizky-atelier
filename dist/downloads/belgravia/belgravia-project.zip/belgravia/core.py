"""BELGRAVIA metric geometry bridge and authored, packed PBR material library.

Colour/roughness are visual interpretations of the supplied catalogue, not
calibrated physical samples. Product photographs are not used as geometry.
"""
import math
from pathlib import Path
import numpy as np
import bpy
import geometry as g
BASE=Path(__file__).resolve().parent
g.BASE=BASE
M=g.M
for _name in ('set_parent','link','empty','mesh','box','sphere','lathe','cylinder','rod','curve','material','image_map','generated','light'):
    globals()[_name]=getattr(g,_name)
def __getattr__(name):
    if name=='PARENT':return g.PARENT
    raise AttributeError(name)

def field(x,y,seed=0):
    rng=np.random.default_rng(seed);value=np.zeros_like(x)
    for i in range(7):
        a,b,phase=rng.uniform(.6,2.8),rng.uniform(.6,2.8),rng.uniform(0,math.tau)
        value+=np.sin((x*a+y*b)*2**i+phase)*np.cos((x*b-y*a)*2**i-phase)/2**(i*.85)
    return value
def texture(name,rgb,noncolor=False):
    return generated(name,np.concatenate((np.clip(rgb,0,1),np.ones((*rgb.shape[:2],1),dtype=np.float32)),axis=2),noncolor)

def materials():
    (BASE/'textures').mkdir(exist_ok=True)
    n=1536;y,x=np.mgrid[0:n,0:n].astype(np.float32)/n
    u=np.abs(x-.5)*5;v=y*5;warp=field(u,v,34)
    wx=u+.24*field(u,v,7);wy=v+.20*field(v,u,81)
    grain=np.sin(wx*29+wy*3+warp*4);eyes=np.zeros_like(x)
    for cx,cy in [(.35,1),(1.3,3.8),(2.2,1.7),(.5,4.3),(2.5,4.2)]:
        r=np.sqrt((wx-cx)**2+(wy-cy)**2*.7)
        eyes+=np.sin(r*36+warp*1.6)*np.exp(-r*r*.55)
    value=np.clip(.50+.15*warp+.075*grain+.10*eyes+.010*field(u*12,v*12,4),0,1)
    burl=np.array([.015,.006,.003])+(np.array([.24,.105,.045])-np.array([.015,.006,.003]))*value[...,None]
    woodpath=texture('belgravia_walnut_burl',burl)
    weave=np.sin(x*math.tau*240)*np.cos(y*math.tau*239)
    clothpath=texture('belgravia_champagne_satin',np.stack([.68+weave*.008,.65+weave*.008,.57+weave*.007],axis=2))
    # Repeating botanical damask: rosettes, curved stems, paired leaves and
    # finer warp/weft. Authored motif, not a manufacturer fabric scan.
    tx=x*8;ty=y*8;fx=(tx+.5*(np.floor(ty)%2))%1-.5;fy=ty%1-.5
    a=np.arctan2(fy,fx);r=np.sqrt(fx*fx+fy*fy)
    petal=np.exp(-((r-(.12+.045*np.cos(6*a)))/.035)**2)
    leaf=np.exp(-((np.abs(fx)-(.16+.09*np.sin(fy*8)))/.038)**2)*np.sin(fy*math.pi*2)**2
    stem=np.exp(-((fx-.09*np.sin(fy*9))/.013)**2)*.32
    pattern=np.clip(petal*.65+leaf*.6+stem,0,1)
    damask=np.array([.63,.60,.52])+pattern[...,None]*np.array([.065,.06,.05])+weave[...,None]*.01
    damaskpath=texture('belgravia_botanical_damask',damask)
    dx=np.cos(x*math.tau*240)*np.sin(y*math.tau*239)*.12
    dy=np.sin(x*math.tau*240)*np.cos(y*math.tau*239)*.12
    normalpath=texture('belgravia_thread_normal',np.stack([.5-dx,.5-dy,np.ones_like(x)],axis=2),True)
    marblewarp=field(x*5,y*5,95)
    vein=np.exp(-np.abs(np.sin(x*18+y*10+marblewarp*1.5))*85)
    cloud=field(x*9,y*9,61)*.013
    marble=np.array([.80,.78,.70])+cloud[...,None]-vein[...,None]*np.array([.30,.29,.24])
    marblepath=texture('belgravia_pale_veined_marble',marble)
    rugfield=field(x*6,y*6,80)
    rugmotif=.5+.22*np.cos(x*math.tau*7)*np.cos(y*math.tau*9)+rugfield*.08
    rugpath=texture('belgravia_vintage_rug',np.stack([.18+rugmotif*.075,.105+rugmotif*.055,.073+rugmotif*.045],axis=2))
    # Grey-washed wide-plank oak and a restrained cream/gold floral carpet.
    grain=np.sin(x*320+field(x*8,y*3,44)*4)*.012+field(x*45,y*2,51)*.015
    plankpath=texture('belgravia_grey_oak',np.stack([.29+grain,.30+grain,.285+grain],axis=2))
    ux=(x-.5)*1.25;vy=y-.5;rad=np.sqrt(ux*ux+vy*vy);angle=np.arctan2(vy,ux)
    ring=np.exp(-((rad-(.20+.009*np.cos(angle*12)))/.009)**2)
    edge=np.minimum(np.minimum(x,1-x),np.minimum(y,1-y))
    border=np.exp(-((edge-.045)/.004)**2)+np.exp(-((edge-.066)/.004)**2)
    leafscroll=np.exp(-((np.abs(ux)-(.15+.08*np.cos(vy*22)))/.014)**2)*np.sin(vy*32)**2
    floral=np.clip(ring*.8+border*.5+leafscroll*.28,0,1)
    carpet=np.array([.69,.65,.55])-floral[...,None]*np.array([.17,.20,.22])+weave[...,None]*.006
    carpetpath=texture('belgravia_cream_gold_floral_carpet',carpet)
    palette={
      'wood':((.38,.15,.035),.20,0),'wood_dark':((.045,.019,.008),.23,0),'inside':((.23,.09,.025),.34,0),
      'bronze':((.48,.28,.08),.28,.84),'gold':((.65,.43,.13),.23,.86),'brass':((.58,.36,.09),.25,.88),
      'cloth':((.68,.65,.57),.62,0),'cloth_light':((.72,.69,.61),.68,0),'cloth_gold':((.49,.34,.16),.68,0),'cloth_dark':((.06,.045,.035),.74,0),
      'white':((.79,.77,.69),.22,0),'ivory':((.72,.69,.62),.72,0),'damask':((.66,.63,.55),.7,0),
      'mirror':((.92,.94,.95),.04,1),'piano':((.007,.006,.005),.13,0),'antique_gold':((.52,.32,.08),.29,.8),
      'stitch':((.37,.30,.20),.87,0),'black':((.008,.008,.008),.24,.04),'inlay':((.68,.51,.27),.25,0),
      'stone':((.8,.78,.70),.19,0),'plinth':((.64,.60,.51),.58,0),'rug':((.24,.16,.11),.98,0),
      'floor_wood':((.29,.30,.285),.48,0),'carpet':((.67,.63,.54),.98,0),'floral_rug':((.69,.65,.55),.98,0),'shag':((.40,.33,.23),.98,0),
      'paper':((.80,.77,.66),.82,0),'ceramic':((.02,.035,.11),.19,.08),'leaf':((.035,.075,.021),.65,0),
      'glass':((.91,.94,.91),.05,0),'window':((.85,.92,.96),.03,0),'light':((1,.81,.48),.25,0),
      'wall':((.19,.20,.19),.88,0),'wall_dark':((.072,.075,.069),.87,0),'plaster':((.71,.68,.60),.81,0),
      'curtain':((.74,.69,.58),.95,0),'curtain_dark':((.055,.042,.025),.90,0),'plum_rug':((.25,.15,.16),.97,0),
      'sky':((.63,.75,.83),1,0),'city':((.28,.35,.38),.86,0),'cityglass':((.29,.43,.49),.43,.12),'fire':((1,.20,.016),.6,0),
    }
    for key,(color,rough,metal) in palette.items():M[key]=material('BELGRAVIA | '+key,color,rough,metal)
    for key in ('wood','inside'):image_map(M[key],woodpath,'Base Color')
    image_map(M['cloth'],clothpath,'Base Color');image_map(M['damask'],damaskpath,'Base Color')
    image_map(M['stone'],marblepath,'Base Color');image_map(M['rug'],rugpath,'Base Color')
    image_map(M['floor_wood'],plankpath,'Base Color');image_map(M['floral_rug'],carpetpath,'Base Color')
    for key in ('carpet','floral_rug','shag'):image_map(M[key],normalpath,'Normal',True,.55)
    for key in ('cloth','cloth_light','cloth_gold','cloth_dark','ivory','damask','rug','curtain','curtain_dark','plum_rug'):
        image_map(M[key],normalpath,'Normal',True,.33)
        bs=M[key].node_tree.nodes['Principled BSDF'];bs.inputs['Sheen Weight'].default_value=.2;bs.inputs['Sheen Tint'].default_value=(*palette[key][0],1)
    for key in ('wood','wood_dark','white','piano','black','stone','ceramic'):
        bs=M[key].node_tree.nodes['Principled BSDF'];bs.inputs['Coat Weight'].default_value=.42;bs.inputs['Coat Roughness'].default_value=.14
    for key in ('wood','inside'):
        bs=M[key].node_tree.nodes['Principled BSDF'];bs.inputs['Roughness'].default_value=.30;bs.inputs['Coat Weight'].default_value=.20;bs.inputs['Coat Roughness'].default_value=.23
    for key in ('wall','wall_dark','plaster','bronze','gold'):
        nodes=M[key].node_tree.nodes;links=M[key].node_tree.links
        noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=220
        bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.12;bump.inputs['Distance'].default_value=.00018
        links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],nodes['Principled BSDF'].inputs['Normal'])
    bs=M['glass'].node_tree.nodes['Principled BSDF'];bs.inputs['Transmission Weight'].default_value=.12;bs.inputs['IOR'].default_value=1.46;bs.inputs['Alpha'].default_value=.16
    M['glass'].surface_render_method='BLENDED';M['glass'].use_raytrace_refraction=False
    bs=M['window'].node_tree.nodes['Principled BSDF'];bs.inputs['Alpha'].default_value=.018;bs.inputs['Specular IOR Level'].default_value=0
    M['window'].surface_render_method='BLENDED'
    for key,strength in (('light',3),('sky',.5),('fire',6)):
        bs=M[key].node_tree.nodes['Principled BSDF'];bs.inputs['Emission Color'].default_value=(*palette[key][0],1);bs.inputs['Emission Strength'].default_value=strength
    for mat in M.values():mat['interpretation']='Authored PBR interpretation of user-supplied MARINER catalogue; not a calibrated material sample'
    return M
