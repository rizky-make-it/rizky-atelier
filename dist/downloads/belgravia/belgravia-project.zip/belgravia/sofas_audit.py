"""Measure eight real evaluated product bounds and render a QA contact sheet."""
import json,sys,math,hashlib
from pathlib import Path
import bpy
from mathutils import Vector
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import core as c
import sofas

bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.set_parent(None);c.materials();result=[]
for i,(sku,spec) in enumerate(sofas.SPECS.items()):
    root=sofas.create(sku,'audit');bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get();inv=root.matrix_world.inverted();points=[];triangles=0;objects=0
    for ob in root.children_recursive:
        if ob.type!='MESH':continue
        ev=ob.evaluated_get(graph);points.extend(inv@ev.matrix_world@v.co for v in ev.data.vertices)
        ev.data.calc_loop_triangles();triangles+=len(ev.data.loop_triangles);objects+=1
    lo=[min(p[k] for p in points) for k in range(3)];hi=[max(p[k] for p in points) for k in range(3)]
    dims=[hi[k]-lo[k] for k in range(3)];delta=[abs(dims[k]-spec[k])*1000 for k in range(3)]
    assert max(delta)<3,(sku,dims,delta)
    assert max(abs(lo[0]+hi[0]),abs(lo[1]+hi[1]),abs(lo[2]))<.001,(sku,lo,hi)
    result.append({'sku':sku,'dimensions_m':dims,'error_mm':delta,'min':lo,'max':hi,'triangles':triangles,'mesh_objects':objects,'normalization_scale':list(root['normalization_scale'])})
    root.location=((i%4-1.5)*3.1,(i//4-.5)*3.4,0);c.set_parent(None)
    text=bpy.data.curves.new('QA label','FONT');text.body=sku;text.size=.15
    ob=bpy.data.objects.new('QA label '+sku,text);bpy.context.scene.collection.objects.link(ob);ob.location=(root.location.x-.77,root.location.y-1.30,.003);text.materials.append(c.M['piano'])
report={'passed':True,'source_sha256':sofas.SOURCE_SHA256,'module_sha256':hashlib.sha256((BASE/'sofas.py').read_bytes()).hexdigest(),'products':result,'total_triangles':sum(x['triangles'] for x in result),'notes':['Native evaluated vertex bounds, including modifiers and decorative styling.','50035.0 kept at printed470mm overall width, including scroll arms.','50049.0 is reconstructed as the photographed high-backed skirted dressing chair.','50037.0 uses shared family photograph and separately stated width.']}
(BASE/'sofas-audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print('BELGRAVIA_UPHOLSTERY_AUDIT',json.dumps(report))
c.box('QA contact sheet ground',(0,0,-.055),(20,13,.10),'plinth',0)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=18;scene.cycles.use_denoising=True;scene.render.threads_mode='FIXED';scene.render.threads=6;scene.world.color=(.24,.24,.24)
c.light('Large frontal key','AREA',(2,-7,10),2300,(1,.93,.82),target=(0,0,.6),size=9)
c.light('Left fill','AREA',(-8,0,7),1600,(.82,.90,1),target=(0,0,.6),size=7)
c.light('Back rim','AREA',(0,7,7),2100,(1,.94,.85),target=(0,0,.6),size=7)
camdata=bpy.data.cameras.new('Upholstery QA overview');cam=bpy.data.objects.new('Upholstery QA overview',camdata);scene.collection.objects.link(cam)
cam.location=(5,-13,12);cam.rotation_euler=(Vector((0,0,.45))-cam.location).to_track_quat('-Z','Y').to_euler();camdata.type='ORTHO';camdata.ortho_scale=14.0
scene.camera=cam;scene.render.resolution_x=2400;scene.render.resolution_y=1500;scene.render.resolution_percentage=100;scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.filepath=str(BASE/'sofas-preview.png')
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'sofas-audit.blend'));bpy.ops.render.render(write_still=True)
