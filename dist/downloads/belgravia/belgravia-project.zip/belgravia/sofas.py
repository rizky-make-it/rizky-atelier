"""BELGRAVIA reference-led editable upholstery, MARINER classic catalogue.

All geometry is authored here. X=width, Y=depth/front=-Y, Z=up; metres.
Only observed fixed structure is modelled; unknown joints are interpretations.
The catalogue photos are evidence, never image planes masquerading as models.
"""
import math
from contextlib import contextmanager
import bpy
import numpy as np
from mathutils import Vector
import core as c

TAU=math.tau
SOURCE_SHA256='ce8ec15e3c67e962c5d3c308ecc60eaf10f2983652b4537c410c17dbe3a5df24'
SPECS={
 '50036.0':(2.210,.800,1.130,'sofa',3,'Belgravia three-seat sofa'),
 '50037.0':(1.500,.800,1.110,'sofa',2,'Belgravia two-seat sofa'),
 '50038.0':(.780,.800,1.110,'sofa',1,'Belgravia armchair'),
 '50034.0':(.470,.620,.980,'chair',0,'Belgravia dining chair'),
 '50035.0':(.470,.620,.980,'chair',1,'Belgravia dining armchair'),
 '50044.0':(2.230,2.150,1.440,'bed',0,'Belgravia upholstered bed'),
 '50048.0':(1.620,.530,.700,'bench',0,'Belgravia rolled-end bench'),
 '50049.0':(.500,.520,.800,'stool',0,'Belgravia skirted high-back dressing stool'),
}

@contextmanager
def parent(ob):
    previous=c.PARENT;c.set_parent(ob)
    try:yield ob
    finally:c.set_parent(previous)

class Batch:
    """Solid ornament in a few editable material-group meshes, not object spam."""
    def __init__(self,name,mat):self.name=name;self.mat=mat;self.v=[];self.f=[]
    def tube(self,points,radius,sides=6,cyclic=False):
        pts=[Vector(p) for p in points]
        if len(pts)<2:return
        if cyclic:pts.append(pts[0])
        base=len(self.v)
        for i,p in enumerate(pts):
            tangent=(pts[min(i+1,len(pts)-1)]-pts[max(i-1,0)]).normalized()
            axis=Vector((0,1,0)) if abs(tangent.y)<.95 else Vector((0,0,1))
            a=tangent.cross(axis).normalized();b=tangent.cross(a).normalized()
            for j in range(sides):
                t=TAU*j/sides;self.v.append(tuple(p+radius*(a*math.cos(t)+b*math.sin(t))))
        for i in range(len(pts)-1):
            for j in range(sides):
                q=base+i*sides+j;r=base+i*sides+(j+1)%sides;self.f.append((q,r,r+sides,q+sides))
        if not cyclic:
            self.f.append(tuple(base+j for j in range(sides-1,-1,-1)))
            self.f.append(tuple(base+(len(pts)-1)*sides+j for j in range(sides)))
    def sphere(self,centre,scale,sides=10,rings=6):
        base=len(self.v)
        for j in range(rings+1):
            t=math.pi*j/rings
            for i in range(sides):
                a=TAU*i/sides;self.v.append((centre[0]+scale[0]*math.sin(t)*math.cos(a),centre[1]+scale[1]*math.sin(t)*math.sin(a),centre[2]+scale[2]*math.cos(t)))
        for j in range(rings):
            for i in range(sides):
                q=base+j*sides+i;r=base+j*sides+(i+1)%sides;self.f.append((q,r,r+sides,q+sides))
    def leaf(self,start,end,width,normal=(0,-1,0),bulge=.004):
        a,b,n=Vector(start),Vector(end),Vector(normal);d=b-a;across=d.cross(n).normalized();base=len(self.v)
        for j in range(8):
            t=j/7;w=width*math.sin(math.pi*t)**.75*(.85+.15*math.cos(t*TAU*3))
            for i in range(5):
                u=(i-2)/2;p=a+d*t+across*u*w+n*bulge*math.sin(math.pi*t)*(1-.8*abs(u));self.v.append(tuple(p))
        for j in range(7):
            for i in range(4):q=base+j*5+i;self.f.append((q,q+1,q+6,q+5))
        self.tube([tuple(a+d*(j/7)+n*(bulge*math.sin(math.pi*j/7)+.0006)) for j in range(8)],.00065,5)
    def finish(self):return c.mesh(self.name,self.v,self.f,self.mat,smooth=True) if self.f else None

def materials():
    if 'belgravia_silk' in c.M:return
    colors={
      'belgravia_silk':((.72,.685,.60),.53),
      'belgravia_damask':((.73,.70,.63),.66),
      'belgravia_stripe':((.64,.59,.50),.67),
      'belgravia_bedding':((.52,.55,.51),.79),
      'belgravia_pink':((.52,.435,.415),.65),
      'belgravia_stool':((.61,.585,.55),.78),
    }
    for key,(col,rough) in colors.items():
        mat=c.material('BELGRAVIA | '+key,col,rough);c.M[key]=mat
        bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Sheen Weight'].default_value=.25;bs.inputs['Sheen Tint'].default_value=(*col,1)
        reference=c.M.get('cloth')
        if reference:
            normal=next((n for n in reference.node_tree.nodes if n.type=='TEX_IMAGE' and n.image and 'normal' in n.image.name.lower()),None)
            if normal:
                tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=normal.image
                nm=mat.node_tree.nodes.new('ShaderNodeNormalMap');nm.inputs['Strength'].default_value=.34
                mat.node_tree.links.new(tex.outputs['Color'],nm.inputs['Color']);mat.node_tree.links.new(nm.outputs['Normal'],bs.inputs['Normal'])
        mat['interpretation']='Authored textile matching catalogue appearance; not a calibrated manufacturer scan.'
    n=1024;y,x=np.mgrid[0:n,0:n].astype(np.float32)/n
    fx=(x*3+.5*(np.floor(y*3)%2))%1-.5;fy=y*3%1-.5
    # Large symmetrical leaf medallions and curling acanthus, not Nantes damask.
    stem=np.exp(-((fx-.045*np.sin(fy*11))/.014)**2)*.38
    motif=stem.copy()
    for sign in (-1,1):
        for off in (-.24,-.06,.14):
            center=sign*(.075+.10*np.sin((fy-off)*6))
            leaf=np.exp(-((fx-center)/.050)**2-((fy-off)/.105)**2)
            motif+=leaf*.70
        scroll=np.exp(-((fx-sign*(.16+.095*np.sin(fy*9)))/.014)**2)*np.sin(fy*math.pi*2)**2*.38
        motif+=scroll
    weave=np.sin(x*TAU*260)*np.cos(y*TAU*259)*.006
    rgb=np.array([.71,.683,.615])+np.clip(motif,0,1)[...,None]*np.array([.10,.095,.08])+weave[...,None]
    path=c.generated('belgravia_cream_acanthus_damask',np.concatenate((rgb,np.ones((*rgb.shape[:2],1),dtype=np.float32)),axis=2))
    c.image_map(c.M['belgravia_damask'],path,'Base Color')
    stripe=(np.cos(x*TAU*10)>-.02).astype(np.float32)
    fine=np.sin(x*TAU*190)*np.sin(y*TAU*187)*.008
    # Wide pearl and soft taupe bands observed on side chair and rolled bench.
    rgb=np.array([.50,.445,.385])+stripe[...,None]*np.array([.23,.24,.23])+fine[...,None]
    path=c.generated('belgravia_pearl_taupe_wide_stripes',np.concatenate((rgb,np.ones((*rgb.shape[:2],1),dtype=np.float32)),axis=2))
    c.image_map(c.M['belgravia_stripe'],path,'Base Color')

def cushion(name,centre,dims,mat,rotation=(0,0,0),seat=False,phase=0,softness=1,n=18,piping=None):
    """Closed six-patch fabric volume with rounded corners, real folds and welt."""
    holder=c.empty(name,centre);holder.rotation_euler=rotation;half=[v/2 for v in dims];power=9 if seat else 4.6
    def shape(q):
        den=sum(abs(v)**power for v in q)**(1/power);p=[half[k]*q[k]/den for k in range(3)]
        if seat:
            if abs(q[2])>.99:
                edge=math.exp(-((abs(q[1])-.82)/.19)**2)
                p[2]+=math.copysign(.0025*softness*math.sin(q[0]*41+phase+math.sin(q[0]*13))*edge,q[2])
                if q[2]>0:p[2]-=.003*softness*(1-q[0]**2)*(1-q[1]**2)
            if abs(q[1])>.99:p[1]+=math.copysign(.003*softness*math.sin(q[0]*38+phase)*(1-q[2]**2),q[1])
        elif abs(q[1])>.99:
            edge=math.exp(-((abs(q[0])-.82)/.18)**2)+math.exp(-((abs(q[2])-.84)/.15)**2)
            p[1]+=math.copysign(softness*(.007*(1-q[0]**2)*(1-q[2]**2)+.0038*math.sin(q[0]*32+q[2]*11+phase)*edge),q[1])
        return tuple(p)
    with parent(holder):
        vv=[];ff=[];uv=[]
        for axis,sign in [(0,-1),(0,1),(1,-1),(1,1),(2,-1),(2,1)]:
            other=[i for i in range(3) if i!=axis];base=len(vv)
            for j in range(n+1):
                for i in range(n+1):
                    q=[0,0,0];q[axis]=sign;q[other[0]]=-1+2*i/n;q[other[1]]=-1+2*j/n
                    vv.append(shape(q));uv.append((q[other[0]]*half[other[0]],q[other[1]]*half[other[1]]))
            forward=sign*(1 if axis!=1 else -1)>0
            for j in range(n):
                for i in range(n):q=base+j*(n+1)+i;f=(q,q+1,q+n+2,q+n+1);ff.append(f if forward else tuple(reversed(f)))
        c.mesh(name+' | tailored filled textile',vv,ff,mat,uv,True)
        points=[]
        for side in range(4):
            for i in range(20):
                t=-1+2*i/20;a,b=[(1,t),(-t,1),(-1,-t),(t,-1)][side]
                points.append(shape((a,b,0) if seat else (a,0,b)))
        c.curve(name+' | sewn perimeter welt',points,.0015,piping or mat,True)
    return holder

def oval(batch,centre,u_axis,v_axis,a,b,radius=.0013,n=22):
    p,u,v=Vector(centre),Vector(u_axis),Vector(v_axis)
    batch.tube([tuple(p+u*a*math.cos(TAU*i/n)+v*b*math.sin(TAU*i/n)) for i in range(n)],radius,5,True)

def rosette(gold,relief,centre,r=.021,normal=(0,-1,0)):
    p,n=Vector(centre),Vector(normal);u=Vector((1,0,0)) if abs(n.y)>.8 else Vector((0,1,0));v=n.cross(u).normalized()
    oval(gold,p,u,v,r,r,.0012,24)
    for i in range(10):
        a=TAU*i/10;d=u*math.cos(a)+v*math.sin(a)
        relief.leaf(tuple(p+d*r*.15),tuple(p+d*r*.85),r*.20,tuple(n),.003)
    relief.sphere(tuple(p+n*.003),tuple(.003 if abs(n[k])>.8 else .004 for k in range(3)),10,6)

def beadline(batch,points,pitch=.010,r=.0018):
    points=[Vector(p) for p in points]
    for a,b in zip(points,points[1:]):
        count=max(1,round((b-a).length/pitch))
        for i in range(count):batch.sphere(tuple(a.lerp(b,(i+.5)/count)),(r,r,r),6,4)

def crest(gold,relief,width,y,z):
    """Hand-carved open scroll crest with individual acanthus leaves."""
    c.box('Dark burl central crest pedestal',(0,y+.006,z-.005),(width*.63,.030,.025),'wood_dark',.002)
    for sign in (-1,1):
        pts=[]
        for i in range(30):
            t=i/29;rad=width*.18*(1-.74*t);a=-.8+TAU*1.05*t
            pts.append((sign*(width*.15+rad*math.cos(a)),y,z+.020+rad*.62*math.sin(a)))
        gold.tube(pts,.0037,7)
        for i in range(1,7):
            t=i/7;x=sign*width*(.08+.34*t);zz=z+.016+.025*math.sin(t*math.pi)
            relief.leaf((x,y,zz),(x+sign*.026,y,zz+.027),.008,(0,-1,0),.005)
    for i in range(7):
        a=(i-3)*.21;start=(math.sin(a)*.009,y,z+.025);end=(math.sin(a)*width*.16,y,z+.060+.035*math.cos(a))
        relief.leaf(start,end,.011,(0,-1,0),.005)

def finial(name,x,y,z,height,gold,relief):
    r=height*.23
    c.lathe(name+' | turned bronze pinecone',(x,y,z),[(0,0),(r*.8,.004),(r*.8,.012),(r*.60,.016),(r,.030),(r*.72,height*.74),(0,height)],'bronze',24)
    for j in range(5):
        t=(j+1)/6;rr=r*math.sin(math.pi*t)**.6
        for i in range(7):
            a=TAU*(i+.5*(j%2))/7
            relief.sphere((x+rr*math.cos(a),y+rr*math.sin(a),z+.018+t*(height-.023)),(.004,.004,.005),7,4)

def tapered_leg(name,x,y,height,width=.073):
    bottom=width*.55;top=width
    vv=[(x+sx*(bottom if k==0 else top)/2,y+sy*(bottom if k==0 else top)/2,k*height) for k in (0,1) for sx,sy in [(-1,-1),(1,-1),(1,1),(-1,1)]]
    c.mesh(name+' | white tapered block',vv,[(0,3,2,1),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7),(4,5,6,7)],'white')
    # Flush dark walnut panels leave real white lacquer edge bands on two sides.
    panel=[(x-bottom*.31,y-bottom/2-.0007,.008),(x+bottom*.31,y-bottom/2-.0007,.008),(x+top*.33,y-top/2-.0007,height-.014),(x-top*.33,y-top/2-.0007,height-.014)]
    c.mesh(name+' | front tapered dark burl inset',panel,[(0,1,2,3)],'wood_dark')
    for sign in (-1,1):
        c.mesh(name+' | side tapered dark burl inset',[(x+sign*(bottom/2+.0007),y-bottom*.31,.008),(x+sign*(bottom/2+.0007),y+bottom*.31,.008),(x+sign*(top/2+.0007),y+top*.33,height-.014),(x+sign*(top/2+.0007),y-top*.33,height-.014)],[(0,1,2,3)],'wood_dark')

def frame_apron(width,depth,z,h,gold):
    for sign in (-1,1):
        c.box('White lacquer seat apron',(0,sign*(depth/2-.018),z),(width,.045,h),'white',.004)
        c.box('Recessed dark burl long apron inlay',(0,sign*(depth/2+.006),z),(width-.11,.002,h-.027),'wood_dark',.0003)
        gold.tube([(-width/2+.055,sign*(depth/2+.008),z-h/2+.014),(width/2-.055,sign*(depth/2+.008),z-h/2+.014)],.0009,5)
        c.box('White lacquer side apron',(sign*(width/2-.019),0,z),(.043,depth-.020,h),'white',.004)
        c.box('Side walnut burl apron inlay',(sign*(width/2+.004),0,z),(.002,depth-.106,h-.027),'wood_dark',.0003)

def column(name,x,y,z0,height,gold,relief,r=.023):
    """Solid turned tapered shaft with individually modelled acanthus/flutes."""
    c.lathe(name+' | hand-carved bronze shaft',(x,y,z0),[(0,0),(r*.86,0),(r,.010),(r*.70,.025),(r*.65,height*.22),(r*.92,height*.64),(r*.92,height*.78),(r*.72,height*.91),(r*.95,height*.95),(r*.95,height),(0,height)],'bronze',28)
    for i in range(10):
        a=TAU*i/10;n=Vector((math.cos(a),math.sin(a),0))
        start=Vector((x,y,z0+height*.23))+n*r*.69;end=Vector((x,y,z0+height*.78))+n*r*.98
        relief.leaf(tuple(start),tuple(end),r*.27,tuple(n),.0035)
        gold.tube([tuple(Vector((x,y,z0+height*t))+n*r*(.64+.24*t)) for t in [.10,.20,.35,.50]],.0011,5)
    for zz in (.019,height*.91,height*.96):oval(gold,(x,y,z0+zz),(1,0,0),(0,1,0),r*.95,r*.95,.0016,24)

def sofa(width,depth,height,seats,gold,relief):
    top=height-.105;half=width/2;seatwidth=width-.155
    frame_apron(width-.015,depth-.035,.222,.082,gold)
    footxs=(-half+.055,0,half-.055) if seats==3 else (-half+.055,half-.055)
    for x in footxs:
        for y in (-depth/2+.063,depth/2-.065):tapered_leg('Sofa white/burl tapered foot',x,y,.185,.067)
    c.box('Upholstery support deck',(0,-.005,.285),(width-.10,depth-.09,.070),'ivory',.012)
    # One continuous tall upholstered back, with subtle vertical seam divisions.
    cushion('Continuous tall ivory damask back',(0,depth/2-.080,(.425+top)/2),(width-.075,.102,top-.425),'belgravia_damask',n=24,softness=.36)
    c.box('White lacquer rear structural back',(0,depth/2-.028,(.405+top)/2),(width-.025,.052,top-.405),'white',.005)
    c.box('Dark walnut exterior back inset',(0,depth/2+.0008,(.435+top-.025)/2),(width-.108,.002,top-.460),'wood',.001)
    for i in range(1,seats):
        x=-seatwidth/2+seatwidth*i/seats
        c.curve('Fine sewn vertical back upholstery division',[(x,depth/2-.137,.455),(x,depth/2-.137,top-.018)],.0007,'belgravia_silk')
    # Sloping upholstered side profiles follow the source, not a Nantes U-shell.
    for sign in (-1,1):
        profile=[]
        for i in range(45):
            t=i/44;y=-depth/2+.045+(depth-.100)*t
            z=.641+(top-.641)*t**3.2;profile.append((y,z))
        x=sign*(half-.031);vv=[];ff=[];uv=[]
        for side in (-1,1):
            for j in range(11):
                t=j/10
                for i,(y,z) in enumerate(profile):
                    bulge=.009*math.sin(math.pi*t)*math.sin(math.pi*i/44)
                    vv.append((x+sign*(side*.024+bulge),y,.300+(z-.300)*t));uv.append((y,.300+(z-.300)*t))
        cols=len(profile);patch=cols*11
        for side in range(2):
            for j in range(10):
                for i in range(cols-1):
                    q=side*patch+j*cols+i;f=(q,q+1,q+cols+1,q+cols);ff.append(f if side else tuple(reversed(f)))
        for i in range(cols-1):ff.append((10*cols+i,10*cols+i+1,patch+10*cols+i+1,patch+10*cols+i))
        for j in range(10):
            for i in (0,cols-1):
                q=j*cols+i;ff.append((q,q+cols,q+cols+patch,q+patch))
        c.mesh('Sloping ivory damask upholstered arm and side',vv,ff,'belgravia_damask',uv,True)
        upper=[(sign*(half-.018),y,z+.006) for y,z in profile]
        c.curve('White lacquer sloping back-and-arm rim',upper,.013,'white')
        gold.tube([(sign*(half-.023),y-.004,z+.015) for y,z in profile],.002,7)
        # Chain-like gilt border physically follows the inner rise.
        for i in range(7,44,2):
            y,z=profile[i];oval(gold,(sign*(half-.040),y-.006,z-.013),(0,1,0),(0,0,1),.006,.008,.0010,12)
        xcol=sign*(half-.043);yf=-depth/2+.030
        column('Sofa acanthus front arm column',xcol,yf,.266,.358,gold,relief,.021)
        rosette(gold,relief,(xcol,yf-.023,.646),.025)
        # Corner back block and small cast-bronze pinecone.
        c.box('White upper corner finial block',(sign*(half-.025),depth/2-.030,top-.002),(.065,.069,.050),'white',.003)
        rosette(gold,relief,(sign*(half-.025),depth/2-.067,top-.002),.015)
        finial('Sofa corner pinecone',sign*(half-.025),depth/2-.030,top+.025,.063,gold,relief)
    c.box('White straight upper back rail',(0,depth/2-.030,top),(width-.020,.055,.035),'white',.004)
    gold.tube([(-half+.038,depth/2-.062,top+.010),(half-.038,depth/2-.062,top+.010)],.0016,6)
    beadline(gold,[(-half+.047,depth/2-.064,top-.005),(half-.047,depth/2-.064,top-.005)],.010,.0025)
    crest(gold,relief,min(.255,width*.27),depth/2-.065,top+.019)
    # Separate actual seat cushions; catalogue three-seat has three, not bench seat.
    gap=.010;each=(seatwidth-gap*(seats-1))/seats
    for i in range(seats):
        x=-seatwidth/2+each/2+i*(each+gap)
        cushion('Separate ivory damask seat cushion '+str(i+1),(x,-.063,.361),(each,.584,.126),'belgravia_damask',seat=True,n=18,phase=i*1.3)
    styling=c.empty('Removable reference scatter cushions and cylindrical bolsters',props={'kind':'styling','not_a_separate_catalogue_sku':True})
    with parent(styling):
        xs=(-half+.330,half-.330) if seats>1 else (0,)
        for i,x in enumerate(xs):cushion('Cream loose square scatter pillow '+str(i+1),(x,.074,.590),(.315,.095,.315),'belgravia_silk',rotation=(-.14,0,(-.13 if x<0 else .13)),n=20,phase=i+1)
        if seats>1:
            for sign in (-1,1):
                ob=c.lathe('Round gathered end bolster',(sign*(half-.225),-.095,.491),[(0,-.134),(.072,-.134),(.078,-.124),(.078,.124),(.072,.134),(0,.134)],'belgravia_silk',40)
                ob.rotation_euler=(0,math.pi/2,0)
                for x in (sign*(half-.225)-.134,sign*(half-.225)+.134):
                    oval(gold,(x,-.095,.491),(0,1,0),(0,0,1),.060,.060,.00075,28)
                    for j in range(12):
                        a=TAU*j/12;c.curve('Bolster radial gathered seam',[(x,-.095+.015*math.cos(a),.491+.015*math.sin(a)),(x,-.095+.069*math.cos(a),.491+.069*math.sin(a))],.00065,'belgravia_silk')
                    c.sphere('Bolster centre fabric button',(x,-.095,.491),(.004,.011,.011),'belgravia_silk',16,8)

def bent_member(name,points,width,depth,mat):
    vv=[];ff=[]
    for x,y,z in points:vv.extend([(x-width/2,y-depth/2,z),(x+width/2,y-depth/2,z),(x+width/2,y+depth/2,z),(x-width/2,y+depth/2,z)])
    for i in range(len(points)-1):
        for j in range(4):q=i*4+j;r=i*4+(j+1)%4;ff.append((q,r,r+4,q+4))
    ff.extend([(3,2,1,0),tuple((len(points)-1)*4+j for j in range(4))]);ob=c.mesh(name,vv,ff,mat)
    mod=ob.modifiers.new('Soft polished curved lacquer edges','BEVEL');mod.width=.0025;mod.segments=3
    mod=ob.modifiers.new('Weighted lacquer normals','WEIGHTED_NORMAL');mod.keep_sharp=True
    return ob

def dining_chair(arms,gold,relief):
    width=.470;depth=.620;cloth='belgravia_damask' if arms else 'belgravia_stripe'
    # Legs are gently sabred rectangular lacquer, not gilt turned console legs.
    for sign in (-1,1):
        x=sign*.191
        for back in (False,True):
            yf=.211 if back else -.230
            pts=[]
            for i in range(13):
                t=i/12;y=yf+(.030 if back else -.018)*(1-t)**2
                pts.append((x+sign*.010*(1-t),y,.005+.422*t))
            bent_member('Curved white lacquer chair leg',pts,.036,.035,'white')
            for s in (-1,1):gold.tube([(x+s*.013,y-.019,z) for x,y,z in pts],.0009,5)
        pts=[]
        for i in range(25):
            t=i/24;pts.append((sign*.206,.197+.090*t-.012*math.sin(t*math.pi),.420+.537*t))
        bent_member('Swept chair back white lacquer stile',pts,.035,.031,'white')
        gold.tube([(x-sign*.009,y-.019,z) for x,y,z in pts],.0011,6)
    frame_apron(.446,.470,.421,.055,gold)
    cushion('Dining chair separately piped seat',(0,-.043,.478),(.433,.485,.103),cloth,seat=True,n=22,phase=.8)
    # Bowed upholstered back with backward rolled top and open gap above seat.
    vv=[];ff=[];uv=[];nx=22;nz=24
    for side in (-1,1):
        for j in range(nz+1):
            t=j/nz;z=.594+.350*t;y=.215+.070*t+.012*math.sin(math.pi*t)
            for i in range(nx+1):
                u=-1+2*i/nx;vv.append((u*.186,y+side*.025-side*.007*(1-u*u)*math.sin(math.pi*t),z));uv.append((u*.186,z))
    patch=(nx+1)*(nz+1)
    for side in range(2):
        for j in range(nz):
            for i in range(nx):q=side*patch+j*(nx+1)+i;f=(q,q+1,q+nx+2,q+nx+1);ff.append(f if side else tuple(reversed(f)))
    for i in range(nx):
        ff.append((i,i+1,patch+i+1,patch+i));q=nz*(nx+1)+i;ff.append((q,q+1,patch+q+1,patch+q))
    for j in range(nz):
        for i in (0,nx):q=j*(nx+1)+i;ff.append((q,q+nx+1,patch+q+nx+1,patch+q))
    ob=c.mesh('Curved upholstered high back, front and back',vv,ff,cloth,uv,True)
    if arms:
        # Plain rear upholstery observed on the office rear view.
        rear=cushion('Plain cream rear back upholstery',(0,.311,.767),(.367,.012,.344),'belgravia_silk',rotation=(-.18,0,0),n=14,softness=.18)
    for sign in (-1,1):
        gold.tube([(sign*.188,.197+.09*t-.001,.594+.35*t) for t in [i/28 for i in range(29)]],.0012,6)
    roll=c.lathe('Small backward-rolled upholstered chair top',(0,.289,.951),[(0,-.205),(.019,-.205),(.020,.205),(0,.205)],cloth,32);roll.rotation_euler=(0,math.pi/2,0)
    for sign in (-1,1):
        rosette(gold,relief,(sign*.213,.289,.951),.014,normal=(sign,0,0))
    c.box('White bottom back rail',(0,.214,.575),(.417,.030,.034),'white',.003)
    gold.tube([(-.207,.195,.564),(.207,.195,.564)],.0011,6)
    if arms:
        for sign in (-1,1):
            # A broad flattened scroll, curled inward at the front, in the YZ plane.
            pts=[]
            for i in range(26):
                t=i/25;pts.append((sign*.215,.229-.429*t,.745-.080*t+.011*math.sin(math.pi*t)))
            for i in range(1,32):
                t=i/31;a=math.pi/2+TAU*.86*t;r=.050*(1-.72*t)
                pts.append((sign*.215,-.200+r*math.cos(a),.615+r*math.sin(a)))
            bent_member('Open white lacquer curled dining arm',pts,.026,.027,'white')
            for sx in (-1,1):gold.tube([(x+sx*.014,y-.008,z+.001) for x,y,z in pts],.0010,6)
            column('Small gilt front arm support',sign*.215,-.200,.497,.082,gold,relief,.012)
            rosette(gold,relief,(sign*.231,-.200,.615),.011,normal=(sign,0,0))

def pyramids(name,width,y,z,height,gold):
    """Actual four triangular faces per white raised marquetry pyramid."""
    count=max(6,round(width/.100));step=width/count;vv=[];ff=[]
    for i in range(count):
        x=-width/2+i*step;base=len(vv)
        vv.extend([(x,y,z-height/2),(x+step,y,z-height/2),(x+step,y,z+height/2),(x,y,z+height/2),(x+step/2,y-.013,z)])
        ff.extend([(base,base+1,base+4),(base+1,base+2,base+4),(base+2,base+3,base+4),(base+3,base,base+4)])
    c.mesh(name,vv,ff,'white')
    for dz in (-height/2-.005,height/2+.005):
        gold.tube([(-width/2,y-.002,z+dz),(width/2,y-.002,z+dz)],.0015,6)
        beadline(gold,[(-width/2,y-.003,z+dz),(width/2,y-.003,z+dz)],.008,.0017)

def draped_duvet():
    """A genuinely falling folded textile surface, not a rounded foam cuboid."""
    def point(u,v):
        x=1.046*u;y=-.153+.860*v
        side=max(0,(abs(u)-.865)/.135);front=max(0,(-v-.865)/.135)
        drop=.097*side**1.25+.089*front**1.2
        broad=.0045*math.sin(x*24+y*11)+.0031*math.sin(y*35-x*9)
        gathers=.0055*math.sin(x*71+y*18)*max(side,front)
        fine=.0011*math.sin(x*141+y*27)*math.sin(y*83-x*16)
        turnover=.008*math.exp(-((y-.452)/.026)**2)-.003*math.exp(-((y-.483)/.017)**2)
        return (x,y,.672-drop+broad+gathers+fine+turnover)
    nx=116;ny=94;vv=[];ff=[];uv=[]
    for j in range(ny+1):
        for i in range(nx+1):
            u=-1+2*i/nx;v=-1+2*j/ny;p=point(u,v);vv.append(p);uv.append((p[0],p[1]))
    for j in range(ny):
        for i in range(nx):q=j*(nx+1)+i;ff.append((q,q+1,q+nx+2,q+nx+1))
    ob=c.mesh('Soft silver duvet, real falling sides, corners and top fold',vv,ff,'belgravia_bedding',uv,True)
    solid=ob.modifiers.new('Layered cotton duvet fabric thickness','SOLIDIFY');solid.thickness=.003
    for side in range(4):
        points=[]
        for i in range(85):
            t=-1+2*i/84;u,v=[(-1,t),(1,t),(t,-1),(t,1)][side]
            p=point(u,v);points.append((p[0],p[1],p[2]+.0008))
        c.curve('Fine duvet perimeter stitched hem',points,.0012,'belgravia_bedding')

def bed(gold,relief):
    # Catalogue frame's exact bounds are completed by the low footboard and finials.
    width=2.230;depth=2.150;hx=1.037;rear=1.017
    for sign in (-1,1):
        tapered_leg('Bed front tapered white/burl foot',sign*1.055,-1.024,.224,.085)
        tapered_leg('Bed rear support foot',sign*1.020,.997,.180,.073)
        c.box('Long dark walnut side rail',(sign*1.062,-.023,.337),(.092,2.034,.145),'wood_dark',.004)
        c.box('White long side-rail border',(sign*1.109,-.023,.337),(.003,2.025,.100),'white',.001)
        gold.tube([(sign*1.113,-1.036,.288),(sign*1.113,.990,.288)],.0014,6)
    c.box('Internal bed slat bearer',(0,-.005,.310),(2.035,1.946,.055),'inside',.004)
    for i in range(15):c.box('Individual editable bed slat '+str(i+1),(0,-.91+i*.129,.350),(2.050,.081,.028),'inside',.002)
    c.box('Low white front footboard',(0,-1.032,.313),(2.220,.078,.151),'white',.003)
    c.box('Dark walnut broad footboard top rail',(0,-1.034,.407),(2.230,.082,.034),'wood_dark',.003)
    pyramids('Raised white diamond-pyramid footboard frieze',1.997,-1.073,.314,.105,gold)
    for sign in (-1,1):
        c.box('Footboard dark rosette corner block',(sign*1.061,-1.075,.314),(.073,.006,.129),'wood_dark',.001)
        rosette(gold,relief,(sign*1.061,-1.080,.315),.024)
    # Deep tufted high upholstered panel, not a flat damask rectangle.
    c.box('White structural headboard',(0,rear+.020,.853),(2.170,.075,.878),'white',.004)
    c.box('Headboard rear walnut figured inset',(0,rear+.059,.859),(2.016,.003,.775),'wood',.001)
    nx=130;nz=48;vv=[];ff=[];uv=[]
    def tuft(x,z):
        px=(x+1.0)/.177;pz=(z-.492)/.160
        # Alternate half-pitch button rows; diagonal lattice generates gathered diamonds.
        nearest=10
        for row in range(-1,7):
            cx=round(px-.5*(row%2))+.5*(row%2);d=((px-cx)**2+(pz-row)**2)**.5;nearest=min(nearest,d)
        depression=.025*math.exp(-(nearest/.145)**2)
        diamonds=(abs(math.sin(math.pi*(px+pz*.5)))*abs(math.sin(math.pi*(px-pz*.5))))**.5
        ripple=.0019*math.sin(x*165+z*54)*math.exp(-(nearest/.30)**2)
        return .950-.020*diamonds+depression+ripple
    for j in range(nz+1):
        z=.487+.699*j/nz
        for i in range(nx+1):
            x=-1.003+2.006*i/nx;vv.append((x,tuft(x,z),z));uv.append((x,z))
    for j in range(nz):
        for i in range(nx):q=j*(nx+1)+i;ff.append((q,q+nx+1,q+nx+2,q+1))
    panel=c.mesh('Real sculpted button-tufted cream damask headboard',vv,ff,'belgravia_damask',uv,True)
    solid=panel.modifiers.new('Upholstered panel solid thickness','SOLIDIFY');solid.thickness=.018
    for row in range(5):
        z=.492+row*.160
        for col in range(12):
            x=-1.0+(col+.5*(row%2))*.177
            if abs(x)>.98:continue
            c.sphere('Headboard recessed fabric button',(x,tuft(x,z)-.002,z),(.009,.004,.009),'belgravia_silk',12,8)
    c.box('White headboard pyramid frieze support',(0,rear,1.261),(2.165,.083,.132),'white',.002)
    pyramids('Raised white diamond-pyramid headboard frieze',2.018,rear-.044,1.261,.097,gold)
    c.box('Thick dark walnut headboard crown',(0,rear+.004,1.346),(2.230,.111,.037),'wood_dark',.003)
    for sign in (-1,1):
        column('Tall carved headboard column',sign*hx,rear-.011,.467,.784,gold,relief,.029)
        c.box('Headboard column square rosette capital',(sign*hx,rear-.028,1.268),(.076,.074,.076),'bronze',.002)
        rosette(gold,relief,(sign*hx,rear-.068,1.268),.023)
        finial('Bed cast pinecone finial',sign*hx,rear+.004,1.367,.073,gold,relief)
    styling=c.empty('Removable reference-inspired silver/ivory bed styling',props={'kind':'styling','not_a_separate_catalogue_sku':True,'construction_note':'Bedding is decorative interpretation, without maker logos.'})
    with parent(styling):
        cushion('Ivory covered mattress',(0,-.016,.463),(2.025,1.998,.230),'ivory',seat=True,n=24,softness=.30)
        draped_duvet()
        # Physically pleated low bed skirt, distinct from the fixed walnut structure.
        skirt=[];faces=[];uv=[];count=124
        for j in range(9):
            t=j/8;z=.050+.422*t
            for i in range(count+1):
                a=TAU*i/count;co=math.cos(a);si=math.sin(a);den=(abs(co)**8+abs(si)**8)**.125
                fold=.005*math.sin(a*52)*(1-.5*t)
                skirt.append(((1.012+fold)*co/den,-.012+(.999+fold)*si/den,z+.003*math.sin(a*39)*(1-t)));uv.append((i/count*6,z))
        for j in range(8):
            for i in range(count):q=j*(count+1)+i;faces.append((q,q+1,q+count+2,q+count+1))
        c.mesh('Fabric skirt with fine floor-length pleats',skirt,faces,'belgravia_silk',uv,True)
        for i,x in enumerate((-.65,0,.65)):
            cushion('Large ivory sleeping pillow '+str(i+1),(x,.670,.759),(.690,.158,.360),'ivory',rotation=(-.15,0,(-.035 if x<0 else .035)),n=22,phase=i)
        bolster=c.lathe('Long champagne rolled head bolster',(0,.774,.742),[(0,-.940),(.125,-.940),(.132,-.921),(.132,.921),(.125,.940),(0,.940)],'belgravia_silk',48);bolster.rotation_euler=(0,math.pi/2,0)
        for i,x in enumerate((-.465,.465)):
            cushion('Dusty rose decorative tufted pillow '+str(i+1),(x,.399,.750),(.522,.120,.329),'belgravia_pink',rotation=(-.14,0,(-.12 if x<0 else .12)),n=24,phase=i+2)
            for dx in (-.117,.117):c.sphere('Rose pillow inset fabric button',(x+dx,.329,.761),(.009,.004,.009),'belgravia_silk',12,8)

def bench(gold,relief):
    width=1.620;depth=.530
    frame_apron(width-.136,depth-.010,.231,.073,gold)
    for sign in (-1,1):
        for y in (-.211,.211):tapered_leg('Bench white/burl tapered foot',sign*.672,y,.202,.071)
    cushion('Striped low bench seat',(0,0,.366),(1.135,.514,.173),'belgravia_stripe',seat=True,n=26,phase=.7)
    # Thick, solid outward rolling end shells. The upper padded band really curls.
    for sign in (-1,1):
        path=[]
        for i in range(20):
            t=i/19;path.append((sign*(.535+.092*t),.408+.205*math.sin(t*math.pi/2)))
        for i in range(1,39):
            t=i/38;a=math.pi/2-math.pi*1.14*t;r=.103*(1-.18*t)
            path.append((sign*(.667+r*math.cos(a)),.590+r*math.sin(a)))
        vv=[];ff=[];uv=[]
        for j in range(19):
            y=-.250+.500*j/18
            for i,(x,z) in enumerate(path):
                vv.append((x,y,z+.002*math.sin(j*.8)*math.sin(math.pi*i/(len(path)-1))));uv.append((x,y))
        cols=len(path)
        for j in range(18):
            for i in range(cols-1):q=j*cols+i;ff.append((q,q+1,q+cols+1,q+cols))
        shell=c.mesh('Outward curled striped upholstered bench end',vv,ff,'belgravia_stripe',uv,True)
        solid=shell.modifiers.new('Real upholstered roll thickness','SOLIDIFY');solid.thickness=.045
        for y in (-.253,.253):
            # Dark walnut curved outer cheek is visible under the striped cap.
            pts=[(x,y,z-.026) for x,z in path]
            c.curve('Dark walnut curved rolled-end cheek',pts,.026,'wood')
            gold.tube([(x,y-.003 if y<0 else y+.003,z-.030) for x,z in path],.0014,6)
            rosette(gold,relief,(sign*.715,y-.031 if y<0 else y+.031,.570),.026,normal=(0,-1 if y<0 else 1,0))
        # White rising support carries the dark roll rather than floating upholstery.
        pts=[(sign*(.682-.035*math.sin(math.pi*t)),0,.264+.271*t) for t in [i/14 for i in range(15)]]
        for y in (-.223,.223):bent_member('White bench end rising support',[(x,y,z) for x,_,z in pts],.053,.049,'white')

def dressing_stool(gold,relief):
    # The printed name is STOOL, but the source shows an 800mm high-backed chair.
    cushion('Dressing chair upholstered seat',(0,-.025,.432),(.495,.482,.131),'belgravia_stool',seat=True,n=24,phase=1.2)
    cushion('Rounded high upholstered dressing-chair back',(0,.196,.618),(.472,.094,.364),'belgravia_stool',rotation=(-.105,0,0),n=28,phase=1.8,softness=.25)
    # Floor-length, closed pleated skirt makes no unsupported claim about hidden feet.
    vv=[];ff=[];uv=[];count=120;rows=18
    for j in range(rows+1):
        t=j/rows;z=.012+.387*t
        for i in range(count+1):
            a=TAU*i/count;co=math.cos(a);si=math.sin(a);den=(abs(co)**8+abs(si)**8)**.125
            # Eight deep tailored box pleats plus smaller woven undulations.
            fold=(.010*math.cos(a*12)+.0025*math.sin(a*45))*(1-.62*t)
            x=(.239+fold)*co/den;y=-.015+(.242+fold)*si/den
            vv.append((x,y,z+.0020*math.sin(a*23)*(1-t)));uv.append((i/count*1.9,z))
    for j in range(rows):
        for i in range(count):q=j*(count+1)+i;ff.append((q,q+1,q+count+2,q+count+1))
    c.mesh('Full-length pleated tailored vanity chair skirt',vv,ff,'belgravia_stool',uv,True)
    # Upholstered horizontal belt and antique nailheads in the reference rear view.
    belt=[]
    for i in range(81):
        a=TAU*i/80;co=math.cos(a);si=math.sin(a);den=(abs(co)**8+abs(si)**8)**.125
        belt.append((.247*co/den,-.015+.246*si/den,.403))
    c.curve('Dressing stool tailored waistband welt',belt,.007,'belgravia_silk',True)
    for i in range(30):
        a=TAU*i/30;co=math.cos(a);si=math.sin(a);den=(abs(co)**8+abs(si)**8)**.125
        relief.sphere((.250*co/den,-.015+.249*si/den,.402),(.0032,.0032,.0032),8,5)

def normalize(root,body,target):
    """Evaluate real vertices, convert cords, then floor-centre to catalogue bounds."""
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get()
    for ob in list(root.children_recursive):
        if ob.type!='CURVE':continue
        data=bpy.data.meshes.new_from_object(ob.evaluated_get(graph));result=bpy.data.objects.new(ob.name+' | editable cord mesh',data)
        bpy.context.scene.collection.objects.link(result);result.parent=ob.parent;result.matrix_basis=ob.matrix_basis.copy()
        for p in data.polygons:p.use_smooth=True
        old=ob.data;bpy.data.objects.remove(ob,do_unlink=True)
        if not old.users:bpy.data.curves.remove(old)
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get();inv=root.matrix_world.inverted();points=[]
    for ob in root.children_recursive:
        if ob.type=='MESH':
            ev=ob.evaluated_get(graph);points.extend(inv@ev.matrix_world@v.co for v in ev.data.vertices)
    lo=[min(p[k] for p in points) for k in range(3)];hi=[max(p[k] for p in points) for k in range(3)]
    scale=[target[k]/(hi[k]-lo[k]) for k in range(3)];body.scale=scale
    body.location=(-(lo[0]+hi[0])*scale[0]/2,-(lo[1]+hi[1])*scale[1]/2,-lo[2]*scale[2])
    root['catalogue_bounds_normalized']=True;root['normalization_scale']=scale
    root['construction_note']='Reference-based editable visual reconstruction; concealed construction interpreted; not manufacturer CAD.'
    bpy.context.view_layer.update()

def create(sku,instance='main'):
    sku=str(sku);width,depth,height,family,count,title=SPECS[sku];materials()
    printed='70-75' if family=='sofa' else '206-207, 262-265' if family=='chair' else '248-251'
    root=c.empty(f'{title} | {sku} | {instance}',props={
      'kind':'product','product_id':sku,'instance_id':instance,'name':title,
      'dimensions_mm':[round(v*1000) for v in (width,depth,height)],
      'catalogue_dimensions_mm':[round(v*1000) for v in (width,depth,height)],
      'catalogue_reference':'MARINER BELGRAVIA printed pages '+printed,
      'source_pdf':'CLASSIC_FURNITURE_CATALOG_2023.pdf','source_sha256':SOURCE_SHA256,
      'finish':'BEL. / OF (488 / 55)' if family!='stool' else 'BEL. (488)',
      'fabric_reference':'241.187 / 243.095' if family=='sofa' else '243.069' if family=='bed' else '241.188',
      'materials_declared':'Walnut burl veneer, white lacquer, sycamore marquetry, hand-carved wood columns and cast bronze ornaments',
      'mechanisms':'Fixed; no unsupported articulation','reference_authorship':'Authored reconstruction from user-supplied MARINER catalogue; no manufacturer affiliation.'})
    if family=='sofa':
        root['seat_count']=count;root['seat_cushions']=count
        root['source_image_note']='50037.0 has no separately isolated photograph; proportions reconstructed to its separately printed1500mm width using50036.0 family photograph.' if count==2 else 'Separate ivory damask source photographs; blue event-installation variant is not the principal finish.'
    if sku=='50035.0':root['dimension_note']='Catalogue prints470mm width for both chair and armchair; overall470mm retained including arms, not silently corrected.'
    if family=='stool':root['form_note']='Printed STOOL; reference visibly shows800mm high upholstered back and full-length pleated skirt. Reconstructed as shown, not backless.'
    with parent(root):body=c.empty('Exact metric editable Belgravia upholstered geometry')
    with parent(body):
        gold=Batch('Fine cast gilt edging, beads, turned collars and solid flutes','gold')
        relief=Batch('Individual bronze acanthus leaves, rosettes and pinecone scales','antique_gold')
        if family=='sofa':sofa(width,depth,height,count,gold,relief)
        elif family=='chair':dining_chair(bool(count),gold,relief)
        elif family=='bed':bed(gold,relief)
        elif family=='bench':bench(gold,relief)
        else:dressing_stool(gold,relief)
        gold.finish();relief.finish()
    normalize(root,body,(width,depth,height))
    return root
