"""Reopen native BELGRAVIA residence and check real evaluated product geometry."""
import bpy,json,sys,math,hashlib
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent
scene=bpy.context.scene;assert scene.get('collection')=='BELGRAVIA'
roots=[o for o in scene.objects if o.get('kind')=='product']
source=json.loads((BASE/'reference/products.json').read_text(encoding='utf8'));expected={p['sku']:p for p in source['products']}
assert set(o['product_id'] for o in roots)==set(expected) and len(expected)==22
assert scene.get('walls') and scene.get('roof') and scene.get('layout')=='furnished-interior'
assert not [o for o in scene.objects if o.get('kind')=='articulation']
info=json.loads(scene['web_scene_info']);assert len(info['placements'])==len(roots)
rebuild_hashes=json.loads(scene['rebuild_source_sha256'])
for name,digest in rebuild_hashes.items():assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==digest,('Native scene uses outdated source',name)
assert len(info['rooms'])==6 and info['defaultRoom']=='living' and info['colliders']
audit=[];dg=bpy.context.evaluated_depsgraph_get()
for root in roots:
    points=[];triangles=0
    for obj in root.children_recursive:
        if obj.type not in {'MESH','CURVE'}:continue
        e=obj.evaluated_get(dg);data=e.to_mesh();data.calc_loop_triangles();triangles+=len(data.loop_triangles)
        matrix=root.matrix_world.inverted()@obj.matrix_world
        points.extend(matrix@v.co for v in data.vertices);e.to_mesh_clear()
    dims=[(max(v[a] for v in points)-min(v[a] for v in points))*1000 for a in range(3)]
    target=expected[root['product_id']]['dimensions_mm'];delta=[abs(a-b) for a,b in zip(dims,target)]
    assert max(delta)<=3,(root.name,dims,target)
    assert triangles>3000,(root.name,triangles)
    audit.append({'sku':root['product_id'],'instance':root['instance_id'],'catalogue_mm':target,'geometry_mm':[round(d,3) for d in dims],'max_error_mm':round(max(delta),3),'triangles':triangles})
images=[i for i in bpy.data.images if i.source=='FILE' and i.type=='IMAGE']
assert len(images)>=6 and all(i.packed_file or i.packed_files for i in images)
cameras=[o for o in scene.objects if o.type=='CAMERA'];assert len(cameras)==11
shells=[o for o in scene.objects if o.get('kind')=='architectural-surface'];assert len(shells)>=10
assert all(not o.hide_render for o in shells)
report={'ok':True,'scene':bpy.data.filepath,'uniqueSKUs':len(expected),'placements':len(roots),'unsupportedMovingParts':0,'packedImages':len(images),'cameras':len(cameras),'walls':True,'roof':True,'layout':'furnished-interior','architecturalGroups':len(shells),'resolution':[scene.render.resolution_x,scene.render.resolution_y],'bounds':audit,'rebuildSourceSHA256':rebuild_hashes,'sourcePDFSHA256':source['source_pdf_sha256'],'materials':'Authored procedural catalogue interpretations, not certified manufacturer CAD/material samples'}
(BASE/'native-audit.json').write_text(json.dumps(report,indent=2));print('BELGRAVIA_NATIVE_AUDIT',json.dumps({k:v for k,v in report.items() if k!='bounds'}),flush=True)
