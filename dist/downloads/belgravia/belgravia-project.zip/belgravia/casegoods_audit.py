"""Run with Blender --background --threads 4 --python casegoods_audit.py.

Builds and audits all fourteen unique products; optional one-pass native
contact sheet via --render (no simultaneous background render processes).
"""
import sys
import math
import json
import hashlib
from pathlib import Path
import bpy
from mathutils import Vector

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import core as c
import casegoods as cg

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
c.materials()
records = []
roots = []
for i, (sku, (name, dims)) in enumerate(cg.SPECS.items()):
    root = cg.create(sku)
    roots.append(root)
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    meshes = [o for o in root.children_recursive if o.type == 'MESH']
    low, high = Vector((float('inf'),)*3), Vector((-float('inf'),)*3)
    tris = 0
    finite = True
    uv = True
    invalid = []
    for ob in meshes:
        ev = ob.evaluated_get(dg)
        mesh = ev.to_mesh()
        mesh.calc_loop_triangles()
        tris += len(mesh.loop_triangles)
        for vertex in mesh.vertices:
            p = ev.matrix_world @ vertex.co
            if not all(math.isfinite(v) for v in p):
                finite = False
            for k in range(3):
                low[k] = min(low[k], p[k])
                high[k] = max(high[k], p[k])
        if not mesh.uv_layers:
            uv = False
            invalid.append(ob.name)
        for layer in mesh.uv_layers:
            if any(not all(math.isfinite(v) for v in point.uv) for point in layer.data):
                finite = False
        ev.to_mesh_clear()
    measured = [(high[k]-low[k])*1000 for k in range(3)]
    delta = [abs(measured[k]-dims[k]) for k in range(3)]
    row = dict(sku=sku, name=name, dimensions_mm=dims, evaluated_dimensions_mm=measured,
               delta_mm=delta, max_delta_mm=max(delta), min_z_mm=low.z*1000,
               center_xy_mm=[(high[k]+low[k])*500 for k in (0, 1)],
               meshes=len(meshes), triangles=tris, finite=finite, uv_present=uv,
               missing_uv_objects=invalid, envelope_fit_scale=list(root['envelope_fit_scale']))
    records.append(row)
    print('CASEGOODS', sku, 'delta', round(max(delta), 6), 'mm', tris, 'triangles', flush=True)
    assert max(delta) <= 3, row
    assert abs(low.z*1000) < 1e-3, row
    assert finite and uv, row
    # Small products are raised only in QA display, never in exported origins.
    root.location = ((i % 4-1.5)*3.25, (i//4-1.5)*3.15, 0)
    if sku in ('50061.0', '50032.0', '50047.0'):
        root.location.z = .58
report = dict(collection='Belgravia', unique_casegoods=len(records),
              source_sha256=hashlib.sha256((BASE/'casegoods.py').read_bytes()).hexdigest(),
              total_triangles=sum(r['triangles'] for r in records),
              source='MARINER CLASSIC_FURNITURE_CATALOG_2023.pdf | supplied local reference',
              scope='Native geometry before web simplification. No mechanisms are animated.',
              products=records)
(BASE/'casegoods-audit.json').write_text(json.dumps(report, indent=2), encoding='utf8')
print('AUDIT_OK', report['total_triangles'], 'total triangles', flush=True)
if '--render' in sys.argv:
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 16
    scene.cycles.use_denoising = True
    scene.render.threads_mode = 'FIXED'
    scene.render.threads = 4
    scene.render.resolution_x = 1900
    scene.render.resolution_y = 1900
    scene.render.resolution_percentage = 100
    scene.world.color = (.25, .25, .25)
    c.set_parent(None)
    c.box('Neutral QA floor', (0, 0, -.04), (20, 20, .07), 'plinth', .004)
    c.light('Large softbox left', 'AREA', (-8, -9, 13), 2100, (1, .91, .79), (0, 0, .8), 8)
    c.light('Large fill right', 'AREA', (9, -1, 11), 1600, (.86, .92, 1), (0, 0, .8), 7)
    data = bpy.data.cameras.new('Casegoods QA camera')
    camera = bpy.data.objects.new('Casegoods QA camera', data)
    scene.collection.objects.link(camera)
    camera.location = (9, -19, 22)
    camera.rotation_euler = (Vector((0, 0, .3))-camera.location).to_track_quat('-Z', 'Y').to_euler()
    data.type = 'ORTHO'
    data.ortho_scale = 16.8
    scene.camera = camera
    scene.render.image_settings.file_format = 'PNG'
    scene.render.filepath = str(BASE/'casegoods-contactsheet.png')
    bpy.ops.render.render(write_still=True)
