"""BELGRAVIA casegoods: independent editable, metric catalogue reconstruction.

MARINER CLASSIC_FURNITURE_CATALOG_2023.pdf, PDF 37--38, 103--105,
126 and 133. Walnut burl / white lacquer / sycamore marquetry, carved
gilt columns and bronze ornaments, BEL./OF (488/55). The portrait mirror
50061.0 is the separately photographed ornate POE (380) gold finish.

create(sku, instance='main') returns an EMPTY. X width, Y depth, front -Y,
Z up. Floor centre, or bottom centre for mirrors. Geometry is authored from
the photographs, not manufacturer CAD: hidden construction and exact floral
castings are interpretations. No photo planes or invented animated joints.
"""
import math
from contextlib import contextmanager
import bpy
from mathutils import Vector
import core as c

TAU = math.tau
SPECS = {
    '50061.0': ('Belgravia ornate gilt portrait mirror', (940, 90, 1380)),
    '50050.0': ('Belgravia carved-column console', (1490, 450, 830)),
    '50039.0': ('Belgravia square coffee table', (1160, 1160, 480)),
    '50040.0': ('Belgravia round pedestal side table', (680, 680, 650)),
    '50194.0': ('Belgravia television furniture', (2200, 500, 760)),
    '50031.0': ('Belgravia twin-pedestal dining table', (2460, 1320, 760)),
    '50043.0': ('Belgravia six-column dining table', (2460, 1320, 760)),
    '50032.0': ('Belgravia landscape dining mirror', (2120, 60, 1070)),
    '50028.0': ('Belgravia two-door three-drawer sideboard', (2220, 530, 910)),
    '50033.0': ('Belgravia glazed display cabinet', (1540, 510, 2100)),
    '50045.0': ('Belgravia drawer-and-door night table', (720, 450, 750)),
    '50047.0': ('Belgravia dressing mirror', (1300, 60, 1060)),
    '50046.0': ('Belgravia two-pedestal dressing table', (1820, 520, 780)),
    '50051.0': ('Belgravia writing desk', (1720, 800, 790)),
}


@contextmanager
def parent_to(ob):
    previous = c.PARENT
    c.set_parent(ob)
    try:
        yield
    finally:
        c.set_parent(previous)


def bezier(a, b, d, e, steps=18):
    return [tuple((1-t)**3*a[k]+3*(1-t)**2*t*b[k]+3*(1-t)*t*t*d[k]+t**3*e[k]
                  for k in range(len(a))) for t in [j/steps for j in range(steps+1)]]


class Relief:
    """Batched real stems, gilt pearls, carved ridged leaves and castings."""
    def __init__(self):
        self.data = {}

    def part(self, mat):
        return self.data.setdefault(mat, [[], []])

    def tube(self, points, radius, mat='gold', sides=6, closed=False):
        points = [Vector(p) for p in points]
        if len(points) < 2:
            return
        if closed:
            points.append(points[0])
        verts, faces = self.part(mat)
        base, old_u = len(verts), None
        for j, p in enumerate(points):
            t = points[min(j+1, len(points)-1)]-points[max(j-1, 0)]
            if t.length < 1e-8:
                t = Vector((0, 0, 1))
            t.normalize()
            ref = Vector((0, 0, 1)) if abs(t.z) < .94 else Vector((1, 0, 0))
            u = t.cross(ref).normalized()
            if old_u is not None and old_u.dot(u) < 0:
                u.negate()
            v, old_u = t.cross(u).normalized(), u
            for k in range(sides):
                a = TAU*k/sides
                verts.append(tuple(p+radius*(u*math.cos(a)+v*math.sin(a))))
        for j in range(len(points)-1):
            for k in range(sides):
                q, r = base+j*sides+k, base+j*sides+(k+1) % sides
                faces.append((q, r, r+sides, q+sides))
        faces.append(tuple(base+k for k in reversed(range(sides))))
        last = base+(len(points)-1)*sides
        faces.append(tuple(last+k for k in range(sides)))

    def bead(self, pos, radius, mat='gold', seg=7, rings=4):
        verts, faces = self.part(mat)
        base = len(verts)
        for j in range(rings+1):
            t = math.pi*j/rings
            for k in range(seg):
                a = TAU*k/seg
                verts.append((pos[0]+radius*math.sin(t)*math.cos(a),
                              pos[1]+radius*math.sin(t)*math.sin(a),
                              pos[2]+radius*math.cos(t)))
        for j in range(rings):
            for k in range(seg):
                q, r = base+j*seg+k, base+j*seg+(k+1) % seg
                faces.append((q, r, r+seg, q+seg))

    def leaf(self, mapping, path, width=.009, mat='gold', depth=.003):
        # A closed leaf has a raised central ridge, rolled tips and a fine vein.
        verts, faces = self.part(mat)
        base, n = len(verts), len(path)
        for rear in (False, True):
            for j, (u, v) in enumerate(path):
                t = j/(n-1)
                a, b = path[max(j-1, 0)], path[min(j+1, n-1)]
                dx, dy = b[0]-a[0], b[1]-a[1]
                length = max(1e-9, math.hypot(dx, dy))
                spread = max(.00005, width*math.sin(math.pi*t)**.8)
                for k in range(3):
                    s = k-1
                    r = -.00015 if rear else depth*(1-.65*s*s)*math.sin(math.pi*t)+.0002
                    verts.append(mapping(u-s*dy/length*spread, v+s*dx/length*spread, r))
        for j in range(n-1):
            for k in range(2):
                q = base+j*3+k
                faces.extend([(q, q+3, q+4, q+1), (q+3*n+1, q+3*n+4, q+3*n+3, q+3*n)])
            q = base+j*3
            faces.extend([(q, q+3*n, q+3*n+3, q+3), (q+2, q+5, q+3*n+5, q+3*n+2)])
        faces.append(tuple(base+k for k in (0, 1, 2, 3*n+2, 3*n+1, 3*n)))
        q = base+3*(n-1)
        faces.append(tuple(q+k for k in (0, 3*n, 3*n+1, 3*n+2, 2, 1)))
        self.tube([mapping(u, v, depth*math.sin(math.pi*j/(n-1))+.0007)
                   for j, (u, v) in enumerate(path)], .0005, mat, 4)

    def finish(self, name):
        return [c.mesh(name+' | '+mat, verts, faces, mat, smooth=mat != 'white')
                for mat, (verts, faces) in self.data.items() if verts]


def rect(w, d, r=.003, steps=3):
    pts = []
    for x, y, a0 in ((w/2-r, d/2-r, 0), (-w/2+r, d/2-r, math.pi/2),
                     (-w/2+r, -d/2+r, math.pi), (w/2-r, -d/2+r, 3*math.pi/2)):
        for j in range(steps+1):
            a = a0+j*math.pi/(2*steps)
            pts.append((x+r*math.cos(a), y+r*math.sin(a)))
    return pts


def circle(r, steps=112):
    return [(r*math.cos(TAU*j/steps), r*math.sin(TAU*j/steps)) for j in range(steps)]


def prism(name, path, z0, z1, mat, bevel=.001):
    edge = min(bevel, (z1-z0)*.24)
    w, d = 2*max(abs(x) for x, y in path), 2*max(abs(y) for x, y in path)
    rings = [(1-2*edge/w, 1-2*edge/d, z0), (1, 1, z0+edge),
             (1, 1, z1-edge), (1-2*edge/w, 1-2*edge/d, z1)]
    verts = [(x*sx, y*sy, z) for sx, sy, z in rings for x, y in path]
    n, faces = len(path), []
    for j in range(3):
        for k in range(n):
            faces.append((j*n+k, j*n+(k+1) % n, (j+1)*n+(k+1) % n, (j+1)*n+k))
    faces.extend([tuple(reversed(range(n))), tuple(3*n+k for k in range(n))])
    return c.mesh(name, verts, faces, mat)


def f_map(x, y, z):
    return lambda u, v, r: (x+u, y-r, z+v)


def s_map(x, y, z, sign=1):
    return lambda u, v, r: (x+sign*r, y+u, z+v)


def h_map(x, y, z):
    return lambda u, v, r: (x+u, y+v, z+r)


def outline(rel, mapping, w, h, radius=.0012, mat='gold'):
    rel.tube([mapping(u, v, 0) for u, v in rect(w, h, min(.003, w/8, h/8))], radius, mat, 5, True)


def rosette(rel, mapping, radius=.018, petals=12):
    for k in range(petals):
        a = TAU*k/petals
        path = [(radius*t*math.cos(a+.18*math.sin(math.pi*t)),
                 radius*t*math.sin(a+.18*math.sin(math.pi*t))) for t in (0, .2, .4, .6, .8, 1)]
        rel.leaf(mapping, path, radius*.20, 'gold', radius*.20)
    for rr in (radius*.29, radius*1.03):
        rel.tube([mapping(rr*math.cos(TAU*k/32), rr*math.sin(TAU*k/32), .001)
                  for k in range(32)], .0009, 'antique_gold', 5, True)
    rel.bead(mapping(0, 0, .004), radius*.17, 'bronze')


def pearl_line(rel, a, b, pitch=.008, radius=.0017, mat='gold'):
    a, b = Vector(a), Vector(b)
    n = max(2, round((b-a).length/pitch))
    for j in range(n+1):
        rel.bead(a+(b-a)*j/n, radius, mat, 6, 3)


def diamond_band(rel, mapping, length, height, pitch=.063):
    """The conspicuous real ivory pyramid frieze, never a flat normal map."""
    n = max(2, round(length/pitch))
    cell = length/n
    verts, faces = rel.part('white')
    for j in range(n):
        u, q = -length/2+j*cell, len(verts)
        for v, z, r in ((u, -height/2, 0), (u+cell, -height/2, 0),
                        (u+cell, height/2, 0), (u, height/2, 0),
                        (u+cell/2, 0, min(.012, height*.19))):
            verts.append(mapping(v, z, r))
        faces.extend([(q, q+1, q+4), (q+1, q+2, q+4), (q+2, q+3, q+4), (q+3, q, q+4)])
    for z in (-height/2-.004, height/2+.004):
        rel.tube([mapping(-length/2, z, .001), mapping(length/2, z, .001)], .0017, 'gold', 6)
        pearl_line(rel, mapping(-length/2, z, .002), mapping(length/2, z, .002), .007, .0013)


def laurel_torches(rel, mapping, w=.22, h=.30, mat='inlay'):
    """Physical sycamore-leaf wreath, tied bow and three classical torches."""
    scale = min(w/.22, h/.30)
    def mp(u, v, r):
        return mapping(u*scale, v*scale, r*.35)
    for sign in (-1, 1):
        stem = [(sign*(.017+.070*math.sin(t*math.pi*.84)), -.115+t*.235) for t in [j/26 for j in range(27)]]
        rel.tube([mp(u, v, .0005) for u, v in stem], .0010*scale, mat, 5)
        for j in range(8):
            t = .12+j*.105
            u, v = sign*(.017+.070*math.sin(t*math.pi*.84)), -.115+t*.235
            for outward in (-1, 1):
                leafpath = bezier((u, v), (u+sign*outward*.012, v+.004),
                                  (u+sign*outward*.023, v+.014), (u+sign*outward*.027, v+.028), 5)
                rel.leaf(mp, leafpath, .0058, mat, .0012)
    for k in (-1, 0, 1):
        dx = k*.022
        path = [(dx*(1-t)*1.7, -.147+t*.26) for t in [j/12 for j in range(13)]]
        rel.tube([mp(u, v, .0015) for u, v in path], .0018*scale, mat, 5)
        for yy, ww in ((.082, .016), (.099, .012), (.116, .009)):
            rel.tube([mp(dx-ww, yy, .002), mp(dx+ww, yy, .002)], .0011*scale, mat, 5)
        for ss in (-1, 0, 1):
            rel.leaf(mp, [(dx+ss*.006, .112), (dx+ss*.010, .126), (dx+ss*.007, .140)], .0032, mat, .0015)
    for sign in (-1, 1):
        rel.tube([mp(sign*.026*math.sin(math.pi*t), -.047+.020*math.sin(TAU*t), .003)
                  for t in [j/28 for j in range(29)]], .0012*scale, mat, 5, True)
        rel.tube([mp(0, -.046, .003), mp(sign*.024, -.072, .003), mp(sign*.016, -.088, .003)], .0012*scale, mat, 5)


def fluted_column(rel, x, y, h, radius=.042, z0=0, short=False):
    """Hand-carved gilt column: tapered flutes, acanthus, square rosette cap."""
    if short:
        c.lathe('Carved gilt short foot', (x, y, z0),
                [(0, 0), (.014, 0), (.018, .008), (.024, h*.46), (.028, h*.68),
                 (.023, h*.83), (.030, h), (0, h)], 'gold', 32)
        for k in range(8):
            a = TAU*k/8
            mp = lambda u, v, r, a=a: (x+(.023+r)*math.cos(a)+u*math.sin(a),
                                        y+(.023+r)*math.sin(a)-u*math.cos(a), z0+v)
            rel.leaf(mp, [(.0, h*.13), (.004, h*.30), (.003, h*.52), (0, h*.78)], .0045, 'gold', .003)
        return
    c.lathe('Turned and tapered gilt column', (x, y, z0),
            [(0, 0), (radius*.33, 0), (radius*.42, .007), (radius*.36, h*.09),
             (radius*.48, h*.36), (radius*.59, h*.53), (radius*.85, h*.69),
             (radius*.91, h*.73), (radius*.57, h*.77), (radius*.66, h*.80),
             (radius*.96, h*.84), (radius*.96, h*.86), (radius*.68, h*.88),
             (radius*.70, h*.94), (radius*1.12, h*.97), (radius*1.12, h), (0, h)], 'gold', 40)
    for k in range(10):
        a = TAU*k/10
        rel.tube([(x+radius*(.37+.20*t)*math.cos(a), y+radius*(.37+.20*t)*math.sin(a), z0+h*(.07+.47*t))
                  for t in [j/10 for j in range(11)]], .0018, 'antique_gold', 5)
    for k in range(8):
        a = TAU*k/8
        mp = lambda u, v, r, a=a: (x+(radius*.80+r)*math.cos(a)+u*math.sin(a),
                                    y+(radius*.80+r)*math.sin(a)-u*math.cos(a), z0+v)
        rel.leaf(mp, [(.0, h*.48), (.004, h*.55), (-.003, h*.63), (.0, h*.74)], radius*.17, 'gold', radius*.12)
        rel.tube([mp(radius*.14*math.sin(t*math.pi*2), h*(.52+.22*t), .002)
                  for t in [j/18 for j in range(19)]], .0012, 'bronze', 5)
    bh = h*.085
    c.box('Square column collar with gilt flower blocks', (x, y, z0+h*.875), (radius*1.85, radius*1.85, bh), 'antique_gold', .001)
    for axis in range(4):
        a = axis*math.pi/2
        mp = lambda u, v, r, a=a: (x+(radius*.94+r)*math.sin(a)+u*math.cos(a),
                                    y-(radius*.94+r)*math.cos(a)+u*math.sin(a), z0+h*.875+v)
        rosette(rel, mp, min(bh*.36, radius*.47), 9)
    # Leafy Ionic capital is below the apron, rather than a generic metal pole.
    for k in range(12):
        a = TAU*k/12
        mp = lambda u, v, r, a=a: (x+(radius*1.04+r)*math.cos(a)+u*math.sin(a),
                                    y+(radius*1.04+r)*math.sin(a)-u*math.cos(a), z0+v)
        rel.leaf(mp, [(0, h*.954), (.003, h*.981), (0, h*1.005)], radius*.13, 'gold', .003)
    for zz, rr in ((.012, radius*.41), (h*.80, radius*.67), (h*.945, radius*.73)):
        rel.tube([(x+rr*math.cos(TAU*k/36), y+rr*math.sin(TAU*k/36), z0+zz) for k in range(36)], .0015, 'gold', 6, True)


def stepped_outline(w, d, step=.05):
    # Small relieved corners, visible on both dining-table designs.
    a, b, s = w/2, d/2, step
    return [(a, b-s), (a-s*.4, b-s), (a-s*.4, b), (-a+s*.4, b),
            (-a+s*.4, b-s), (-a, b-s), (-a, -b+s), (-a+s*.4, -b+s),
            (-a+s*.4, -b), (a-s*.4, -b), (a-s*.4, -b+s), (a, -b+s)]


def table_top(rel, w, d, h, dining=False, writing=False):
    path = stepped_outline(w, d) if dining else rect(w, d, .006)
    prism('Glossy walnut-burl solid tabletop with eased edges', path, h-.028, h, 'wood', .0018)
    lower = [(x*(w-.010)/w, y*(d-.010)/d) for x, y in path]
    prism('Dark thin shadow line beneath top', lower, h-.034, h-.026, 'wood_dark', .0006)
    if writing:
        if 'bel_writing' not in c.M:
            c.M['bel_writing'] = c.material('BELGRAVIA | dark leather writing inset', (.025, .020, .014), .49, 0)
            bs = c.M['bel_writing'].node_tree.nodes['Principled BSDF']
            noise = c.M['bel_writing'].node_tree.nodes.new('ShaderNodeTexNoise')
            noise.inputs['Scale'].default_value = 380
            bump = c.M['bel_writing'].node_tree.nodes.new('ShaderNodeBump')
            bump.inputs['Strength'].default_value = .18
            bump.inputs['Distance'].default_value = .00016
            c.M['bel_writing'].node_tree.links.new(noise.outputs['Fac'], bump.inputs['Height'])
            c.M['bel_writing'].node_tree.links.new(bump.outputs['Normal'], bs.inputs['Normal'])
        prism('Inset dark writing surface', rect(w-.17, d-.14), h-.001, h+.0004, 'bel_writing', .0002)
    for inset, mat, rr in ((.027, 'ivory', .0037), (.033, 'gold', .0008), (.048, 'ivory', .0011)):
        rel.tube([(x*(w-2*inset)/w, y*(d-2*inset)/d, h-.0012) for x, y in path], rr, mat, 6, True)
    if dining:
        for x in (-w*.25, w*.25):
            laurel_torches(rel, h_map(x, 0, h-.0005), .20, .28)


def table_apron(rel, w, d, h, fh=.092, corner=.088, writing=False):
    z = h-.031-fh/2
    for sign in (-1, 1):
        y = sign*(d/2-.020)
        c.box('White lacquer diamond-apron long rail', (0, y-sign*.010, z), (w-.018, .038, fh), 'white', .001)
        mp = lambda u, v, r, y=y, sign=sign: (u, y+sign*(r+.011), z+v)
        if writing and sign == 1:
            # Catalogue office-room photo shows a three-panel reverse face,
            # while the isolated product photograph shows diamonds at the front.
            length, gap = w-2*corner-.012, .012
            panelw = (length-2*gap)/3
            for j in (-1, 0, 1):
                xx = j*(panelw+gap)
                c.box('Desk reverse-face fixed walnut drawer panel',
                      (xx, y+sign*.012, z), (panelw, .008, fh-.024), 'wood', .0006)
                outline(rel, lambda u, v, r, xx=xx: mp(u+xx, v, r+.006), panelw+.003, fh-.020, .0010, 'ivory')
                if j:
                    # Two outer ring pulls are visible; the central face has none.
                    rel.tube([mp(xx+.011*math.cos(TAU*k/32), -.003+.011*math.sin(TAU*k/32), .012)
                              for k in range(32)], .0018, 'gold', 6, True)
        else:
            diamond_band(rel, mp, w-2*corner, fh-.026)
        for x in (-w/2+corner/2+.004, w/2-corner/2-.004):
            c.box('Walnut-burl apron end block', (x, y+sign*.010, z), (corner-.013, .007, fh-.014), 'wood', .0005)
            outline(rel, lambda u, v, r, x=x: mp(u+x, v, r+.003), corner-.016, fh-.015, .0010)
            if not writing:
                rosette(rel, lambda u, v, r, x=x: mp(u+x, v, r+.006), min(.018, fh*.23))
    for sign in (-1, 1):
        x = sign*(w/2-.020)
        c.box('White lacquer diamond-apron short rail', (x-sign*.010, 0, z), (.038, d-.018, fh), 'white', .001)
        mp = lambda u, v, r, x=x, sign=sign: (x+sign*(r+.011), u, z+v)
        if writing:
            c.box('Desk side apron walnut-burl inset', (x+sign*.011, 0, z),
                  (.008, d-2*corner-.006, fh-.025), 'wood', .0005)
            outline(rel, lambda u, v, r: mp(u, v, r+.006), d-2*corner-.003, fh-.022, .001, 'ivory')
        else:
            diamond_band(rel, mp, d-2*corner, fh-.026)
        for y in (-d/2+corner/2+.004, d/2-corner/2-.004):
            if not writing:
                rosette(rel, lambda u, v, r, y=y: mp(u+y, v, r+.003), min(.018, fh*.23))


def leg_table(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    rel = Relief()
    dining, console, desk = sku == '50043.0', sku == '50050.0', sku == '50051.0'
    fh = .096 if dining or desk else .087
    leg_h = h-.030-fh+.006
    xs = (-w/2+.082, 0, w/2-.082) if dining else (-w/2+.067, w/2-.067)
    ys = (-d/2+.069, d/2-.069)
    for x in xs:
        for y in ys:
            fluted_column(rel, x, y, leg_h, .042 if dining or desk or console else .039)
    table_apron(rel, w-.010, d-.010, h, fh, writing=desk)
    table_top(rel, w, d, h, dining, desk)
    if console:
        # Photographed walnut stretcher is open in the centre, not a solid shelf.
        a, b = w/2-.067, d/2-.069
        path = bezier((-a, -b), (-a+.20, -.01), (-a+.20, b), (-a, b), 22)
        path += bezier((-a, b), (-a*.35, b+.004), (a*.35, b+.004), (a, b), 24)[1:]
        path += bezier((a, b), (a-.20, b), (a-.20, -.01), (a, -b), 22)[1:]
        # A broad, flattened, curved timber rail: real gap inside the loop.
        verts, faces = [], []
        for j, (x, y) in enumerate(path):
            dx = path[min(j+1, len(path)-1)][0]-path[max(j-1, 0)][0]
            dy = path[min(j+1, len(path)-1)][1]-path[max(j-1, 0)][1]
            n = max(1e-8, math.hypot(dx, dy))
            for z, side in ((.028, -1), (.028, 1), (.052, 1), (.052, -1)):
                verts.append((x-dy/n*.027*side, y+dx/n*.027*side, z))
        for j in range(len(path)-1):
            for k in range(4):
                faces.append((j*4+k, j*4+(k+1) % 4, (j+1)*4+(k+1) % 4, (j+1)*4+k))
        faces.extend([(3, 2, 1, 0), tuple((len(path)-1)*4+k for k in range(4))])
        c.mesh('Open curved lower console stretcher', verts, faces, 'wood')
        rel.tube([(x, y, .052) for x, y in path], .0016, 'gold', 5)
    rel.finish(SPECS[sku][0]+' physical carved details')


def round_table():
    w, d, h = [v/1000 for v in SPECS['50040.0'][1]]
    rel = Relief()
    c.lathe('Circular walnut-burl pedestal base', (0, 0, 0),
            [(0, 0), (.184, 0), (.191, .008), (.191, .034), (.180, .044), (0, .044)], 'wood', 112)
    c.lathe('Tapered dark figured pedestal', (0, 0, 0),
            [(0, .035), (.069, .035), (.065, .068), (.049, .18), (.041, .40), (.047, .545),
             (.059, .558), (0, .558)], 'wood', 64)
    c.lathe('Gilt gadrooned pedestal foot collar', (0, 0, 0),
            [(0, .043), (.088, .043), (.096, .050), (.087, .060), (.074, .075), (.064, .082), (0, .082)], 'gold', 64)
    for k in range(36):
        a = TAU*k/36
        rel.tube([((.090-.025*t)*math.cos(a), (.090-.025*t)*math.sin(a), .050+.029*t)
                  for t in [j/8 for j in range(9)]], .0014, 'antique_gold', 5)
    c.lathe('Solid dark burl circular tabletop and apron', (0, 0, 0),
            [(0, h-.092), (.325, h-.092), (.331, h-.084), (.331, h-.023), (.340, h-.018),
             (.340, h-.004), (.336, h), (0, h)], 'wood', 112)
    for zz, rr, tube, mat in ((h-.086, .331, .0024, 'ivory'), (h-.029, .331, .0028, 'ivory'),
                              (h-.0022, .286, .0052, 'ivory'), (h-.0022, .278, .0011, 'gold')):
        rel.tube([(rr*math.cos(TAU*k/112), rr*math.sin(TAU*k/112), zz) for k in range(112)], tube, mat, 6, True)
    for k in range(4):
        a = TAU*k/4
        mp = lambda u, v, r, a=a: ((.333+r)*math.sin(a)+u*math.cos(a),
                                    -(.333+r)*math.cos(a)+u*math.sin(a), h-.057+v)
        outline(rel, mp, .049, .049, .001, 'ivory')
        rosette(rel, mp, .014, 10)
    rel.finish('Round pedestal table gilt moulding and collar ribs')


def pedestal_table():
    w, d, h = [v/1000 for v in SPECS['50031.0'][1]]
    rel = Relief()
    for x in (-.69, .69):
        # Four outward arched feet per pedestal, each terminating in bronze toes.
        for k in range(4):
            a = math.pi/4+k*math.pi/2
            direction = Vector((math.cos(a), math.sin(a), 0))
            path = [(x+direction.x*r, direction.y*r, z) for r, z in
                    ((.07, .24), (.16, .235), (.24, .19), (.31, .10), (.39, .057), (.43, .047))]
            # Swept rectangular carved ivory bracket, width tapers at the toe.
            verts, faces = [], []
            side = Vector((-direction.y, direction.x, 0))
            for j, p in enumerate(path):
                width = .066-j*.004
                for ss, zz in ((-1, -.025), (1, -.025), (1, .025), (-1, .025)):
                    verts.append(tuple(Vector(p)+side*ss*width/2+Vector((0, 0, zz))))
            for j in range(len(path)-1):
                for q in range(4):
                    faces.append((j*4+q, j*4+(q+1) % 4, (j+1)*4+(q+1) % 4, (j+1)*4+q))
            faces.extend([(3, 2, 1, 0), tuple((len(path)-1)*4+q for q in range(4))])
            c.mesh('Arched ivory pedestal foot', verts, faces, 'white')
            end = Vector(path[-1])
            c.sphere('Bronze claw foot', (end.x, end.y, .039), (.041, .041, .039), 'gold', 20, 10)
            for off in (-.020, -.007, .007, .020):
                toe = end+side*off+direction*.022
                rel.tube([(toe.x, toe.y, .018), (toe.x+direction.x*.010, toe.y+direction.y*.010, .038),
                          (toe.x, toe.y, .061)], .0034, 'antique_gold', 6)
            for off in (-.016, 0, .016):
                rel.tube([tuple(Vector(p)+side*off+Vector((0, 0, .026))) for p in path], .0013, 'gold', 5)
        # White framed, tapered square burl shaft with a broad gilt plinth.
        z0, z1 = .215, h-.127
        c.box('Square white pedestal socket', (x, 0, .238), (.288, .288, .096), 'white', .002)
        for z, size in ((.192, .300), (.278, .279)):
            prism('Gold pedestal plinth moulding', rect(size, size), z, z+.008, 'gold', .001).location.x = x
        verts = [(x+xx*s, yy*s, z) for z, s in ((.278, .245), (z1, .176))
                 for xx, yy in ((-.5, -.5), (.5, -.5), (.5, .5), (-.5, .5))]
        c.mesh('Tapered walnut-burl pedestal', verts, [(0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                                                       (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)], 'wood')
        for k in range(4):
            a = math.pi/4+k*math.pi/2
            rel.tube([(x+s*.7071*math.cos(a), s*.7071*math.sin(a), z) for z, s in
                      ((.282, .245), (z1-.003, .176))], .0052, 'ivory', 6)
        for sign in (-1, 1):
            rosette(rel, f_map(x, sign*.146, .238) if sign == -1 else
                    (lambda u, v, r, x=x: (x+u, .146+r, .238+v)), .020, 10)
    table_apron(rel, w-.010, d-.010, h, .098)
    table_top(rel, w, d, h, True)
    rel.finish('Twin pedestal dining table physical marquetry and castings')


def drawer_pull(rel, x, y, z, r=.012):
    rel.bead((x, y+.002, z), r*.76, 'bronze', 12, 6)
    rel.tube([(x+r*math.cos(TAU*k/36), y-.007, z-r*.42+r*math.sin(TAU*k/36))
              for k in range(36)], .0019, 'gold', 6, True)


def framed_panel(rel, x, y, z0, z1, w, marquetry=False, drawer=False):
    h, z = z1-z0, (z0+z1)/2
    c.box('Individual white lacquer drawer front' if drawer else 'Individual white lacquer door panel',
          (x, y+.010, z), (w, .032, h), 'white', .001)
    pw, ph = w-.070, h-.064
    c.box('Inset bookmatched walnut-burl panel', (x, y-.007, z), (pw, .007, ph), 'wood', .0006)
    outline(rel, f_map(x, y-.011, z), pw+.002, ph+.002, .0010, 'gold')
    if marquetry:
        laurel_torches(rel, f_map(x, y-.012, z), min(.23, pw*.67), min(.35, ph*.80))
    if drawer:
        for px in (x-w*.33, x+w*.33):
            drawer_pull(rel, px, y-.015, z, .012)
    else:
        c.box('Small fixed brass key escutcheon', (x+w/2-.012, y-.008, z+.027), (.004, .002, .010), 'bronze', .0004)


def side_panel(rel, w, d, z0, z1, ox=0):
    z, h = (z0+z1)/2, z1-z0
    for sign in (-1, 1):
        x = ox+sign*(w/2-.007)
        c.box('Burl inset side panel in lacquer surround', (x, .005, z), (.010, d-.110, h-.065), 'wood', .0006)
        outline(rel, s_map(x+sign*.006, .005, z, sign), d-.109, h-.064, .0009)


def shell(w, d, z0, z1, ox=0, back='inside'):
    # Real thickness and an unfilled internal storage volume, even for fixed doors.
    t = .023
    for sign in (-1, 1):
        c.box('White lacquer cabinet side', (ox+sign*(w/2-t/2), 0, (z0+z1)/2), (t, d, z1-z0), 'white', .0007)
    c.box('Actual timber case back', (ox, d/2-.012, (z0+z1)/2), (w-2*t, .024, z1-z0), back, .0005)
    for z in (z0+t/2, z1-t/2):
        c.box('Solid case floor or ceiling', (ox, 0, z), (w-.023, d-.018, t), 'inside', .0006)


def cabinet_edges(rel, w, d, h, foot=.12, columns=True, ox=0, apron=True):
    bodytop = h-.029
    fy = -d/2+.021
    for x in (ox-w/2+.052, ox+w/2-.052):
        for y in (-d/2+.046, d/2-.046):
            fluted_column(rel, x, y, foot, .030, short=True)
    # Contrasting dark rails at the base and at the square posts.
    c.box('Continuous dark burl lower rail', (ox, 0, foot+.019), (w-.007, d-.008, .040), 'wood', .0012)
    if columns:
        for x in (ox-w/2+.046, ox+w/2-.046):
            fluted_column(rel, x, fy-.003, bodytop-foot-.055, .036, foot+.047)
    else:
        for x in (ox-w/2+.031, ox+w/2-.031):
            c.box('White lacquer front stile', (x, fy+.007, (foot+bodytop)/2), (.062, .043, bodytop-foot), 'white', .0007)
            c.box('Slim burl front stile inset', (x, fy-.017, (foot+bodytop)/2-.014), (.024, .006, bodytop-foot-.065), 'wood', .0005)
            for z in (foot+.076, bodytop-.065):
                rosette(rel, f_map(x, fy-.023, z), .012, 10)
    if apron:
        ah = .074
        zz = bodytop-ah/2-.008
        c.box('Ivory upper case apron', (ox, fy+.012, zz), (w-.068, .043, ah), 'white', .0007)
        diamond_band(rel, f_map(ox, fy-.012, zz), w-.158, ah-.018)
    c.box('Bookmatched walnut-burl case top', (ox, 0, h-.0145), (w, d, .029), 'wood', .0018)
    rel.tube([(x+ox, y, h-.028) for x, y in rect(w-.008, d-.008)], .0011, 'gold', 5, True)


def sideboard():
    w, d, h = [v/1000 for v in SPECS['50028.0'][1]]
    rel = Relief()
    foot, z0, z1 = .123, .168, h-.125
    shell(w-.024, d-.031, foot+.032, h-.030)
    side_panel(rel, w-.018, d-.020, z0, z1)
    cabinet_edges(rel, w, d, h, foot)
    fy = -d/2+.007
    center_w, outer_w = .804, .578
    for sign in (-1, 1):
        x = sign*(center_w/2+outer_w/2+.012)
        framed_panel(rel, x, fy, z0+.005, z1, outer_w, True)
        c.box('Interior shelf behind fixed door', (x, 0, .43), (outer_w-.018, d-.09, .019), 'inside', .0006)
    for j in range(3):
        zh = (z1-z0)/3
        framed_panel(rel, 0, fy-.002, z0+j*zh+.002, z0+(j+1)*zh-.003, center_w, False, True)
    for x in (-center_w/2-.007, center_w/2+.007):
        c.box('Burl vertical division between drawers and doors', (x, fy+.016, (z0+z1)/2), (.022, .032, z1-z0), 'wood', .0005)
    rel.finish('Sideboard physical faceted apron, marquetry and castings')


def tv_furniture():
    w, d, h = [v/1000 for v in SPECS['50194.0'][1]]
    rel = Relief()
    # Photograph shows a nearly floor-standing white plinth, not raised columns.
    c.box('Floor-standing white TV plinth', (0, 0, .024), (w-.016, d-.012, .048), 'white', .0012)
    c.box('Narrow figured lower rail', (0, -d/2+.023, .048), (w-.060, .016, .034), 'wood', .0005)
    shell(w-.022, d-.023, .059, h-.032, back='white')
    side_panel(rel, w-.016, d-.022, .081, h-.118)
    fy, pw, cw = -d/2+.008, .526, 1.006
    for sign in (-1, 1):
        x = sign*(cw/2+pw/2+.006)
        framed_panel(rel, x, fy, .071, h-.139, pw, True)
    for x in (-cw/2-.008, cw/2+.008):
        c.box('Open bay vertical partition', (x, -.005, .352), (.024, d-.062, .574), 'white', .0006)
    c.box('True open media-bay single shelf', (0, -.002, .335), (cw, d-.066, .020), 'white', .001)
    zz = h-.081
    c.box('White faceted TV fascia', (0, fy+.012, zz), (w-.070, .039, .083), 'white', .0006)
    diamond_band(rel, f_map(0, fy-.010, zz), w-.168, .058)
    for x in (-w/2+.036, w/2-.036):
        c.box('Burl corner stile inset', (x, fy-.004, .377), (.026, .007, .523), 'wood', .0004)
        for z in (.059, h-.077):
            rosette(rel, f_map(x, fy-.013, z), .014, 10)
    c.box('Polished walnut-burl television top', (0, 0, h-.0145), (w, d, .029), 'wood', .0017)
    rel.finish('TV furniture dimensional frieze, inlays and bronze fittings')


def night_table():
    w, d, h = [v/1000 for v in SPECS['50045.0'][1]]
    rel = Relief()
    foot = .104
    shell(w-.020, d-.025, foot+.031, h-.029)
    side_panel(rel, w-.013, d-.022, foot+.060, h-.047)
    cabinet_edges(rel, w, d, h, foot, False, apron=False)
    fy, pw = -d/2+.010, w-.126
    framed_panel(rel, 0, fy, foot+.064, h-.175, pw, False)
    framed_panel(rel, 0, fy-.001, h-.163, h-.052, pw, False, True)
    rel.finish('Night table physical borders, ring pulls and carved feet')


def vanity():
    w, d, h = [v/1000 for v in SPECS['50046.0'][1]]
    rel = Relief()
    pw, foot = .588, .109
    fy = -d/2+.010
    for sign in (-1, 1):
        ox = sign*(w/2-pw/2+.003)
        shell(pw-.017, d-.020, foot+.031, h-.029, ox)
        side_panel(rel, pw-.011, d-.022, foot+.065, h-.052, ox)
        # Each pedestal has four discrete feet; original photo exposes rear feet.
        for x in (ox-pw/2+.045, ox+pw/2-.045):
            for y in (-d/2+.045, d/2-.045):
                fluted_column(rel, x, y, foot, .027, short=True)
        c.box('Burl vanity pedestal lower rail', (ox, 0, foot+.018), (pw, d-.006, .036), 'wood', .001)
        framed_panel(rel, ox, fy, foot+.060, h-.176, pw-.101, True)
        # The photograph shows one faceted upper drawer on each side.
        c.box('Individual ivory vanity top drawer', (ox, fy+.010, h-.105), (pw-.101, .033, .108), 'white', .0008)
        diamond_band(rel, f_map(ox, fy-.008, h-.105), pw-.133, .069)
        drawer_pull(rel, ox, fy-.019, h-.105, .010)
        # Carved front outer column is full-height; inner knee stile is plain burl.
        colx = sign*(w/2-.044)
        fluted_column(rel, colx, fy-.002, h-foot-.065, .032, foot+.044)
        inx = ox-sign*(pw/2-.020)
        c.box('Burl inner knee-space stile', (inx, fy+.012, .43), (.038, .030, .615), 'wood', .0005)
    knee = w-2*pw-.022
    c.box('Vanity central open knee-space rear modesty rail', (0, d/2-.022, h-.108), (knee+.022, .030, .154), 'white', .001)
    c.box('Slim central apron above open knee space', (0, fy+.022, h-.064), (knee+.026, .035, .062), 'white', .001)
    c.box('Single continuous walnut-burl vanity top', (0, 0, h-.014), (w, d, .028), 'wood', .0017)
    rel.finish('Vanity carved columns, marquetry, raised diamonds and ring pulls')


def display_cabinet():
    w, d, h = [v/1000 for v in SPECS['50033.0'][1]]
    rel = Relief()
    foot, lower_top = .122, .785
    shell(w-.033, d-.030, foot+.036, lower_top-.024)
    side_panel(rel, w-.020, d-.024, foot+.067, lower_top-.125)
    fy = -d/2+.009
    for x in (-w/2+.052, w/2-.052):
        for y in (-d/2+.047, d/2-.047):
            fluted_column(rel, x, y, foot, .029, short=True)
        fluted_column(rel, x, fy-.001, lower_top-foot-.064, .036, foot+.043)
    c.box('Dark walnut cabinet lower rail', (0, 0, foot+.020), (w-.009, d-.010, .040), 'wood', .001)
    for sign in (-1, 1):
        framed_panel(rel, sign*.338, fy, foot+.065, lower_top-.120, .655, True)
    c.box('White diamond fascia beneath glazed upper case', (0, fy+.013, lower_top-.068), (w-.102, .039, .079), 'white', .001)
    diamond_band(rel, f_map(0, fy-.009, lower_top-.068), w-.184, .055)
    c.box('Walnut lower/upper case separation ledge', (0, 0, lower_top-.013), (w, d, .026), 'wood', .0015)
    # Upper display section: visibly transparent panes, two clear glass shelves.
    uz0, uz1 = lower_top+.011, h-.030
    inner_w = w-.180
    c.box('Ivory display-cabinet solid back', (0, d/2-.023, (uz0+uz1)/2), (w-.071, .025, uz1-uz0), 'white', .001)
    c.box('Display-cabinet upper solid ceiling', (0, 0, uz1-.012), (w-.025, d-.020, .024), 'white', .0008)
    c.box('Display-case floor', (0, 0, uz0+.013), (w-.042, d-.028, .026), 'white', .0008)
    for sign in (-1, 1):
        x = sign*(w/2-.040)
        # Independent upper corner pillars leave the side central glazing open.
        for yy in (-d/2+.042, d/2-.041):
            c.box('Upper glazed-case ivory corner pillar', (x, yy, (uz0+uz1)/2), (.067, .066, uz1-uz0), 'white', .001)
        pane_x = sign*(w/2-.031)
        c.box('Actual transparent side glass panel', (pane_x, 0, (uz0+uz1)/2), (.006, d-.152, uz1-uz0-.116), 'glass', .0002)
        # The front upper pilaster is burl with gilt outline and a cast flower.
        c.box('Long upper walnut-burl corner pilaster', (x, fy-.011, (uz0+uz1)/2), (.036, .008, uz1-uz0-.043), 'wood', .0005)
        outline(rel, f_map(x, fy-.016, (uz0+uz1)/2), .041, uz1-uz0-.031, .0010)
        rosette(rel, f_map(x, fy-.018, uz1-.085), .017, 12)
    door_w = inner_w/2-.004
    for sign in (-1, 1):
        x = sign*(door_w/2+.004)
        dh, cz = uz1-uz0-.026, (uz0+uz1)/2
        fw, bottom = .043, .051
        for sx in (-1, 1):
            c.box('Independent glazed-door white vertical frame', (x+sx*(door_w/2-fw/2), fy+.008, cz), (fw, .033, dh), 'white', .001)
        for zz in (cz-dh/2+bottom/2, cz+dh/2-bottom/2):
            c.box('Independent glazed-door white horizontal frame', (x, fy+.008, zz), (door_w, .033, bottom), 'white', .001)
        c.box('Real clear front display-door glass', (x, fy+.010, cz), (door_w-2*fw+.004, .006, dh-2*bottom+.004), 'glass', .0002)
        outline(rel, f_map(x, fy-.010, cz), door_w-2*fw+.004, dh-2*bottom+.004, .0015, 'gold')
        # Individual physical hinges and small handles, fixed, not animated.
        for zz in (uz0+.22, uz1-.22):
            c.box('Visible fixed bronze hinge', (x+sign*(door_w/2-.007), fy-.010, zz), (.008, .007, .020), 'bronze', .0008)
        drawer_pull(rel, sign*.021, fy-.016, cz-.030, .007)
    for z in (1.185, 1.615):
        c.box('Actual clear interior glass shelf', (0, .005, z), (inner_w+.012, d-.102, .009), 'glass', .0003)
        for x in (-inner_w/2, inner_w/2):
            for yy in (-d/2+.082, d/2-.062):
                c.box('Small bronze shelf support', (x, yy, z-.009), (.010, .014, .010), 'brass', .0007)
    c.box('Glossy walnut cabinet crown', (0, 0, h-.014), (w, d, .028), 'wood', .0016)
    rel.tube([(x, y, h-.027) for x, y in rect(w-.007, d-.007)], .0012, 'gold', 5, True)
    rel.finish('Glazed cabinet physical gold trim, laurel inlay and cast column details')


def landscape_mirror(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    rel = Relief()
    # Back board only behind the mirror plane; front is an open frame plus glass.
    c.box('Mirror backing board', (0, d/2-.010, h/2), (w-.014, .020, h-.014), 'wood_dark', .0006)
    fx, fy = .074, -d/2+.012
    for sign in (-1, 1):
        xx = sign*(w/2-fx/2-.003)
        c.box('White lacquer mirror vertical surround', (xx, .001, h/2), (fx, d-.006, h-.020), 'white', .001)
        c.box('Burl inset mirror-side vertical strip', (xx, fy-.003, h/2-.012), (.026, .008, h-.096), 'wood', .0006)
        outline(rel, f_map(xx, fy-.009, h/2-.012), .032, h-.090, .001)
        rosette(rel, f_map(xx, fy-.010, h-.089), .014, 10)
    for zz in (.012, h-.012):
        c.box('Dark walnut mirror top or bottom edge', (0, 0, zz), (w, d, .024), 'wood', .0012)
    ah, az = .078, h-.073
    c.box('White dimensional mirror crown frieze', (0, .001, az), (w-.142, d-.012, ah), 'white', .0008)
    diamond_band(rel, f_map(0, fy-.009, az), w-.178, ah-.022)
    opening_w, opening_h = w-.156, h-.144
    cz = .032+opening_h/2
    c.box('Actual reflective glass mirror surface', (0, fy+.011, cz), (opening_w, .005, opening_h), 'mirror', .0005)
    # A thin four-sided bevel catches the light around the reflective opening.
    outline(rel, f_map(0, fy+.006, cz), opening_w+.001, opening_h+.001, .0025, 'gold')
    outline(rel, f_map(0, fy+.008, cz), opening_w-.008, opening_h-.008, .0011, 'ivory')
    pearl_line(rel, (-w/2+.004, fy-.004, .025), (w/2-.004, fy-.004, .025), .008, .0015)
    rel.finish('Mirror real faceted diamonds, gilt border and corner rosettes')


def ornate_mirror():
    """50061.0: POE380 antique gilt, oval aperture inside an ornate rectangle."""
    w, d, h = [v/1000 for v in SPECS['50061.0'][1]]
    rel = Relief()
    fw, fh, basez = .858, 1.148, .008
    cy, cz = .018, basez+fh/2
    # Broad gold frame with a true oval central aperture, rather than a solid box.
    rx, rz = .316, .457
    outer = []
    for j in range(144):
        a = TAU*j/144
        dx, dz = math.cos(a), math.sin(a)
        length = min(fw/2/max(abs(dx), 1e-8), fh/2/max(abs(dz), 1e-8))
        outer.append((length*dx, cz+length*dz))
    inner = [(rx*math.cos(TAU*j/144), cz+rz*math.sin(TAU*j/144)) for j in range(144)]
    verts, faces = [], []
    for y in (-.008, .042):
        verts += [(x, y, z) for x, z in outer]+[(x, y, z) for x, z in inner]
    n = 144
    for j in range(n):
        k = (j+1) % n
        faces.extend([(j, k, n+k, n+j), (2*n+j, 3*n+j, 3*n+k, 2*n+k),
                      (j, 2*n+j, 2*n+k, k), (n+j, n+k, 3*n+k, 3*n+j)])
    c.mesh('Actual antique gilt frame with oval opening', verts, faces, 'antique_gold')
    # Elliptical reflective sheet and a substantial stepped, beaded oval rim.
    v = [(0, .005, cz)]+[(rx*.992*math.cos(TAU*j/144), .005, cz+rz*.992*math.sin(TAU*j/144)) for j in range(144)]
    c.mesh('Real oval mirror glass', v, [(0, 1+j, 1+(j+1) % 144) for j in range(144)], 'mirror')
    for sx, sz, yy, rr, mat in ((rx+.004, rz+.004, -.012, .0042, 'gold'),
                               (rx+.013, rz+.014, -.012, .0030, 'bronze'),
                               (rx+.021, rz+.024, -.012, .0036, 'gold')):
        rel.tube([(sx*math.cos(TAU*j/144), yy, cz+sz*math.sin(TAU*j/144)) for j in range(144)], rr, mat, 7, True)
    for j in range(180):
        a = TAU*j/180
        rel.bead(((rx+.012)*math.cos(a), -.017, cz+(rz+.013)*math.sin(a)), .0017, 'gold', 6, 3)
    for inset, rr, yy in ((.005, .0055, -.012), (.022, .0034, -.015), (.041, .0023, -.013)):
        rel.tube([(x, yy, z+cz) for x, z in rect(fw-2*inset, fh-2*inset, .004)], rr, 'gold', 7, True)
    # Raised corner cross-blocks, heavily foliated with curling Rococo scrolls.
    for sx in (-1, 1):
        for sz in (-1, 1):
            xx, zz = sx*.377, cz+sz*.485
            c.box('Raised antique-gold frame corner block', (xx, .002, zz), (.178, .066, .182), 'antique_gold', .002)
            mp = f_map(xx, -.034, zz)
            rosette(rel, mp, .041, 12)
            for ss in (-1, 1):
                pts = [(ss*(.018+.051*t)*math.cos(TAU*t*1.18), (.018+.051*t)*math.sin(TAU*t*1.18)) for t in [j/45 for j in range(46)]]
                rel.tube([mp(u, v, .001) for u, v in pts], .0043, 'gold', 6)
                for k in range(5):
                    a = .35+k*.68
                    start = (ss*.038*math.cos(a), .040*math.sin(a))
                    end = (ss*(.055+.013*k)*math.cos(a+.45), (.052+.004*k)*math.sin(a+.45))
                    rel.leaf(mp, bezier(start, (start[0]*1.2, start[1]*1.2), end, end, 7), .008, 'gold', .005)
    # Four smaller spandrel acanthus groups sit outside the oval, inside frame.
    for sx in (-1, 1):
        for sz in (-1, 1):
            mp = f_map(sx*.256, -.016, cz+sz*.405)
            for k in range(4):
                a = k*.55
                path = bezier((0, 0), (sx*.019, sz*.010),
                              (sx*(.038+a*.008), sz*(.024+a*.019)),
                              (sx*(.046+a*.011), sz*(.048+a*.017)), 8)
                rel.leaf(mp, path, .009, 'gold', .006)
    # Crest: open wreath, rising palmette, draped foliate scrolls and side fans.
    zc = 1.206
    mp = f_map(0, -.014, zc)
    rel.tube([mp(.071*math.cos(TAU*j/84), .071*math.sin(TAU*j/84), .001) for j in range(84)], .006, 'gold', 8, True)
    for sign in (-1, 1):
        pts = bezier((sign*.030, -.020), (sign*.105, -.091), (sign*.236, -.045), (sign*.241, -.077), 26)
        rel.tube([mp(u, v, .002) for u, v in pts], .0048, 'gold', 7)
        for j in range(8):
            u, v = sign*(.058+j*.022), -.050-.016*math.sin(j*.7)
            rel.leaf(mp, bezier((u, v), (u+sign*.018, v+.008), (u+sign*.017, v+.029), (u+sign*.005, v+.041), 7), .010, 'gold', .006)
        for j in range(6):
            a = -.4+j*.25
            rel.leaf(mp, bezier((sign*.025, .062), (sign*.045, .085),
                                (sign*(.041+.035*math.sin(a)), .113+.014*j),
                                (sign*(.016+.052*math.sin(a)), .128+.011*(5-j)), 8), .010, 'gold', .006)
    rosette(rel, f_map(0, -.021, zc-.015), .027, 10)
    # Repeated fine foliate runners on the long frame members.
    for sign in (-1, 1):
        xx = sign*.394
        for j in range(20):
            zz = .207+j*.035
            mp = f_map(xx, -.016, zz)
            rel.leaf(mp, [(0, -.014), (sign*.010, -.004), (sign*.012, .007), (0, .016)], .0055, 'gold', .004)
    rel.finish('POE380 portrait mirror high-relief Rococo scrolls and palmette crest')


def fit_metric(root, dimensions):
    """Fit the authored relief-inclusive envelope to the published metric size.

    This small final manufacturing envelope adjustment includes projecting
    handles and castings, rather than claiming only an unornamented case size.
    The root remains identity scale and every mesh stays directly editable.
    """
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    items = [o for o in root.children_recursive if o.type in {'MESH', 'CURVE'}]
    inv = root.matrix_world.inverted()
    points = [inv @ o.matrix_world @ Vector(p) for o in items for p in o.evaluated_get(dg).bound_box]
    lo = Vector([min(p[k] for p in points) for k in range(3)])
    hi = Vector([max(p[k] for p in points) for k in range(3)])
    size = hi-lo
    factors = Vector([dimensions[k]/1000/size[k] for k in range(3)])
    center = Vector(((lo.x+hi.x)/2, (lo.y+hi.y)/2, lo.z))
    root['envelope_fit_scale'] = list(factors)
    for o in items:
        o.location = Vector([(o.location[k]-center[k])*factors[k] for k in range(3)])
        o.scale = Vector([o.scale[k]*factors[k] for k in range(3)])
    bpy.context.view_layer.update()


def create(sku, instance='main'):
    sku = str(sku)
    if sku not in SPECS:
        raise ValueError('Unknown Belgravia casegoods SKU: '+sku)
    name, dimensions = SPECS[sku]
    root = c.empty(name+' | '+str(instance), props={
        'kind': 'product', 'product_id': sku, 'instance_id': str(instance),
        'dimensions_mm': list(dimensions), 'collection': 'Belgravia',
        'source': 'MARINER CLASSIC_FURNITURE_CATALOG_2023.pdf | PDF 37-38,103-105,126,133',
        'moving_parts': 0,
        'reconstruction_note': 'Independent visual reconstruction from catalogue photographs, not manufacturer CAD. Hidden joinery and exact carving/inlay motifs interpreted; finishes are not calibrated physical samples.',
        'origin_note': 'Floor-centred; mirrors bottom-centred for separate wall mounting.',
    })
    if sku == '50033.0':
        root['shelf_count'], root['display_levels'], root['glazed_side_panels'] = 2, 3, True
    if sku == '50043.0':
        root['leg_count'] = 6
    if sku == '50031.0':
        root['pedestal_count'], root['claw_feet_per_pedestal'] = 2, 4
    if sku == '50061.0':
        root['catalogue_finish'] = 'POE (380), ornate gold; not BEL./OF white lacquer family'
    if sku == '50194.0':
        root['open_media_bay_shelf_count'] = 1
    with parent_to(root):
        if sku in ('50050.0', '50039.0', '50043.0', '50051.0'):
            leg_table(sku)
        elif sku == '50040.0':
            round_table()
        elif sku == '50031.0':
            pedestal_table()
        elif sku in ('50032.0', '50047.0'):
            landscape_mirror(sku)
        elif sku == '50061.0':
            ornate_mirror()
        elif sku == '50028.0':
            sideboard()
        elif sku == '50194.0':
            tv_furniture()
        elif sku == '50045.0':
            night_table()
        elif sku == '50046.0':
            vanity()
        elif sku == '50033.0':
            display_cabinet()
    fit_metric(root, dimensions)
    return root
