# BELGRAVIA — editable furnished interiors

22 unique MARINER classic catalogue references; 36 placed instances in four
fully enclosed connected rooms. Native geometry and packed authored PBR maps.
Original source images are preserved separately with hashes and native sizes.
Source PDF pages36–39,102–105,125–126,132–133. Source rights remain with owners.

Blender5.2LTS, metres, product width/depth/height from printed millimetres.
Front=-Y, Z=up. Mirrors use a bottom-centre origin. Bound validation includes
ornaments, handles and soft furnishings. Storage is static, not unverified
working drawer/door hardware. Catalogue width470mm for the dining armchair is
preserved as printed, not independently certified. The high-back stool height
is800mm overall. Two-seat sofa imagery is a disclosed shared family reference.
The50061 mirror uses the special POE380 finish.

Architecture, connected plan, unseen joinery, exact textile motifs and finish
calibration are interpretations, not certified manufacturer CAD. Room-tour
walls and ceilings remain complete; only the labelled overview is a cutaway.
No AI images are used in place of native renders or original catalogue images.

Rebuild (run with Blender from this folder):

    blender --background --python build_scene.py
    blender --background belgravia-interior.blend --python validate_native.py
    blender --background belgravia-interior.blend --python export_web.py
    node scripts/render_verified.mjs
    python prepare_assets.py

Extraction/packaging uses PyMuPDF; geometry/textures use Blender's NumPy. The
extraction script documents the original user-supplied catalogue location.
Packaging expects the workspace site; export falls back to web-export outside
that workspace. render_verified.mjs declares this workstation's Blender path;
adjust that executable path when rebuilding elsewhere. The native master is
configured for Cycles128samples. Delivered room PNGs are genuine3840×2160
EEVEE renders (64samples, raytracing), plus three1600² details. No upscaling.
The runner rejects shadow-pool exhaustion and records settings per camera.
Full-detail product inspectors preserve source geometry; repeated room models
use a decimated product-only LOD. Browser reflections differ from Blender.

Website and3D visualisation by Muhammad Rizky. Visible data/file requests open
the shared English WhatsApp draft. Public static assets are not access control.
