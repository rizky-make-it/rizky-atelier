"""Preserve the complete original BELGRAVIA living/dining/bedroom/office evidence."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / '.local/catalogue-review/packages'))
import pymupdf as fitz

SOURCE = Path('C:/Users/Admin/Downloads/CLASSIC_FURNITURE_CATALOG_2023.pdf')
DEST = ROOT / 'output/belgravia/reference'
ORIGINALS = DEST / 'originals'
PRODUCTS = DEST / 'catalogue'
DETAILS = DEST / 'details'
for folder in [DEST, ORIGINALS, PRODUCTS, DETAILS]:
    folder.mkdir(parents=True, exist_ok=True)
PAGE_NUMBERS = [36,37,38,39,102,103,104,105,125,126,132,133]
doc = fitz.open(SOURCE)
pages = []
for pdf_page in PAGE_NUMBERS:
    page = doc[pdf_page-1]
    scale = 2400/page.rect.width
    image_path = DEST/f'page-{pdf_page:03}.jpg'
    page.get_pixmap(matrix=fitz.Matrix(scale,scale), alpha=False).save(image_path,jpg_quality=96)
    for image in page.get_image_info(xrefs=True):
        if image.get('xref'):
            original = doc.extract_image(image['xref'])
            (ORIGINALS/f'page-{pdf_page:03}-xref-{image["xref"]}.{original["ext"]}').write_bytes(original['image'])
    pages.append({'pdf_page':pdf_page, 'rect_pdf_points':list(page.rect),
                  'text':page.get_text(sort=True), 'text_blocks':page.get_text('blocks'),
                  'images':page.get_image_info(xrefs=True), 'preview':image_path.name})
report = {'source':str(SOURCE), 'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'page_count':len(doc), 'metadata':doc.metadata,
          'image_classification':'Original catalogue image; not independently verified product photography',
          'pages':pages}
(DEST/'catalogue-evidence.json').write_text(json.dumps(report,indent=2,
    default=lambda value:value.hex() if isinstance(value,bytes) else str(value)),encoding='utf8')
print('PREVIEWS_READY', DEST, flush=True)

def source_rect(pdf_page, xref, rect_pixels):
    info = next(i for i in doc[pdf_page-1].get_image_info(xrefs=True) if i['xref']==xref)
    x0,y0,x1,y1 = rect_pixels
    transform = fitz.Matrix(info['transform'])
    points = [fitz.Point(x/info['width'],y/info['height'])*transform for x,y in [(x0,y0),(x1,y0),(x0,y1),(x1,y1)]]
    return [min(p.x for p in points),min(p.y for p in points),max(p.x for p in points),max(p.y for p in points)]

def preserve_image(pdf_page, xref, destination, crop=None):
    original = doc.extract_image(xref)
    source_path = ORIGINALS/f'page-{pdf_page:03}-xref-{xref}.{original["ext"]}'
    source_path.write_bytes(original['image'])
    info = next(i for i in doc[pdf_page-1].get_image_info(xrefs=True) if i['xref']==xref)
    smask = next((i[1] for i in doc[pdf_page-1].get_images(full=True) if i[0]==xref),0)
    pixels = crop or [0,0,original['width'],original['height']]
    mirrored = info['transform'][0] < 0 and info['transform'][3] > 0
    evidence = {'source_pdf_page':pdf_page,'source_image_xref':xref,
                'source_native_pixels':[original['width'],original['height']],
                'crop_rect_native_pixels':pixels,'crop_rect_pdf_points':source_rect(pdf_page,xref,pixels),
                'source_image_file':source_path.relative_to(DEST).as_posix(),
                'source_image_sha256':hashlib.sha256(original['image']).hexdigest(),
                'source_image_to_pdf_transform':list(info['transform']),
                'source_pdf_horizontal_mirror':mirrored,
                'orientation_note':'Original embedded image orientation retained; the source PDF displays this image horizontally mirrored.' if mirrored else 'Original embedded image orientation matches the source PDF display.',
                'file':destination.relative_to(DEST).as_posix()}
    if crop or smask:
        composite = fitz.open()
        page = composite.new_page(width=original['width'],height=original['height'])
        if smask:
            mask = doc.extract_image(smask)
            mask_path = ORIGINALS/f'page-{pdf_page:03}-mask-{smask}.{mask["ext"]}'
            mask_path.write_bytes(mask['image'])
            page.insert_image(page.rect,stream=original['image'],mask=mask['image'])
            evidence.update({'source_soft_mask_xref':smask,'source_soft_mask_file':mask_path.relative_to(DEST).as_posix(),
                             'source_soft_mask_sha256':hashlib.sha256(mask['image']).hexdigest()})
        else:
            page.insert_image(page.rect,stream=original['image'])
        pixmap = page.get_pixmap(clip=fitz.Rect(pixels),alpha=False)
        pixmap.save(destination,jpg_quality=96)
        evidence['output_pixels'] = [pixmap.width,pixmap.height]
        evidence['transformation'] = ('Native-density rectangular crop; ' if crop else '') + ('original embedded JPEG with its original PDF soft mask faithfully composited over the original white page background; no new segmentation, upscaling or subject alteration' if smask else 'original embedded JPEG rendered at native pixel density; no upscaling or subject alteration')
        composite.close()
    else:
        destination.write_bytes(original['image'])
        evidence['output_pixels'] = [original['width'],original['height']]
        evidence['transformation'] = 'Exact original embedded JPEG bytes, no resizing or visual modification'
    evidence['sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
    return evidence

if '--previews-only' in sys.argv:
    doc.close()
    raise SystemExit(0)

COMMON = ['Polished deep brown walnut-burl veneer combined with warm white lacquer',
          'Fine pale sycamore inlay borders and gold beaded edge mouldings',
          'White raised pyramid-diamond apron band on principal tables and selected rails',
          'Carved gold acanthus columns and cast-bronze foliate or rosette accents']
SEATING = ['High straight upper back with sloping inward-curved shoulders down to the arms',
           'Cream-white damask upholstery with large pale floral medallions',
           'Gold interlocking beaded upper/side frame, white outer frame and dark burl lower apron insets',
           'Gold centre crest on a dark rectangular top plaque and two small corner finials',
           'Rolled front arm ends with round gold rosettes over tall gold acanthus front uprights',
           'Short tapered white legs with dark burl front insets; no long gold table-style legs']
CARVED_LEGS = ['Gold carved column legs with Ionic-scroll capitals, square floral blocks, acanthus/fluted shafts and tapered lower toes']
definitions = [
 {'sku':'50036.0','name':'Belgravia Three-seat Sofa','type':'Sofa','room':'Living room',
  'dimensions_mm':[2210,800,1130],'weight_kg':53,'source_pdf_page':37,'xref':200,
  'fabric_codes':['241.187','243.095'],'fabric_statement':'Suggested Fabric: 241.187 / 243.095',
  'visible_details':SEATING+['Three individual seat cushions, two square pale pillows and two round end bolsters','Additional centre support beneath the long front rail'],
  'imageShared':True,'imageSharedWith':['50037.0'],
  'reference_note':'Original isolated three-seat photograph also serves as explicitly disclosed family evidence for separately dimensioned two-seat50037.0. No isolated two-seat image appears in these source pages. Original lifestyle view on PDF36 confirms white upholstery; navy installation on PDF39 is a separately preserved alternate styling reference.'},
 {'sku':'50037.0','name':'Belgravia Two-seat Sofa','type':'Sofa','room':'Living room',
  'dimensions_mm':[1500,800,1110],'weight_kg':42,'source_pdf_page':37,'xref':200,
  'fabric_codes':['241.187','243.095'],'fabric_statement':'Suggested Fabric: 241.187 / 243.095',
  'visible_details':SEATING,
  'imageShared':True,'imageSharedWith':['50036.0'],
  'reference_note':'SHARED FAMILY IMAGE: catalogue separately prints two-seat SKU50037.0 and dimensions but no isolated two-seat photo. The original three-seat50036.0 photograph is shared as family reference, not represented as a true two-seat photograph. Two-seat cushion count/arrangement and centre support are dimension-led reconstruction choices.'},
 {'sku':'50038.0','name':'Belgravia Lounge Armchair','type':'Armchair','room':'Living room',
  'dimensions_mm':[780,800,1110],'weight_kg':27,'source_pdf_page':37,'xref':198,
  'fabric_codes':['241.187','243.095'],'fabric_statement':'Suggested Fabric: 241.187 / 243.095',
  'visible_details':SEATING+['One separate seat cushion and one square pale loose pillow; the isolated single-seat source has no round bolster'],
  'reference_note':'Living lounge armchair50038.0 is a high fully upholstered side-panel chair, not the open scroll-arm dining/office50035.0.'},
 {'sku':'50061.0','name':'Belgravia Gilt Oval-in-Rectangle Mirror','type':'Mirror','room':'Living room',
  'dimensions_mm':[940,90,1380],'weight_kg':34,'source_pdf_page':37,'xref':196,'crop':[170,70,575,650],
  'finish':'POE (380)','materials':['Gold-coloured ornate carved frame; printed finish POE (380)','Mirrored glass'],
  'visible_details':['Tall rectangular entirely gilt ornamental frame surrounding an OVAL mirrored centre','Broad stepped outer frame with corner acanthus scroll relief','Gilt corner spandrels between oval opening and rectangular frame','Tall upper centre crest containing leaf shell, wreath and scrolling foliage'],
  'reference_note':'Native-density crop of original console lifestyle photo, retaining actual reflection and overlapping crystal vessel. Special printed finish POE(380), not BEL/OF white-walnut. Catalogue does not specify substrate, gilding chemistry or mirror bevel thickness. Exact ornamental carving is an interpretation of visible source detail.'},
 {'sku':'50050.0','name':'Belgravia Carved-leg Console','type':'Console','room':'Living room',
  'dimensions_mm':[1490,450,830],'weight_kg':26,'source_pdf_page':37,'xref':196,'crop':[55,685,690,1060],
  'visible_details':['Narrow rectangular dark-burl top with fine pale perimeter edge','Long raised white pyramid-diamond apron bounded in gold and dark-burl square corner plaques']+CARVED_LEGS+['Four full-height gold carved legs','Low dark-burl shaped open stretcher link joining the feet; not a full lower storage shelf'],
  'reference_note':'Original lifestyle crop retains vase base, baskets/boxes, wall and floor; no isolated console photo is printed. Visible lower stretcher curves in plan. Decorative objects are styling, not additional product SKUs. No drawer is evidenced.'},
 {'sku':'50039.0','name':'Belgravia Square Coffee Table','type':'Coffee table','room':'Living room',
  'dimensions_mm':[1160,1160,480],'weight_kg':51,'source_pdf_page':38,'sourcePages':[36,38],
  'image_source_pdf_page':36,'xref':193,'crop':[455,655,1225,1120],
  'visible_details':['SQUARE dark polished walnut-burl top with fine pale rectangular perimeter inlay','Raised white pyramid-diamond relief around all aprons','Dark-burl corner blocks with round gilt rosettes framed in white']+CARVED_LEGS+['Four short chunky gold carved legs; no pedestal and no lower shelf'],
  'reference_note':'Printed SKU/specification is on PDF38, while the clearest complete table photo is a native-density crop of original full-room image PDF36. Decorative bowl/boxes and nearby furnishings remain in the crop. Do not confuse with circular side table50040.0. Exact tabletop marquetry hidden by objects is not verified.'},
 {'sku':'50040.0','name':'Belgravia Round Pedestal Side Table','type':'Side table','room':'Living room',
  'dimensions_mm':[680,680,650],'diameter_mm':680,'weight_kg':20,'source_pdf_page':38,'xref':205,
  'visible_details':['Circular polished dark-burl top with broad concentric pale inlay ring','Dark cylindrical apron with white rectangular banding and small round gold medallions','One tapering dark-burl centre column','Low circular dark-burl base with gold foliate collar around the column foot'],
  'reference_note':'Catalogue prints diameter68cm and height65cm, not width/depth separately. Dimensions_mm uses diameter for both planar axes solely for a web/model bounding box. Tray/objects on top are styling.'},
 {'sku':'50194.0','name':'Belgravia TV Cabinet','type':'TV furniture','room':'Living room',
  'dimensions_mm':[2200,500,760],'weight_kg':108,'source_pdf_page':38,'xref':207,
  'visible_details':['Long dark-burl top over broad white pyramid-diamond upper rail','Two outer solid storage fronts, each dark-burl with pale gold laurel-and-crossed-torch marquetry','Central open equipment bay divided horizontally by one white shelf into two levels','White lacquer frame, dark-burl vertical insets and four upper/lower gold rosettes','Low rectilinear plinth rather than tall carved legs'],
  'reference_note':'Visible front seams and open centre shelf are reference evidence; hidden storage internals, opening range and AV wiring are not. Electronics/books/glasses are styling only.'},
 {'sku':'50031.0','name':'Belgravia Twin-pedestal Dining Table','type':'Dining table','room':'Dining room',
  'dimensions_mm':[2460,1320,760],'weight_kg':250,'source_pdf_page':103,'xref':623,
  'visible_details':['Long rectilinear dark-burl top with softly concave clipped corners, pale inlay border and two central gold foliate marquetry emblems','White raised pyramid-diamond apron and dark-burl corner blocks','TWO substantial tapering dark-burl pedestal supports with white framing','Each pedestal sits on a white splayed four-foot base with gold claw-like toe caps and round gold medallions'],
  'reference_note':'This250kg twin-pedestal variant differs from six-carved-leg50043.0 despite identical printed overall dimensions. Manufacturer does not dimension separate pedestal footprint or hidden fixings.'},
 {'sku':'50043.0','name':'Belgravia Six-leg Dining Table','type':'Dining table','room':'Dining room',
  'dimensions_mm':[2460,1320,760],'weight_kg':188,'source_pdf_page':103,'xref':625,
  'visible_details':['Long rectilinear glossy dark-burl top with concave clipped corners, pale perimeter inlay and two central marquetry emblems','White pyramid-diamond apron with dark-burl corner plaques']+CARVED_LEGS+['SIX gold carved legs arranged as three opposed pairs, including a middle pair; not the twin-pedestal variant'],
  'reference_note':'Same overall size as twin-pedestal50031.0 but source photo and188kg printed weight show a distinct six-leg construction. Six leg positions are visible in isolated photo. Hidden joinery is unverified.'},
 {'sku':'50034.0','name':'Belgravia Dining Side Chair','type':'Dining chair','room':'Dining room',
  'dimensions_mm':[470,620,980],'weight_kg':10,'source_pdf_page':104,'xref':631,
  'fabric_codes':['241.188'],'fabric_statement':'Suggested Fabric: 241.188',
  'visible_details':['Armless white lacquer chair with narrow gold piping along frame and legs','Tall gently swept upholstered back with rolled top corners','Original isolated photo shows broad alternating champagne/taupe and cream vertical stripes','Short open horizontal gap under upholstered back','Upholstered seat, swept tapering front/rear legs and low white apron'],
  'reference_note':'Original isolated side-chair photo is striped while armchair50035.0 on the same source page is floral, despite both printing241.188. Preserve this visible fabric distinction rather than assigning identical patterns solely from code. Office lifestyle PDF132 also shows striped armless chairs, not new labelled SKUs.'},
 {'sku':'50035.0','name':'Belgravia Scroll-arm Dining and Office Chair','type':'Dining armchair','room':'Dining room / Office',
  'rooms':['Dining room','Office'],'dimensions_mm':[470,620,980],'weight_kg':12,
  'source_pdf_page':104,'sourcePages':[104,133],'xref':633,
  'fabric_codes':['241.188'],'fabric_statement':'Suggested Fabric: 241.188',
  'visible_details':['White lacquer dining-height chair with gold edge piping','Open elegant curved SCROLL arms ending in gold centre rosettes above narrow front arm uprights','Cream floral-vine upholstery on seat and front of swept high back','Plain pale upholstery at rear in office lifestyle image','Four slim swept tapered white/gold legs; no wheels and no swivel base'],
  'dimension_note':'Source explicitly prints width47cm for BOTH side chair50034.0 and armchair50035.0. This unusual armchair width is preserved verbatim, not corrected or replaced with an invented wider value.',
  'reference_note':'Same SKU repeats in dining PDF104 and office PDF133 and is counted once. Original dining image selected; office original and rear lifestyle view retained as supporting evidence. Printed470mm width is unusual for a scroll-arm chair and is not independently verified.'},
 {'sku':'50032.0','name':'Belgravia Wide Landscape Mirror','type':'Mirror','room':'Dining room',
  'dimensions_mm':[2120,60,1070],'weight_kg':52,'source_pdf_page':104,'xref':635,
  'visible_details':['Wide rectangular landscape mirrored centre','Dark-burl top and bottom rails with white inner borders','White raised pyramid-diamond band along top rail','Tall dark-burl side insets in white framing with small gold oval rosettes at upper corners','Fine continuous gold beaded inside edge'],
  'reference_note':'Landscape dining mirror is2120mm wide; bedroom50047.0 is1300mm wide. Optical bevel, backing, fixing type and exact reflection properties not specified.'},
 {'sku':'50028.0','name':'Belgravia Three-drawer Sideboard','type':'Sideboard','room':'Dining room',
  'dimensions_mm':[2220,530,910],'weight_kg':158,'source_pdf_page':104,'xref':637,
  'visible_details':['Wide dark-burl top with shaped projecting corners and white pyramid-diamond fascia','THREE central wide stacked drawers, each with two round dark/gold ring-like knobs','TWO outer solid doors with gold laurel-and-crossed-torch marquetry on dark-burl panels','White frame and dark-burl inset borders','Tall gold carved side columns with smaller gold carved feet beneath base'],
  'reference_note':'Three central drawer fronts plus two side doors are visible. Interior shelving, drawer boxes, runners and mechanisms are not manufacturer-verified.'},
 {'sku':'50033.0','name':'Belgravia Glazed Display Cabinet','type':'Cabinet','room':'Dining room',
  'dimensions_mm':[1540,510,2100],'weight_kg':224,'source_pdf_page':105,'xref':641,'crop':[45,65,755,1120],
  'visible_details':['Tall two-part hutch cabinet with TWO upper glass-front doors and glazed side panels','TWO visible transparent horizontal shelves create THREE display levels over the lower base','White upper-door frames with narrow gold beaded inner borders and a small paired centre pull','Dark-burl top/waist/base rails and dark vertical edge insets','White pyramid-diamond waist apron','TWO solid lower doors with dark-burl laurel-and-crossed-torch marquetry panels','Gold carved tall lower-side columns and short gold lower feet'],
  'reference_note':'Native-density crop of original cabinet lifestyle photo; surrounding wall, window curtain and floor remain. Two internal glass shelves are visible, not four. Vases/books/tableware are staging. Hinges, opening travel, exact shelf thickness and internal lighting are not specified.'},
 {'sku':'50044.0','name':'Belgravia Tufted Bed','type':'Bed','room':'Bedroom',
  'dimensions_mm':[2230,2150,1440],'weight_kg':120,'source_pdf_page':126,'xref':751,
  'fabric_codes':['243.069'],'fabric_statement':'Suggested Fabric: 243.069',
  'visible_details':['One broad continuous cream/silver diamond-button-tufted headboard panel, not two separated panels','Tall side gold carved columns with small pinecone finials above the dark-burl crest','White raised pyramid-diamond top headboard rail','Low dark-burl side rails outlined in white and gold','White pyramid-diamond footboard fascia with dark corner blocks and small gold rosettes','Short tapered white legs with dark-burl insets','Pale duvet with natural folds, pale square pillows and one long light-taupe cylindrical head bolster'],
  'reference_note':'Printed dimensions describe overall bed frame, not a certified mattress standard. Bedding/pillows are styling. Hidden mattress support, underside construction and tuft spacing are interpretative.'},
 {'sku':'50045.0','name':'Belgravia Drawer-and-door Nightstand','type':'Nightstand','room':'Bedroom',
  'dimensions_mm':[720,450,750],'weight_kg':48,'source_pdf_page':126,'xref':753,
  'visible_details':['Dark-burl top over one narrow upper drawer with two round knobs','One larger lower dark-burl door panel with fine inset border, not a stack of three drawers','White lacquer cabinet frame and dark-burl side panel insets','Gold oval rosettes on upper side uprights','Dark-burl base rail over short gold carved feet'],
  'reference_note':'One upper drawer and one lower door panel are visible. Nightstand does not carry the large white pyramid fascia seen on dressing table/bed. Drawer/door internal construction and opening mechanisms not verified.'},
 {'sku':'50048.0','name':'Belgravia Rolled-end Bedroom Bench','type':'Bench','room':'Bedroom',
  'dimensions_mm':[1620,530,700],'weight_kg':26,'source_pdf_page':126,'xref':749,
  'fabric_codes':['241.188'],'fabric_statement':'Suggested Fabric: 241.188',
  'visible_details':['Long striped champagne/taupe and cream upholstered seat','Two tall outward-scrolling rolled upholstered ends above the seat level','Dark-burl external curved arm panels and gold rosettes at scroll centres','Low white frame with dark-burl front apron inset','Four short tapered white legs with dark front insets'],
  'reference_note':'Printed700mm height includes the TWO high rolled ends, not a700mm seat. Seat height is not separately specified. Bench is not a backless flat rectangular stool.'},
 {'sku':'50047.0','name':'Belgravia Bedroom Dressing Mirror','type':'Mirror','room':'Bedroom',
  'dimensions_mm':[1300,60,1060],'weight_kg':35,'source_pdf_page':126,'xref':754,'crop':[145,20,505,410],
  'visible_details':['Nearly square landscape rectangular mirror rather than the tall oval living mirror','Dark-burl top and lower rails with white inner borders','White raised pyramid-diamond top band','Dark-burl side insets in white framing with small gold oval rosettes','Fine gold beaded mirror perimeter'],
  'reference_note':'Native-density crop of original dressing-table lifestyle image retains real reflection and some overlapping peacock-feather styling. Not a synthesized isolated photograph. Width1300mm differs from the wider dining mirror50032.0.'},
 {'sku':'50046.0','name':'Belgravia Dressing Table','type':'Dressing table','room':'Bedroom',
  'dimensions_mm':[1820,520,780],'weight_kg':93,'source_pdf_page':126,'xref':754,'crop':[55,420,645,790],
  'visible_details':['Broad dark-burl top over TWO white side storage pedestals and an open central knee recess','Each pedestal has one shallow white pyramid-fascia upper drawer with small round knob','Each pedestal lower door contains dark-burl panel with laurel-and-crossed-torch marquetry','Gold carved columns on outside fronts and short gold lower feet','No continuous lower shelf across knee opening'],
  'reference_note':'Native-density original lifestyle crop retains overlapping stool50049.0, wall/floor and decorative objects. Stool hides part of knee space and lower edge; hidden storage/internals and mechanisms are unverified.'},
 {'sku':'50049.0','name':'Belgravia Skirted Vanity Stool Chair','type':'Stool','room':'Bedroom',
  'dimensions_mm':[500,520,800],'weight_kg':17,'source_pdf_page':126,'xref':754,'crop':[325,450,575,803],
  'finish':'BEL (488)','fabric_codes':['241.188'],'fabric_statement':'Suggested Fabric: 241.188',
  'visible_details':['Compact armless vanity seat with a HIGH gently rounded upholstered back','Plain pale silver/taupe upholstery visible on rear and seat','Decorative studded horizontal fabric band around waist/base of back','Floor-length gathered/pleated fabric skirt concealing the legs'],
  'dimension_note':'Source calls this item STOOL but prints height80cm; original photo shows a high-back fully skirted vanity chair. Overall800mm height is retained; do not model as a backless800mm bar stool or invent a lower stated height.',
  'reference_note':'Original source calls50049.0 a stool despite clear high chair-back silhouette. Native-density lifestyle crop preserves actual view from behind and surrounding dressing table. Front upholstery details, concealed legs and exact seat height not visible and remain interpretative.'},
 {'sku':'50051.0','name':'Belgravia Carved-leg Writing Desk','type':'Desk','room':'Office',
  'dimensions_mm':[1720,800,790],'weight_kg':70,'source_pdf_page':133,'xref':789,
  'visible_details':['Rectangular dark-burl top with broad pale inlay border and dark central writing surface','White raised pyramid-diamond apron on the original isolated desk front','Dark-burl square corner blocks and fine gold beaded edges']+CARVED_LEGS+['FOUR gold carved column legs; no enclosed lower pedestals and no centre stretcher','Original office lifestyle image shows dark-burl panels and round pull details on the reverse face'],
  'reference_note':'Printed1720x800x790mm overall dimensions retained exactly. Original isolated view shows diamond apron face; office lifestyle PDF132 shows the opposite dark-burl drawer-panel face. Reverse-face drawer count is visually three panels but opening construction is unverified; no functioning drawer mechanism is claimed. Lamp/books are styling.'},
]

for product in definitions:
    photo_page = product.get('image_source_pdf_page',product['source_pdf_page'])
    product['image'] = preserve_image(photo_page,product['xref'],PRODUCTS/f'{product["sku"]}.jpg',product.get('crop'))
    product.update({'collection':'BELGRAVIA','catalogue_brand':'MARINER','sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023',
                    'sourceBrand':'MARINER','sourcePage':product['source_pdf_page'],
                    'sourcePages':product.get('sourcePages',[product['source_pdf_page']]),
                    'category':product['type'],'rooms':product.get('rooms',[product['room']]),
                    'finish':product.get('finish','BEL. / OF (488/55)'),
                    'imageShared':product.get('imageShared',False),
                    'materials':product.get('materials',['Walnut burl veneer','White lacquer','Sycamore marquetry inlays','Hand-carved wood columns','Cast bronze ornaments']+(['Upholstery with original printed fabric codes recorded separately'] if product.get('fabric_codes') else [])),
                    'dimensions_order':'width, depth, height',
                    'source_printed_pages':f'{(product["source_pdf_page"]-1)*2}-{(product["source_pdf_page"]-1)*2+1}',
                    'image_classification':'Original catalogue image; not independently verified product photography'})
    product['source_printed_dimensions_cm'] = {'width':product['dimensions_mm'][0]/10,'depth':product['dimensions_mm'][1]/10,'height':product['dimensions_mm'][2]/10}
    product['source_product_text_blocks'] = [block[4] for block in doc[product['source_pdf_page']-1].get_text('blocks') if product['sku'] in block[4]]
    if product.get('diameter_mm'):
        product['source_printed_dimensions_cm'].pop('depth')
        product['source_printed_dimensions_cm'].pop('width')
        product['source_printed_dimensions_cm']['diameter'] = product['diameter_mm']/10
    product.pop('xref',None)
    product.pop('crop',None)

supporting = [
 (36,193,'room-living',None,'Living room','Original grey-walled living room with white damask seating, arched tall windows, cream curtains, grey timber floor and taupe shag rug'),
 (37,196,'original-living-console-and-gilt-mirror',None,'Living room','Original50050.0 console and special POE380 oval-in-rectangle gilt mirror50061.0'),
 (38,208,'original-living-seating-detail',None,'Living room','Original right-half close-up of white damask sofa, armchairs, side table and square coffee table'),
 (39,212,'original-living-navy-installation',None,'Living room','Original alternate navy-upholstery palace installation, white/gold coffered ceiling, blue drapes and floral marble floor; no extra variant SKU is printed'),
 (102,619,'room-dining',None,'Dining room','Original grey-walled dining room with six-leg table, ivory/floral chairs, arched windows, cream curtains, grey timber floor and pale shag rug'),
 (103,626,'original-dining-table-cabinet-detail',None,'Dining room','Original dining-table and scroll-arm chair close-up with cabinet behind'),
 (105,641,'original-cabinet-lifestyle',None,'Dining room','Original complete glazed cabinet lifestyle with exactly two visible upper glass shelves'),
 (125,745,'room-bedroom',None,'Bedroom','Original cream panel-moulded bedroom, pale carpet, gold floral rug, cream curtains, crystal chandelier and twin-arm wall sconces'),
 (126,754,'original-dressing-table-mirror-and-skirted-stool',None,'Bedroom','Original dressing table50046.0, mirror50047.0 and high-back skirted stool50049.0 composition'),
 (132,784,'room-office',None,'Office','Original cream panelled office with shuttered window, olive-brown drapes, marble fireplace, fluted pilasters and cream/gold floral rug'),
 (133,787,'original-office-desk-reverse-and-chair-rear',None,'Office','Original diamond-apron desk face and plain cream chair back at marble fireplace'),
 (133,791,'original-office-armchair',None,'Office','Original second isolated photo of repeated dining/office armchair50035.0'),
 (36,193,'details/original-coffee-diamond-apron-and-column',[460,745,1200,1120],'Living room','Native original crop of white raised pyramid-diamond apron, gold beaded borders, rosettes and short carved columns'),
 (105,641,'details/original-laurel-torch-marquetry',[165,685,430,990],'Dining room','Native original crop of lower cabinet walnut-burl panel with laurel-and-crossed-torch marquetry'),
 (125,745,'details/original-headboard-tufting',[755,375,1270,665],'Bedroom','Native original crop of single tufted headboard panel and tall gold columns'),
 (132,784,'details/original-office-drawer-face',[490,505,1210,715],'Office','Native original crop of opposite desk face with dark-burl rectangular panels and two visible round pulls'),
]
supporting_images = []
for pdf_page,xref,name,crop,room,description in supporting:
    evidence = preserve_image(pdf_page,xref,DEST/f'{name}.jpg',crop)
    evidence.update({'room':room,'description':description})
    supporting_images.append(evidence)

manifest = {'collection':'BELGRAVIA','catalogue_brand':'MARINER','catalogue_title':SOURCE.name,
            'sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023','sourceBrand':'MARINER',
            'source_pdf':str(SOURCE),'source_pdf_sha256':report['source_sha256'],'source_pdf_page_count':len(doc),
            'source_pdf_pages':PAGE_NUMBERS,'dimensions_unit':'millimetres','dimensions_order':'width, depth, height',
            'source_material_statement':'WALNUT BURL VENEER COMBINED WITH WHITE LACQUER, SYCAMORE MARQUETRY INLAYS, HAND-CARVED WOOD COLUMNS AND CASTED BRONZE ORNAMENTS.',
            'source_variant_note':'Three-seat50036.0 and separately dimensioned two-seat50037.0 share the original three-seat front photograph; no isolated two-seat photo appears. This is explicitly disclosed. Armchair50035.0 repeats in dining/office and is counted once. Mirror50061.0 has special printed POE(380) finish, not the common BEL/OF white-walnut finish.',
            'scope_note':'Full BELGRAVIA suite: living PDF36-39; dining PDF102-105; bedroom PDF125-126; office PDF132-133.22 unique product SKUs:8 living,7 dining,6 bedroom,1 new office. Dining armchair50035.0 repeats in office. Original lamps, crystal chandeliers, rugs, bedding, tableware, wall art, architecture and other room styling are not extra product SKUs.',
            'provenance_note':'Source images are exact embedded JPEG bytes, documented native-density rectangular crops, or faithful composites of original embedded JPEGs with their original PDF soft masks over white. Raw originals, original masks, xrefs, dimensions, transforms and SHA256 hashes retained. No AI substitution, super-resolution, subject segmentation, missing-photo synthesis, recolouring or geometric image manipulation was performed.',
            'reconstruction_caveat':'Printed dimensions and visibly documented construction are source evidence. Hidden joinery, calibrated finish/colour, exact metal coating, textile weave and fabric-code inconsistency, concealed stool legs, internal storage and opening mechanisms remain interpretative. Source images are not independently verified as photography. Original environments guide a furnished reference interior, not a freestanding exhibition.',
            'dimension_caveats':['Armchair50035.0 width470mm is explicitly printed, even though same as armless50034.0; preserve as source oddity, not an independently verified width.','Stool50049.0 printed height800mm is overall high-back height, not seat height.','Bench50048.0 printed height700mm includes rolled raised ends, not seat height.','Side table50040.0 prints diameter680mm; duplicate planar dimensions are a model/web bounding-box convention.'],
            'rights_note':'User-supplied MARINER catalogue; original designs/images remain the rights of their owners. Extraction grants no commercial reuse licence or manufacturer endorsement.',
            'room_reference_notes':{
              'Living room':'Grey and charcoal walls, tall white-framed arched sash openings, cream curtains, grey timber floor, taupe shag rug, crystal-stem brass lamps and brass/crystal chandelier; white damask seating is primary reference. Navy palace installation PDF39 is a preserved alternate styling reference, not a separately specified product.',
              'Dining room':'Grey walls and grey timber floor, arched tall windows with cream curtains, pale shag rug, warm brass chandelier, gilt small wall lights, cabinet at left and large landscape mirror above sideboard.',
              'Bedroom':'Warm pale cream walls with fine white panel mouldings/chair rail, plain tall rear window and cream curtains, pale carpet, cream/gold floral rug, gold/crystal chandelier, twin-arm crystal wall sconces and silver urn lamp.',
              'Office':'Cream panel walls, fluted white pilasters, shuttered tall rectangular window with full-height dark olive-brown drapes, pale carpet, cream/gold floral rug, marble fireplace, ornate urn lamp and crystal chandelier.'},
            'products':definitions,'supporting_images':supporting_images}
assert len(definitions)==22 and len({p['sku'] for p in definitions})==22
for product in definitions:
    assert all(v>0 for v in product['dimensions_mm'])
    assert product['source_product_text_blocks'],product['sku']
    assert product['image']['output_pixels'][0] <= product['image']['source_native_pixels'][0]
    assert product['image']['output_pixels'][1] <= product['image']['source_native_pixels'][1]
(DEST/'products.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
audited = []
for evidence in [p['image'] for p in definitions]+supporting_images:
    path = DEST/evidence['file']
    pixmap = fitz.Pixmap(str(path))
    assert [pixmap.width,pixmap.height] == evidence['output_pixels']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == evidence['sha256']
    assert hashlib.sha256((DEST/evidence['source_image_file']).read_bytes()).hexdigest() == evidence['source_image_sha256']
    if evidence.get('source_soft_mask_file'):
        assert hashlib.sha256((DEST/evidence['source_soft_mask_file']).read_bytes()).hexdigest() == evidence['source_soft_mask_sha256']
    assert evidence['output_pixels'][0]<=evidence['source_native_pixels'][0]
    assert evidence['output_pixels'][1]<=evidence['source_native_pixels'][1]
    audited.append({'file':evidence['file'],'pixels':evidence['output_pixels'],'bytes':path.stat().st_size,'sha256':evidence['sha256']})
(DEST/'reference-audit.json').write_text(json.dumps({'status':'passed','source_pdf_sha256':report['source_sha256'],
    'unique_products':22,'living_unique_products':8,'dining_unique_products':7,'bedroom_unique_products':6,
    'new_office_unique_products':1,'office_shared_with_dining':['50035.0'],
    'shared_family_product_images':{'50037.0':'50036.0'},
    'original_source_page_previews':PAGE_NUMBERS,'audited_images':audited,
    'assertions':['All22 SKUs unique and linked to original printed SKU text blocks','All output pixel sizes match decoded image sizes',
                  'No output is upscaled','All output/original/mask SHA256 hashes verified',
                  'Original soft masks faithfully composited over white, not new segmentation',
                  'Printed unusual armchair470mm width, stool800mm and rolled-bench700mm height preserved',
                  'Four original complete room lifestyle images and original navy installation retained']},indent=2),encoding='utf8')
print('PRODUCT_REFERENCES_READY',len(definitions),DEST/'products.json',flush=True)
doc.close()
