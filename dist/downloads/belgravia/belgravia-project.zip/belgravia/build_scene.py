"""BELGRAVIA: four connected, fully enclosed catalogue-inspired interiors.

The walking tour retains actual walls and ceilings. Only the explicitly labelled
overview cutaway removes tagged surfaces. Architecture is an interpretation.
"""
import bpy,math,sys,json,random,time,hashlib
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import core as c
import sofas,casegoods
started=time.perf_counter();random.seed(48855)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.materials();scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='METERS'
scene['collection']='BELGRAVIA';scene['layout']='furnished-interior';scene['walls']=True;scene['roof']=True
scene['reference']='MARINER classic catalogue: PDF36-39,102-105,125-126,132-133'
c.set_parent(None);staging=c.empty('BELGRAVIA | catalogue-inspired residence',props={'kind':'interior-staging','walls':True,'roof':True})
H=3.65;DEPTH=10;colliders=[];browser_lights=[]
def branch(name,cutaway=False):
    c.set_parent(staging);root=c.empty(name,props={'kind':'architectural-surface','cutaway':cutaway});c.set_parent(root);return root
def panel(name,x,y,z,w,h,side=False):
    for inset,r in ((0,.009),(.027,.004)):
        pts=[]
        for a,b in ((-w/2,-h/2),(w/2,-h/2),(w/2,h/2),(-w/2,h/2)):
            a-=math.copysign(inset,a);b-=math.copysign(inset,b)
            pts.append((x,y+a,z+b) if side else (x+a,y,z+b))
        c.curve(name,pts,r,'plaster',True)
def cornice(x0,x1,y):
    for z,d,h in ((3.49,.065,.07),(3.55,.10,.055),(3.60,.15,.045)):
        c.box('Layered white cornice',((x0+x1)/2,y,z),(x1-x0,d,h),'plaster',.008)
    for i in range(int((x1-x0-.4)/.24)):
        c.box('Cornice dentil',(x0+.22+i*.24,y-.035,3.485),(.08,.055,.05),'plaster',.004)
def sheet(name,profile,y,thick,mat):
    n=len(profile);vs=[(x,yy,z) for yy in (y-thick/2,y+thick/2) for x,z in profile]
    fs=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return c.mesh(name,vs,fs,mat)
def curtain(x,y,width,mat='curtain'):
    vs=[];fs=[];N=70;rows=18
    for j in range(rows+1):
        t=j/rows;z=.055+3.30*t
        for i in range(N+1):
            u=i/N;v=(u-.5)*width*(1+.07*math.sin(t*math.pi))
            vs.append((x+v,y+.045*math.cos(u*math.tau*7)+.012*math.sin(t*5+u*4),z))
    for j in range(rows):
        for i in range(N):a=j*(N+1)+i;fs.append((a,a+1,a+N+2,a+N+1))
    ob=c.mesh('Full-length pleated '+mat,vs,fs,mat,smooth=True)
    mod=ob.modifiers.new('Woven curtain thickness','SOLIDIFY');mod.thickness=.0015
    c.rod('Curtain gilt rail',(x-width/2-.08,y,3.38),(x+width/2+.08,y,3.38),.012,'brass')
def arched_facade(room,x0):
    branch(room+' arched rear facade');holes=[(x0+.65,x0+2.05),(x0+4.95,x0+6.35)]
    ranges=[(x0,holes[0][0]),(holes[0][1],holes[1][0]),(holes[1][1],x0+7)]
    for a,b in ranges:c.box('Solid charcoal wall',((a+b)/2,10.08,H/2),(b-a,.20,H),'wall_dark',.004)
    for a,b in holes:
        cx=(a+b)/2;r=(b-a)/2;spring=2.50
        c.box('Solid wall below arch window',(cx,10.08,.22),(b-a,.2,.44),'wall_dark',.004)
        prof=[(a,H),(b,H),(b,spring)]+[(cx+r*math.cos(t),spring+r*math.sin(t)) for t in [i*math.pi/48 for i in range(1,49)]]
        sheet('Actual masonry above arched opening',prof,10.08,.2,'wall_dark')
        arch=[(a,9.95,.47),(a,9.95,spring)]+[(cx+r*math.cos(t),9.95,spring+r*math.sin(t)) for t in [math.pi-i*math.pi/64 for i in range(65)]]+[(b,9.95,.47)]
        c.curve('White arch-top window casing',arch,.039,'white')
        for x in (a+.06,cx,b-.06):c.box('Sash vertical frame',(x,9.98,1.50),(.034,.045,2.10),'white',.003)
        for z in (.48,1.10,1.8,2.50):c.box('Sash horizontal frame',(cx,9.98,z),(b-a,.045,.034),'white',.003)
        profile=[(a+.03,.48),(b-.03,.48),(b-.03,spring)]+[(cx+(r-.03)*math.cos(t),spring+(r-.03)*math.sin(t)) for t in [i*math.pi/48 for i in range(1,49)]]
        sheet('Almost invisible arch window glass',profile,10.015,.005,'window')
        c.box('White projecting sill',(cx,9.91,.47),(b-a+.16,.27,.055),'white',.009)
        for edge in (a-.10,b+.10):curtain(edge,9.77,.40)
        # Soft daylight beyond a real opening, not a cartoon city poster.
        sheet('Soft sky beyond arch',profile,11.2,.01,'sky')
        c.set_parent(None);c.light(room+' window daylight','AREA',(cx,9.68,2.1),600,(.85,.92,1),target=(x0+3.5,6,.6),size=1.6);c.set_parent(staging)
    cornice(x0,x0+7,9.91)
    for a,b in ranges:c.box('Rear white skirting',((a+b)/2,9.94,.095),(b-a,.08,.19),'white',.006)
for room,x0 in (('living',0),('dining',7)):arched_facade(room,x0)
for room,x0,wa,wb in [('bedroom',14,15.9,19.1),('office',21,23.4,25.6)]:
    branch(room+' cream panelled rear facade')
    for a,b in ((x0,wa),(wb,x0+7)):
        c.box('Cream panelled rear wall',((a+b)/2,10.08,H/2),(b-a,.2,H),'plaster',.005)
        if b-a>.6:panel('Rear cream raised panel',(a+b)/2,9.96,1.98,b-a-.24,2.5)
    for z,h in ((.3,.6),(3.48,.34)):c.box('Rectangular window head/sill',((wa+wb)/2,10.08,z),(wb-wa,.2,h),'plaster',.004)
    for x in (wa,wb,(wa+wb)/2):c.box('White window vertical',(x,9.96,1.98),(.06,.07,2.76),'white',.005)
    for z in (.62,1.97,3.34):c.box('White window horizontal',((wa+wb)/2,9.96,z),(wb-wa+.06,.07,.055),'white',.005)
    c.box('Clear rectangular window',((wa+wb)/2,10.01,1.98),(wb-wa,.005,2.72),'window',0)
    c.box('Soft sky beyond rectangular window',((wa+wb)/2,11.1,1.98),(wb-wa,.01,2.72),'sky',0)
    c.box('White sill',((wa+wb)/2,9.90,.62),(wb-wa+.16,.29,.06),'white',.008)
    for edge in (wa-.05,wb+.05):curtain(edge,9.74,.55,'curtain_dark' if room=='office' else 'curtain')
    if room=='office':
        for edge in (wa+.21,wb-.21):
            for j in range(24):c.box('White shutter louvre',(edge,9.91,.76+j*.102),(.35,.065,.035),'white',.003)
        for edge in (x0+.55,x0+6.45):
            c.box('White fluted pilaster',(edge,9.90,1.8),(.29,.16,3.25),'white',.009)
            for dx in (-.085,-.042,0,.042,.085):c.rod('Pilaster flute',(edge+dx,9.808,.28),(edge+dx,9.808,3.28),.009,'plaster')
            for z,w,h in ((.20,.40,.12),(3.36,.44,.14)):c.box('Pilaster base and capital',(edge,9.87,z),(w,.23,h),'white',.009)
    cornice(x0,x0+7,9.91)
    c.set_parent(None);c.light(room+' window daylight','AREA',((wa+wb)/2,9.66,2.3),900,(.88,.93,1),target=(x0+3.5,5.5,.7),size=2.8)

# Four complete rooms, with physical 1.6m door openings along the clear lane.
for x in (0,7,14,21,28):
    branch('Side and partition enclosure '+str(x),True)
    spans=[(0,10)] if x in (0,28) else [(0,1.2),(2.8,10)]
    mat='wall' if x<14 else 'plaster'
    for a,b in spans:
        c.box('Physical room partition',(x,(a+b)/2,H/2),(.18,b-a,H),mat,.005);colliders.append([x-.10,a,x+.10,b])
        for side in (-1,1):
            sx=x+side*.104
            c.box('White partition skirting',(sx,(a+b)/2,.09),(.045,b-a,.18),'white',.005)
            c.box('Upper partition cornice',(sx,(a+b)/2,3.54),(.15,b-a,.13),'white',.006)
            if x>=14 and b-a>2:
                for j in range(int((b-a-.4)/1.65)):panel('Cream side panel',sx,a+1+j*1.65,1.98,1.35,2.45,True)
    if x not in (0,28):
        c.box('Doorway lintel',(x,2,3.2),(.18,1.6,.9),mat,.004)
        for y in (1.17,2.83):c.box('Doorway white jamb',(x,y,1.38),(.24,.075,2.76),'white',.006)
        c.box('Doorway white architrave',(x,2,2.80),(.26,1.75,.12),'white',.007)
branch('Complete front facade',True)
for x0 in (0,7,14,21):
    c.box('Complete front wall',(x0+3.5,-.08,H/2),(7,.2,H),'wall' if x0<14 else 'plaster',.005)
    for x in (x0+1.3,x0+3.5,x0+5.7):panel('Front raised panel',x,.032,2,1.7,2.5)
    cornice(x0,x0+7,.06)
branch('Complete coffered plaster ceiling',True)
for x0 in (0,7,14,21):
    c.box('Full plaster ceiling',(x0+3.5,5,3.72),(7,10,.16),'plaster',.01)
    for x in (x0+.35,x0+6.65):c.box('Ceiling perimeter',(x,5,3.61),(.08,9.3,.065),'white',.008)
    for y in (.35,9.65):c.box('Ceiling perimeter',(x0+3.5,y,3.61),(6.3,.08,.065),'white',.008)
    for r in (.28,.37,.43):c.curve('Chandelier plaster rose',[(x0+3.5+math.cos(i*math.tau/64)*r,6.5+math.sin(i*math.tau/64)*r,3.60) for i in range(64)],.018,'plaster',True)
branch('Grey oak and pale carpet flooring')
for x0 in (0,7):
    for i in range(20):
        x=x0+.175+i*.35
        for j in range(5):c.box('Grey-washed wide oak plank',(x,1+j*2,-.046),(.347,1.997,.09),'floor_wood',.001)
for x0 in (14,21):c.box('Pale fitted room carpet',(x0+3.5,5,-.041),(7,10,.08),'carpet',.003)
def rug(name,x,y,w,d,shag=False):
    c.set_parent(staging);c.box(name,(x,y,.015),(w,d,.028),'shag' if shag else 'floral_rug',.01)
    if shag:
        vs=[];fs=[]
        for i in range(11000):
            px=x+(random.random()-.5)*w;py=y+(random.random()-.5)*d;h=.008+random.random()*.016;a=len(vs)
            vs.extend([(px-.0015,py,.029),(px+.0015,py,.029),(px+.002,py+.002,.029+h)]);fs.append((a,a+1,a+2))
        c.mesh('Physical woven shag tufts',vs,fs,'shag')
    else:
        for inset in (.04,.085):c.curve('Fine woven rug border',[(x-w/2+inset,y-d/2+inset,.032),(x+w/2-inset,y-d/2+inset,.032),(x+w/2-inset,y+d/2-inset,.032),(x-w/2+inset,y+d/2-inset,.032)],.002,'cloth_gold',True)
rug('Salon taupe shag rug',3.5,6.75,5.8,4.7,True);rug('Dining taupe shag rug',10.5,6.6,5.4,4.2,True)
rug('Bedroom cream floral carpet',17.5,7.25,5.4,4.4);rug('Office cream floral carpet',24.5,6.5,5.1,4.8)
placements=[]
def place(sku,room,position,rotation=0):
    c.set_parent(None);module=sofas if sku in sofas.SPECS else casegoods
    root=module.create(sku,instance=room+'-'+str(len(placements)+1));root.location=position;root.rotation_euler.z=math.radians(rotation);root['room']=room
    placements.append({'sku':sku,'room':room,'position':list(position),'rotation':rotation,'instance':root['instance_id']});c.set_parent(staging);return root
place('50036.0','living',(3.5,8.75,.03));place('50040.0','living',(1.85,8.65,0));place('50040.0','living',(5.15,8.65,0))
place('50039.0','living',(3.5,6.75,.03));place('50038.0','living',(1.5,6.3,.03),48);place('50038.0','living',(5.6,6.3,.03),-48)
place('50037.0','living',(.68,4.1,0),90);place('50050.0','living',(6.60,4.05,0),-90);place('50061.0','living',(6.87,4.05,1.0),-90)
place('50194.0','living',(3.6,.42,0),180)
place('50043.0','dining',(10.5,6.9,.03))
for x in (9.68,10.5,11.32):
    place('50034.0','dining',(x,5.9,.03),180);place('50034.0','dining',(x,7.9,.03))
place('50035.0','dining',(8.78,6.9,.03),90);place('50035.0','dining',(12.22,6.9,.03),-90)
place('50028.0','dining',(10.5,9.55,0));place('50032.0','dining',(10.5,9.88,1.13))
place('50033.0','dining',(13.60,8.30,0),-90)
place('50031.0','dining',(10.5,3.6,0));place('50034.0','dining',(8.8,3.6,0),90);place('50034.0','dining',(12.2,3.6,0),-90)
place('50044.0','bedroom',(17.5,8.15,.03));place('50045.0','bedroom',(15.83,8.85,0));place('50045.0','bedroom',(19.17,8.85,0))
place('50048.0','bedroom',(17.5,6.55,.03));place('50046.0','bedroom',(14.46,5.15,0),90);place('50047.0','bedroom',(14.15,5.15,.93),90)
place('50049.0','bedroom',(15.28,5.15,0),-90)
place('50051.0','office',(24.5,6.65,.03));place('50035.0','office',(24.5,5.40,.03),180)
place('50034.0','office',(24.5,7.72,.03));place('50035.0','office',(26.0,5.4,.03),-25)

def shade(x,y,z):
    vs=[];fs=[];N=96
    for r,h in ((.235,.48),(.145,.79)):
        for i in range(N):a=i*math.tau/N;rr=r+(.005 if i%2 else -.005);vs.append((x+rr*math.cos(a),y+rr*math.sin(a),z+h))
    for i in range(N):j=(i+1)%N;fs.append((i,j,N+j,N+i))
    c.mesh('Pleated ivory lamp shade',vs,fs,'curtain')
    for r,h in ((.235,.48),(.145,.79)):c.curve('Shade sewn gold rim',[(x+r*math.cos(i*math.tau/64),y+r*math.sin(i*math.tau/64),z+h) for i in range(64)],.002,'brass',True)
def lamp(x,y,z,urn=False):
    c.set_parent(staging);c.lathe('Lamp bronze foot',(x,y,z),[(0,0),(.12,0),(.12,.025),(.08,.045),(.045,.07)],'gold',32)
    if urn:c.lathe('Office urn lamp',(x,y,z+.07),[(.04,0),(.08,.03),(.095,.14),(.055,.25),(.035,.29),(.06,.32)],'white',48)
    else:
        c.lathe('Cut crystal lamp stem',(x,y,z+.07),[(.035,0),(.08,.04),(.035,.10),(.025,.27),(.07,.30),(.035,.36)],'glass',32)
        for i in range(8):a=i*math.tau/8;c.rod('Crystal lamp bronze rib',(x+.032*math.cos(a),y+.032*math.sin(a),z+.14),(x+.025*math.cos(a),y+.025*math.sin(a),z+.34),.0015,'gold')
    c.rod('Lamp central spindle',(x,y,z+.04),(x,y,z+.61),.006,'brass');shade(x,y,z)
    c.set_parent(None);c.light('Warm table lamp','POINT',(x,y,z+.61),44,(1,.78,.51));browser_lights.append({'position':[x,y,z+.61],'intensity':9,'color':'#ffd7a2','distance':3.5});c.set_parent(staging)
for args in [(1.85,8.65,.65),(5.15,8.65,.65),(15.83,8.85,.75),(19.17,8.85,.75),(9.75,9.5,.91)]:lamp(*args)
lamp(23.93,6.78,.82,True)
def chandelier(x,y):
    c.set_parent(staging);c.rod('Chandelier suspension',(x,y,3.58),(x,y,2.84),.012,'gold')
    c.lathe('Chandelier crystal central vase',(x,y,2.49),[(0,0),(.075,.025),(.11,.12),(.05,.21),(.04,.34)],'glass',40)
    for i in range(8):
        a=i*math.tau/8;ex=x+.56*math.cos(a);ey=y+.56*math.sin(a)
        c.curve('Curved gilt chandelier arm',[(x+(.08+t*.48)*math.cos(a),y+(.08+t*.48)*math.sin(a),2.60+.26*(2*t-1)**2) for t in [j/24 for j in range(25)]],.010,'gold')
        c.lathe('Gilt candle dish',(ex,ey,2.84),[(0,0),(.06,0),(.07,.02),(.03,.045)],'gold',24)
        c.cylinder('Ivory candle sleeve',(ex,ey,2.98),.016,.23,'ivory');c.sphere('Glowing candle',(ex,ey,3.11),(.022,.022,.045),'light',12,8)
        for j in range(5):
            t=j/4;px=x+math.cos(a)*(.15+t*.38);py=y+math.sin(a)*(.15+t*.38);pz=2.73-.15*math.sin(t*math.pi)
            c.sphere('Faceted crystal drop',(px,py,pz-.065),(.018,.018,.065),'glass',8,4)
    c.set_parent(None);c.light('Warm crystal chandelier','POINT',(x,y,2.70),105,(1,.83,.64));browser_lights.append({'position':[x,y,2.7],'intensity':13,'color':'#ffe0b5','distance':6});c.set_parent(staging)
for x in (3.5,10.5,17.5,24.5):chandelier(x,6.5)
def flowers(x,y,z):
    c.set_parent(staging);c.lathe('Clear floral vase',(x,y,z),[(0,0),(.085,0),(.09,.02),(.07,.20),(.065,.22)],'glass',28)
    for i in range(13):
        a=i*2.4;px=x+math.cos(a)*(.07+.006*i);py=y+math.sin(a)*(.07+.006*i);h=.32+random.random()*.12
        c.rod('Flower stem',(x,y,z+.05),(px,py,z+h),.0015,'leaf')
        for j in range(5):b=j*math.tau/5;c.sphere('Ivory flower petal',(px+.017*math.cos(b),py+.017*math.sin(b),z+h),(.025,.018,.012),'ivory',10,6)
flowers(3.5,6.75,.51);flowers(10.5,6.9,.81);flowers(11.15,9.5,.91);flowers(14.46,4.65,.79)
c.set_parent(staging)
for x in (9.68,10.5,11.32):
    for y in (6.45,7.35):
        c.lathe('Porcelain dining plate',(x,y,.80),[(0,0),(.11,0),(.14,.01),(.14,.018),(.11,.012),(0,.012)],'ivory',32)
        c.curve('Fine gilt plate rim',[(x+.132*math.cos(i*math.tau/48),y+.132*math.sin(i*math.tau/48),.819) for i in range(48)],.0012,'gold',True)
        c.lathe('Wine glass',(x+.18,y,.80),[(0,0),(.033,0),(.033,.004),(.005,.01),(.005,.09),(.032,.12),(.037,.17),(.032,.19)],'glass',24)
# Four botanical panels above the salon sofa, as in the source composition.
for i in range(4):
    x=2.36+i*.76;c.box('Botanical artwork gilt frame',(x,9.93,2.17),(.65,.048,1.02),'gold',.006);c.box('Botanical artwork ivory ground',(x,9.898,2.17),(.59,.008,.96),'paper',.001)
    for j in range(3):
        xx=x+(j-1)*.12;c.curve('Authored botanical stem',[(xx,9.888,1.80),(xx+.03,9.888,2.12),(xx-.02,9.888,2.48)],.003,'leaf')
        for k in range(5):
            ob=c.sphere('Botanical print leaf',(xx+(.034 if k%2 else -.034),9.886,1.93+k*.10),(.045,.002,.020),'leaf',10,6);ob.rotation_euler.y=(-.5 if k%2 else .5)
# Bedroom gilt sconces and office fireplace are styling, not additional SKUs.
for x in (15.3,19.7):
    c.box('Sconce gilt backplate',(x,9.89,2.15),(.11,.055,.28),'gold',.04)
    for s in (-1,1):
        ex=x+s*.16;c.curve('Double sconce arm',[(x,9.84,2.12),(ex,9.63,2.05),(ex,9.58,2.25)],.012,'gold');c.cylinder('Sconce candle',(ex,9.58,2.36),.016,.20,'ivory');c.sphere('Sconce flame bulb',(ex,9.58,2.48),(.02,.02,.04),'light',12,8)
    c.set_parent(None);c.light('Warm bedroom sconce','POINT',(x,9.42,2.35),38,(1,.75,.46));c.set_parent(staging)
fire=c.empty('Interpreted office fireplace',props={'kind':'styling'});c.set_parent(fire)
c.box('Office dark firebox',(27.83,7.8,.45),(.08,1.12,.84),'black',.008)
for y in (7.1,8.5):c.box('Marble fireplace jamb',(27.66,y,.49),(.46,.18,.98),'stone',.012)
c.box('Marble mantel',(27.61,7.8,1.04),(.64,1.70,.12),'stone',.012);c.box('Marble hearth',(27.58,7.8,.04),(.70,1.7,.08),'stone',.006)
for y in (7.5,7.8,8.05):c.rod('Fireplace log',(27.78,y,.16),(27.60,y+.18,.15),.043,'wood_dark')
c.set_parent(staging)
for i in range(3):c.box('Stacked office book',(24.9,6.9,.85+i*.035),(.24,.34,.03),('wood_dark','paper','cloth_dark')[i],.003)
c.box('Office writing paper',(24.45,6.47,.826),(.22,.30,.002),'paper',0);c.rod('Desk pen',(24.61,6.34,.83),(24.66,6.5,.83),.003,'black')

c.set_parent(None);world=bpy.data.worlds.new('BELGRAVIA soft natural daylight');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.72,.77,.82,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.30
for x in (3.5,10.5,17.5,24.5):
    c.light('Large soft interior bounce','AREA',(x,4.2,3.35),540,(1,.92,.80),target=(x,7.5,.75),size=4)
    c.light('Soft front camera fill','AREA',(x,1,2.7),320,(.92,.96,1),target=(x,6.5,1),size=4)
sun=c.light('Soft exterior daylight','SUN',(-4,13,10),.8,(1,.95,.86),target=(7,3,0));sun.data.angle=.16
# Broad studio fills retain diffuse modelling without obscuring the figured
# veneer beneath a large white softbox reflection in EEVEE.
for ob in scene.objects:
    if ob.type=='LIGHT' and ob.data.type!='SUN':ob.data.specular_factor=.12
cameras={
 'living':((3.5,4.6,1.60),(3.5,8.35,1.08),27),
 'living-wide':((5.95,3.3,1.80),(3.1,7.4,1.05),28),
 'dining':((8.1,4.05,1.85),(10.7,7.6,1.15),27),
 'dining-pedestal':((12.85,1.2,1.72),(10.3,4.25,.95),31),
 'bedroom':((20.3,4.1,1.72),(17.4,8.35,1.04),29),
 'vanity':((17.6,3.35,1.62),(14.5,5.3,1.05),34),
 'office':((22.15,3.5,1.70),(24.65,7.05,1.05),31),
 'office-wide':((26.7,3.2,1.8),(24.65,7.25,1.1),28),
 'detail-burl':((4.63,5.74,.86),(3.98,6.35,.40),65),
 'detail-upholstery':((4.85,7.6,1.10),(4.18,8.6,.80),65),
 'detail-tufting':((18.65,7.15,1.95),(18.05,9.1,1.20),60),
}
for key,(loc,target,lens) in cameras.items():
    data=bpy.data.cameras.new('Lens '+key);ob=bpy.data.objects.new('Camera '+key,data);scene.collection.objects.link(ob);ob.location=loc;ob.rotation_euler=(Vector(target)-ob.location).to_track_quat('-Z','Y').to_euler();data.lens=lens;data.clip_start=.025;data.clip_end=120
    if key.startswith('detail'):data.dof.use_dof=True;data.dof.focus_distance=(Vector(target)-Vector(loc)).length;data.dof.aperture_fstop=8
scene.camera=bpy.data.objects['Camera living'];scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=True
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8';scene.render.image_settings.compression=25
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.render.film_transparent=False
zones={
 'living':{'name':'The arched-window salon','bounds':[.2,.2,6.8,9.8],'camera':[[3.5,4.6,1.65],[3.5,8.35,1.08],60]},
 'dining':{'name':'The walnut dining room','bounds':[7.2,.2,13.8,9.8],'camera':[[8.1,4.05,1.65],[10.7,7.6,1.1],60]},
 'bedroom':{'name':'The ivory bedroom','bounds':[14.2,.2,20.8,9.8],'camera':[[20.3,4.1,1.65],[17.4,8.35,1.04],60]},
 'office':{'name':'The classic office','bounds':[21.2,.2,27.8,9.8],'camera':[[22.15,3.5,1.65],[24.65,7.05,1.05],60]},
 'pedestal':{'name':'The twin-pedestal setting','camera':[[12.85,1.2,1.65],[10.3,4.25,.95],58]},
 'vanity':{'name':'The dressing corner','camera':[[17.6,3.35,1.65],[14.5,5.3,1.05],55]},
}
info={'collection':'BELGRAVIA','units':'metres','layout':'furnished-interior','walls':True,'roof':True,'defaultRoom':'living','overviewCutaway':True,'guideTransitionY':2.0,'floorBounds':[.2,.2,27.8,9.8],'rooms':zones,'placements':placements,'colliders':colliders,'browserLights':browser_lights,
 'overview':{'position':[33,23,27],'target':[14,1,-5],'fov':45},'source':'CLASSIC_FURNITURE_CATALOG_2023.pdf','sourcePages':[36,37,38,39,102,103,104,105,125,126,132,133],'finish':'BEL. / OF (488/55); ornate mirror POE. (380)',
 'interpretations':['Four connected rooms link independent catalogue compositions; this is not a measured source building','Complete architecture remains in the room tour; only the labelled overview is a cutaway','Arched windows, panelling, shutters, curtains, lamps, chandeliers, botanical artwork, fireplace and table styling are authored reference-inspired staging, not additional manufacturer SKUs','Unseen construction, exact textile motifs and material calibration are interpretations, not certified manufacturer CAD','The two-seat sofa shares its source photograph with the three-seat sofa; its independent printed dimensions are retained','The dining armchair retains the unusual printed470mm width; the800mm stool is a high-back skirted vanity chair','The gold mirror50061 uses its own POE380 finish, not the white-lacquer family finish','Cabinetry is static: the source does not establish functional opening hardware']}
scene['web_scene_info']=json.dumps(info);(BASE/'scene.json').write_text(json.dumps(info,indent=2),encoding='utf8')
scene['rebuild_source_sha256']=json.dumps({name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in ('core.py','geometry.py','sofas.py','casegoods.py','build_scene.py')})
for mat in bpy.data.materials:mat.use_fake_user=True
for im in bpy.data.images:
    if im.source=='FILE':im.use_fake_user=True
bpy.ops.file.pack_all()
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.region_3d.view_camera_zoom=0;area.spaces.active.shading.type='MATERIAL'
report={'collection':'BELGRAVIA','products':len(set(p['sku'] for p in placements)),'placements':len(placements),'movingParts':0,'objects':len(scene.objects),'meshes':sum(o.type=='MESH' for o in scene.objects),'walls':True,'roof':True,'layout':'furnished-interior','seconds':round(time.perf_counter()-started,2)}
(BASE/'build-report.json').write_text(json.dumps(report,indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'belgravia-interior.blend'),compress=True)
print('BELGRAVIA_BUILD_COMPLETE',json.dumps(report),flush=True)
