"""Madison living-room upholstery reconstructed from the supplied catalogue.

Reference: CLASSIC_FURNITURE_CATALOG_2023, printed pp. 26–29 and 39.
All dimensions are metres; the opening faces -Y.  Tufting, piping, inlays,
cloth fullness and cushion folds are editable geometry rather than images.
The hidden construction is interpreted, not manufacturer engineering CAD.
"""
import math
from contextlib import contextmanager

import bpy
from mathutils import Vector
import core as c


SPECS = {
    '50532.0': (2.75, .95, .95, 3, 'Madison three-seat sofa'),
    '50533.0': (2.10, .95, .95, 2, 'Madison two-seat sofa'),
    '50534.0': (.95, .95, .95, 1, 'Madison armchair'),
}
TAU = math.tau


@contextmanager
def parent(ob):
    previous = c.PARENT
    c.set_parent(ob)
    try:
        yield ob
    finally:
        c.set_parent(previous)


def smooth(t):
    t = min(1.0, max(0.0, t))
    return t*t*(3-2*t)


class Wrap:
    """Constant arc-length U path, from left-front to right-front."""
    def __init__(self, width, depth, inset=.042, radius=.16):
        self.x = width/2-inset
        self.front = -depth/2+.025
        self.back = depth/2-.045
        self.r = min(radius, width*.18)
        self.side = self.back-self.front-self.r
        self.cross = 2*(self.x-self.r)
        self.arc = math.pi*self.r/2
        self.length = 2*self.side+2*self.arc+self.cross

    def point(self, s):
        s = max(0.0, min(self.length, s))
        if s <= self.side:
            x, y, tx, ty = -self.x, self.front+s, 0, 1
        elif s <= self.side+self.arc:
            a = math.pi-(s-self.side)/self.r
            x = -self.x+self.r+self.r*math.cos(a)
            y = self.back-self.r+self.r*math.sin(a)
            tx, ty = math.sin(a), -math.cos(a)
        elif s <= self.side+self.arc+self.cross:
            x = -self.x+self.r+s-self.side-self.arc
            y, tx, ty = self.back, 1, 0
        elif s <= self.side+2*self.arc+self.cross:
            a = math.pi/2-(s-self.side-self.arc-self.cross)/self.r
            x = self.x-self.r+self.r*math.cos(a)
            y = self.back-self.r+self.r*math.sin(a)
            tx, ty = math.sin(a), -math.cos(a)
        else:
            x = self.x
            y = self.back-self.r-(s-self.side-2*self.arc-self.cross)
            tx, ty = 0, -1
        return x, y, -ty, tx, tx, ty

    def height(self, s):
        p = self.point(s)
        return .825+.111*smooth((p[1]-self.front)/(.95*.77))


def sweep_rail(name, path, zfun, width, height, mat, steps=None):
    """A rectangular timber rail with genuinely rounded profile edges."""
    steps = steps or max(64, int(path.length/.018))
    # Eight points replace infinitely sharp longitudinal edges.
    a, b, k = width/2, height/2, min(width,height)*.16
    section = [(-a+k,-b),(a-k,-b),(a,-b+k),(a,b-k),
               (a-k,b),(-a+k,b),(-a,b-k),(-a,-b+k)]
    verts, faces = [], []
    for j in range(steps+1):
        s = path.length*j/steps
        x,y,nx,ny,_,_ = path.point(s)
        z = zfun(s)
        verts.extend((x+nx*u,y+ny*u,z+v) for u,v in section)
    for j in range(steps):
        for k in range(8):
            a=j*8+k; b=j*8+(k+1)%8
            faces.append((a,b,b+8,a+8))
    faces += [tuple(range(7,-1,-1)),tuple(steps*8+k for k in range(8))]
    return c.mesh(name,verts,faces,mat,smooth=True)


def upholstered_wrap(path):
    """Displaced continuous diamond quilting: valleys, buttons and creases.

    The staggered button lattice is continuous across both rounded corners.
    Only a handful of meshes are used even on the largest sofa.
    """
    ns=max(120,int(path.length/.016))
    nz=38
    pitch_x=.232
    pitch_z=.159
    zbase=.239

    def displacement(s,z,edge=True):
        u=s/pitch_x+.28
        v=(z-.325)/pitch_z
        a=u-.5*v
        b=u+.5*v
        qa=abs(a-round(a)); qb=abs(b-round(b))
        diamond=abs(math.sin(math.pi*a)*math.sin(math.pi*b))
        crease=.0045*(math.exp(-(qa/.057)**2)+math.exp(-(qb/.057)**2))
        rj=round(v)
        ui=round(u-.5*rj)+.5*rj
        ds=(u-ui)*pitch_x; dz=(v-rj)*pitch_z
        rr=math.hypot(ds,dz)
        button=.018*math.exp(-(rr/.027)**2)
        pleat=.0021*math.sin(6*math.atan2(dz,ds)+s*.7)*math.exp(-rr/.045)
        offset=.007+.022*diamond**.64-crease-button+pleat
        if edge:
            upper=path.height(s)-.027
            taper=smooth((z-zbase)/.025)*smooth((upper-z)/.025)
            offset*=taper
        return offset

    verts,faces,uvs=[],[],[]
    for j in range(nz+1):
        t=j/nz
        for i in range(ns+1):
            s=path.length*i/ns
            x,y,nx,ny,_,_=path.point(s)
            z=zbase+t*(path.height(s)-.027-zbase)
            d=displacement(s,z)
            verts.append((x+nx*d,y+ny*d,z))
            uvs.append((s,z))
    for j in range(nz):
        for i in range(ns):
            q=j*(ns+1)+i
            faces.append((q,q+ns+1,q+ns+2,q+1))
    c.mesh('Continuous deep diamond-tufted outer upholstery',verts,faces,'cloth',uvs,True)

    # Smooth, softly padded inner wrap. This is deliberately not an exposed
    # succession of rectangular blocks: the actual reference is a tub sofa.
    verts,faces,uvs=[],[],[]
    ni=max(72,int(path.length/.035)); nj=14
    for j in range(nj+1):
        t=j/nj
        for i in range(ni+1):
            s=path.length*i/ni
            x,y,nx,ny,_,_=path.point(s)
            z=.265+t*(path.height(s)-.036-.265)
            fullness=.018*math.sin(math.pi*t)**.6
            # Shallow irregular sewing tension, most evident near the top.
            gather=.0016*math.sin(s*47+math.sin(s*7))*math.exp(-((t-.91)/.14)**2)
            d=-.087-fullness+gather
            verts.append((x+nx*d,y+ny*d,z))
            uvs.append((s,z))
    for j in range(nj):
        for i in range(ni):
            q=j*(ni+1)+i
            faces.append((q,q+1,q+ni+2,q+ni+1))
    c.mesh('Continuous padded inner back and arms',verts,faces,'cloth',uvs,True)

    # Closed, upholstered roll across the arm/back top beneath the timber.
    verts,faces=[],[]
    for i in range(ni+1):
        s=path.length*i/ni
        x,y,nx,ny,_,_=path.point(s)
        z=path.height(s)-.035
        verts += [(x+nx*.002,y+ny*.002,z),
                  (x-nx*.090,y-ny*.090,z-.003)]
    for i in range(ni):faces.append((2*i,2*i+1,2*i+3,2*i+2))
    c.mesh('Closed rounded upholstered tub top',verts,faces,'cloth',smooth=True)

    # Boundary cords follow the real curved shell, rather than floating on it.
    top=[];bottom=[]
    for i in range(ni+1):
        s=path.length*i/ni
        x,y,nx,ny,_,_=path.point(s)
        top.append((x+nx*.002,y+ny*.002,path.height(s)-.030))
        bottom.append((x+nx*.002,y+ny*.002,zbase+.006))
    c.curve('Outer upholstery upper welt',top,.0021,'cloth_light')
    c.curve('Outer upholstery lower welt',bottom,.0021,'cloth_light')
    for s in (0,path.length):
        x,y,nx,ny,_,_=path.point(s)
        c.curve('Outer upholstery vertical end welt',
                [(x+nx*.002,y+ny*.002,zbase+.006),
                 (x+nx*.002,y+ny*.002,path.height(s)-.030)],.0021,'cloth_light')

    # Each of these caps is a real flattened fabric-covered button. All are
    # collected into one mesh, preventing excessive object/draw-call counts.
    verts,faces=[],[]
    for j in range(4):
        z=.325+j*pitch_z
        k=0
        while True:
            s=(k+.5*j-.28)*pitch_x
            k+=1
            if s<.065:continue
            if s>path.length-.065:break
            if z>path.height(s)-.075:continue
            x,y,nx,ny,tx,ty=path.point(s)
            d=displacement(s,z)+.002
            center=(x+nx*d,y+ny*d,z)
            base=len(verts); nr=6; na=12
            for v in range(nr+1):
                th=math.pi*v/nr
                for u in range(na+1):
                    a=TAU*u/na
                    tang=.0073*math.sin(th)*math.cos(a)
                    vertical=.0073*math.sin(th)*math.sin(a)
                    normal=.0035*math.cos(th)
                    verts.append((center[0]+tx*tang+nx*normal,
                                  center[1]+ty*tang+ny*normal,center[2]+vertical))
            for v in range(nr):
                for u in range(na):
                    q=base+v*(na+1)+u
                    faces.append((q,q+1,q+na+2,q+na+1))
    c.mesh('Batched fabric-covered recessed tuft buttons',verts,faces,'cloth',smooth=True)


def roundrect(a,b,r,steps=8):
    points=[]
    for cx,cy,start in [(a-r,b-r,0),(-a+r,b-r,math.pi/2),
                        (-a+r,-b+r,math.pi),(a-r,-b+r,3*math.pi/2)]:
        for j in range(steps+1):
            angle=start+math.pi*j/(2*steps)
            points.append((cx+r*math.cos(angle),cy+r*math.sin(angle)))
    return points


def cushion(name,center,dims,rotation=(0,0,0),seat=False,stripe=False,phase=0):
    """Closed six-patch stuffed textile mesh, with genuine seam and folds."""
    holder=c.empty(name,center)
    holder.rotation_euler=rotation
    half=[d/2 for d in dims]
    power=12.0 if seat else 4.3
    resolution=18 if seat else 20

    def shape(q):
        norm=sum(abs(v)**power for v in q)**(1/power)
        p=[half[k]*q[k]/norm for k in range(3)]
        if seat:
            # Weight creates subtle top dishing, while front and back hems
            # gather into small deterministic cloth folds.
            if abs(q[2])>.99:
                edge=math.exp(-((abs(q[1])-.86)/.15)**2)
                folds=.0027*math.sin(q[0]*39+phase+math.sin(q[0]*13))*edge
                p[2]+=math.copysign(folds,q[2])
                if q[2]>0:p[2]-=.0045*(1-q[0]*q[0])*(1-q[1]*q[1])
            if abs(q[1])>.99:
                p[1]+=math.copysign(.0020*math.sin(q[0]*37+phase)*(1-q[2]**2),q[1])
        else:
            # Soft diagonal creases and corner puckers, not noisy crumpling.
            if abs(q[1])>.99:
                edge=math.exp(-((abs(q[0])-.83)/.17)**2)
                edge+=math.exp(-((abs(q[2])-.86)/.15)**2)
                fold=.0047*math.sin(q[0]*30+q[2]*9+phase)*edge
                fullness=.010*(1-q[0]**2)*(1-q[2]**2)
                p[1]+=math.copysign(fullness+fold,q[1])
                p[2]+=.003*math.sin(q[0]*8+phase)*(1-q[0]**2)
        return tuple(p)

    with parent(holder):
        verts,faces,uvs=[],[],[]
        # Ordered in UV space; orientation is corrected explicitly below.
        for axis,sgn in [(0,-1),(0,1),(1,-1),(1,1),(2,-1),(2,1)]:
            other=[i for i in range(3) if i!=axis]
            base=len(verts)
            for j in range(resolution+1):
                for i in range(resolution+1):
                    q=[0.,0.,0.];q[axis]=sgn
                    q[other[0]]=-1+2*i/resolution
                    q[other[1]]=-1+2*j/resolution
                    verts.append(shape(q))
                    uvs.append((q[other[0]]*half[other[0]],q[other[1]]*half[other[1]]))
            # cross(other[0],other[1]) has sign - on Y, + otherwise.
            forward=sgn*(1 if axis!=1 else -1)>0
            for j in range(resolution):
                for i in range(resolution):
                    q=base+j*(resolution+1)+i
                    f=(q,q+1,q+resolution+2,q+resolution+1)
                    faces.append(f if forward else tuple(reversed(f)))
        c.mesh(name+' | tailored, filled cotton',verts,faces,'cloth',uvs,True)
        # Use the exact stuffed surface cross-section for the welt, rather
        # than a separate rounded rectangle that can float at the corners.
        perimeter=[]
        for side in range(4):
            for k in range(18):
                t=-1+2*k/18
                perimeter.append([(1,t),(-t,1),(-1,-t),(t,-1)][side])
        coords=[shape((x,y,0) if seat else (x,0,y)) for x,y in perimeter]
        c.curve(name+' | sewn perimeter piping',coords,.0020 if seat else .0023,'cloth_light',True)
        if stripe:
            # A physical contrasting woven strip across the face of alternate
            # accent pillows, as in the supplied upholstery detail photograph.
            verts=[];faces=[];uvs=[]; nx=8;nz=26
            for j in range(nz+1):
                zz=-.98+1.96*j/nz
                for i in range(nx+1):
                    xx=-.27+.54*i/nx
                    p=shape((xx,-1,zz))
                    verts.append((p[0],p[1]-.0011,p[2]))
                    uvs.append((p[0],p[2]))
            for j in range(nz):
                for i in range(nx):
                    q=j*(nx+1)+i;faces.append((q,q+1,q+nx+2,q+nx+1))
            c.mesh(name+' | woven decorative center band',verts,faces,'cloth_light',uvs,True)
    return holder


def descendants(root):
    yield from root.children_recursive


def normalize(root,body,target):
    """Preserve a floor-centred root and catalogue outside dimensions."""
    bpy.context.view_layer.update()
    graph=bpy.context.evaluated_depsgraph_get()
    # Blender 5.2's legacy curve bounding boxes include the unscaled default
    # point radius (+/-1m), even for a 2mm bevel. Materialise only the tiny
    # sewing cords so that both native audits and GLB inspect actual surfaces.
    # Every welt remains an independently editable named geometry object.
    for obj in list(descendants(root)):
        if obj.type!='CURVE':continue
        evaluated=obj.evaluated_get(graph)
        data=bpy.data.meshes.new_from_object(evaluated)
        sewn=bpy.data.objects.new(obj.name+' | modelled cord',data)
        bpy.context.scene.collection.objects.link(sewn)
        sewn.parent=obj.parent
        sewn.matrix_basis=obj.matrix_basis.copy()
        for face in data.polygons:face.use_smooth=True
        old_data=obj.data
        bpy.data.objects.remove(obj,do_unlink=True)
        if not old_data.users:bpy.data.curves.remove(old_data)
    bpy.context.view_layer.update()
    graph=bpy.context.evaluated_depsgraph_get()
    inverse=root.matrix_world.inverted()
    points=[]
    tris=0
    for obj in descendants(root):
        if obj.type not in {'MESH','CURVE'}:continue
        evaluated=obj.evaluated_get(graph)
        points.extend(inverse@evaluated.matrix_world@Vector(p) for p in evaluated.bound_box)
        if obj.type=='MESH':
            evaluated.data.calc_loop_triangles()
            tris+=len(evaluated.data.loop_triangles)
    lo=[min(v[k] for v in points) for k in range(3)]
    hi=[max(v[k] for v in points) for k in range(3)]
    scale=[target[k]/(hi[k]-lo[k]) for k in range(3)]
    body.scale=scale
    body.location=(-(lo[0]+hi[0])*.5*scale[0],
                   -(lo[1]+hi[1])*.5*scale[1],-lo[2]*scale[2])
    root['mesh_triangles_before_curve_conversion']=tris
    root['catalogue_bounds_normalized']=True
    root['construction_note']='Reference-based editable reconstruction; hidden construction interpreted.'
    bpy.context.view_layer.update()


def create(sku,instance='Madison seating'):
    """Create one reference-faithful product under the current core parent."""
    sku=str(sku)
    width,depth,height,seats,title=SPECS[sku]
    root=c.empty(f'{title} | {sku} | {instance}',props={
        'kind':'product','product_id':sku,'instance_id':instance,
        'dimensions_mm':[round(width*1000),round(depth*1000),round(height*1000)],
        'catalogue_reference':'Madison, printed pages 26–29 and 39',
        'finish':'NO / OA (19/231), high-gloss walnut burl veneer',
        'fabric_reference':'241.228 / 241.227',
    })
    with parent(root):
        body=c.empty('Floor-centred exact catalogue geometry')
    with parent(body):
        path=Wrap(width,depth)
        # Floating inset black plinth, burl apron and two slim gilded inlays.
        c.box('Continuous recessed black plinth',(0,.012,.035),
              (width-.10,depth-.10,.070),'black',.018)
        c.box('Walnut burl structural low base',(0,.008,.155),
              (width-.035,depth-.05,.185),'wood',.025)
        c.box('Front polished walnut burl apron',(0,-depth/2+.019,.157),
              (width-.045,.045,.156),'wood',.007)
        for z in (.105,.211):
            c.box('Fine continuous gold front-base inlay',(0,-depth/2-.005,z),
                  (width-.057,.0045,.0047),'gold',.0009)
        # The top edge is a continuous U, including genuinely round corners.
        sweep_rail('High-gloss curved walnut crown rail',path,path.height,.047,.032,'wood')
        sweep_rail('Walnut burl outer lower tub rail',path,lambda s:.213,.049,.040,'wood')
        for s in (0,path.length):
            x,y,nx,ny,_,_=path.point(s)
            h=path.height(s)
            c.box('Walnut vertical arm-front stile',(x,y-.007,(h+.073)/2),
                  (.045,.051,h-.073),'wood',.008)
            # Inner upholstered cap hides the non-engineered shell interior.
            c.box('Padded inner arm-front closure',(x-nx*.050,y+.014,(h+.25)/2),
                  (.068,.032,h-.25),'cloth',.014)
        upholstered_wrap(path)

        interior=width-.263
        gap=.010
        seatwidth=(interior-(seats-1)*gap)/seats
        for j in range(seats):
            xx=-interior/2+seatwidth/2+j*(seatwidth+gap)
            cushion(f'Seat {j+1}',(xx,-.075,.382),
                    (seatwidth,.704,.218),seat=True,phase=j*1.7)

        # Four loose pillows on sofas; two slightly smaller on the armchair.
        size=.365 if seats==1 else .405
        if seats==1:
            accents=[(-.136,.179,True,-.085),(.132,.148,False,.080)]
        else:
            end=width/2-.340
            accents=[(-end,.177,True,-.12),(-end+.300,.138,False,.08),
                     (end-.300,.137,False,-.08),(end,.178,True,.12)]
        for k,(xx,yy,stripe,rz) in enumerate(accents):
            cushion(f'Loose accent cushion {k+1}',(xx,yy,.673),
                    (size,.125,size),(.14,(-.04 if xx<0 else .04),rz),
                    stripe=stripe,phase=k*2.14)
    normalize(root,body,(width,depth,height))
    return root
