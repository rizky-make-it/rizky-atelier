"""Reopen and audit exact dimensions, packed maps, premium geometry and source."""
import bpy,json,sys,math
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent
scene=bpy.context.scene;assert scene.get('collection')=='MADISON'
roots=[o for o in scene.objects if o.get('kind')=='product'];source=json.loads((BASE/'reference/products.json').read_text());expected={p['sku']:p for p in source['products']}
assert len(roots)==12 and set(o['product_id'] for o in roots)==set(expected)
assert scene.get('walls')==0 and scene.get('roof')==False
assert not [o for o in scene.objects if o.get('kind')=='articulation'],'No unsupported opening hardware'
audit=[];dg=bpy.context.evaluated_depsgraph_get()
for root in roots:
    points=[];triangles=0
    for obj in root.children_recursive:
        if obj.type not in {'MESH','CURVE'}:continue
        e=obj.evaluated_get(dg);data=e.to_mesh();data.calc_loop_triangles();triangles+=len(data.loop_triangles)
        mat=root.matrix_world.inverted()@obj.matrix_world
        points.extend(mat@v.co for v in data.vertices);e.to_mesh_clear()
    dims=[(max(v[a] for v in points)-min(v[a] for v in points))*1000 for a in range(3)]
    target=expected[root['product_id']]['dimensions_mm'];delta=[abs(a-b) for a,b in zip(dims,target)]
    assert all(d<7 for d in delta),(root.name,dims,target)
    assert triangles>3000,(root.name,triangles)
    audit.append({'sku':root['product_id'],'instance':root['instance_id'],'catalogue_mm':target,'geometry_mm':[round(d,2) for d in dims],'max_error_mm':round(max(delta),3),'triangles':triangles})
images=[i for i in bpy.data.images if i.source=='FILE' and i.type=='IMAGE']
assert len(images)>=4 and all(i.packed_file or i.packed_files for i in images)
cameras=[o for o in scene.objects if o.type=='CAMERA'];assert len(cameras)==7
report={'ok':True,'scene':bpy.data.filepath,'uniqueSKUs':8,'placements':len(roots),'unsupportedMovingParts':0,'packedImages':len(images),'cameras':len(cameras),'walls':0,'roof':False,'resolution':[scene.render.resolution_x,scene.render.resolution_y],'bounds':audit,'sourcePDFSHA256':source['source_pdf_sha256'],'materials':'Authored procedural visual interpretations of supplied catalogue; not manufacturer CAD'}
(BASE/'native-audit.json').write_text(json.dumps(report,indent=2));print('MADISON_NATIVE_AUDIT',json.dumps(report),flush=True)
