"""Package genuine Madison native/GLB/render assets into the existing flagship."""
from pathlib import Path
import sys,json,shutil,hashlib,struct,zipfile
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'.local/catalogue-review/packages'))
import pymupdf as fitz
DIST=ROOT/'sites/rizky-atelier/dist';ASSET=DIST/'assets/collections/madison';DOWN=DIST/'downloads/madison'
ASSET.mkdir(parents=True,exist_ok=True);DOWN.mkdir(parents=True,exist_ok=True)
source=json.loads((BASE/'reference/products.json').read_text());proof={};copies=[]
models=json.loads((ASSET/'products.json').read_text())
for p in models:p['category']='seating' if p['sku'] in ('50532.0','50533.0','50534.0') else 'storage' if p['sku']=='50536.0' else 'tables'
(ASSET/'products.json').write_text(json.dumps(models,indent=2),encoding='utf8')
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    raw=dst.read_bytes();copies.append({'destination':str(dst.relative_to(DIST)).replace('\\','/'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
for name in ('overview','salon','lounge','consoles','cabinet','detail-burl','detail-tuft'):
    filename=name+('.png' if name.startswith('detail') else '-4k.png');src=BASE/'renders'/filename;raw=src.read_bytes();w,h=struct.unpack('>II',raw[16:24])
    if not name.startswith('detail'):assert (w,h)==(3840,2160)
    copy(src,DOWN/filename);pix=fitz.Pixmap(str(src))
    if w>1920:pix=fitz.Pixmap(pix,1920,round(h*1920/w))
    pix.save(str(ASSET/(name+'.jpg')),jpg_quality=93)
    proof[name]={'file':filename,'width':w,'height':h,'sha256':hashlib.sha256(raw).hexdigest(),'engine':'BLENDER_EEVEE','nativeScene':'madison-exhibition.blend','originalBlenderRender':True}
for p in source['products']:
    src=BASE/'reference/catalogue'/(p['sku']+'.jpg');copy(src,ASSET/'catalogue'/src.name)
    assert hashlib.sha256(src.read_bytes()).hexdigest()==p['image']['sha256']
for filename in ('room-living.jpg','room-overhead.jpg'):
    copy(BASE/'reference'/filename,ASSET/filename)
copy(BASE/'madison-exhibition.blend',DOWN/'madison-exhibition.blend')
copy(BASE/'native-audit.json',DOWN/'native-audit.json');copy(BASE/'reference/products.json',ASSET/'source-reference.json')
(DOWN/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
# Include only the Madison reference spreads, not unrelated catalogue sections.
doc=fitz.open(source['source_pdf']);subset=fitz.open();subset.insert_pdf(doc,from_page=12,to_page=19);subset.save(str(DOWN/'MADISON-reference-pages.pdf'),garbage=4,deflate=True);subset.close();doc.close()
sources=('core.py','geometry.py','sofas.py','casegoods.py','build_scene.py','export_web.py','render_scene.py','validate_native.py','prepare_assets.py','scene.json','build-report.json','export-report.json','native-audit.json','README.md')
with zipfile.ZipFile(DOWN/'madison-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for filename in sources:z.write(BASE/filename,'madison/'+filename)
    for p in (BASE/'textures').iterdir():z.write(p,'madison/textures/'+p.name)
    for p in (BASE/'reference/catalogue').iterdir():z.write(p,'madison/reference/catalogue/'+p.name)
    z.write(BASE/'reference/products.json','madison/reference/products.json');z.write(BASE/'madison-exhibition.blend','madison/madison-exhibition.blend')
    z.write(DOWN/'MADISON-reference-pages.pdf','madison/MADISON-reference-pages.pdf')
for p in DOWN.iterdir():assert p.stat().st_size<95*1024*1024,('GitHub file too large',p)
prefix='assets/collections/madison';url='https://rizky-make-it.github.io/rizky-atelier/';repo='https://github.com/rizky-make-it/rizky-atelier'
def render(name,title,caption):return {'image':prefix+'/'+name+'.jpg','title':title,'caption':caption,'request':'the original MADISON Blender render: '+title,'sourceUrl':url+'downloads/madison/'+proof[name]['file']}
def file(title,ext,desc,request,p):return {'title':title,'extension':ext,'description':desc,'request':request,'sourceUrl':url+p}
collection={'id':'madison','name':'MADISON','number':'04','kind':'Catalogue collection','title':'A more considered kind of grandeur.','tagline':'Walnut burl. Bronze. Calacatta.','description':'Eight MARINER catalogue pieces become an open living-gallery study: three deeply upholstered sofas, marble-topped tables, a rounded TV cabinet and two slender consoles. Glossy walnut burl veneer, chased bronze details and taupe textiles echo the supplied classic reference.','finish':'NO / OA (19/231)','hero':prefix+'/salon.jpg','exhibition':prefix+'/madison-exhibition.glb','scene':prefix+'/scene.json','placementCount':12,'movingParts':0,'sourceSite':url+'#/collections/madison','sourceRepo':repo,'productCount':8,'palette':['#64432d','#ad8b48','#eee6d7','#292e2b'],
 'renders':[render('overview','The open Madison gallery','Original Blender exhibition render, 3840 × 2160. No walls or roof.'),render('salon','The grand salon','Three-seat sofa, quilted armchairs, marble coffee table and the TV piece. Original Blender render: 3840 × 2160.'),render('lounge','A quieter conversation','The two-seat lounge and marble-topped tables. Original Blender render: 3840 × 2160.'),render('consoles','Slender expressions','Both catalogue console widths with bronze collars and lower shelves. Original Blender render: 3840 × 2160.'),render('detail-burl','Burl, marble & bronze','Actual Blender detail render, 1600 × 1600.'),render('detail-tuft','Tailored texture','Actual modelled upholstery and tufting, 1600 × 1600.')],
 'materials':[{'image':prefix+'/detail-burl.jpg','title':'Burl & bronze','description':'Authored walnut-burl PBR, a polished Calacatta interpretation and modelled chased metal edging. A native Blender render, not a physical material sample.'},{'image':prefix+'/detail-tuft.jpg','title':'Tailored taupe','description':'Genuine diamond-displaced upholstery, recessed buttons, seat piping and woven-normal fabric. A native Blender render.'}],
 'files':[file('Native Madison exhibition','.BLEND','Eight SKUs, twelve placements, packed PBR maps and six cameras.','the MADISON editable Blender exhibition master (.blend)','downloads/madison/madison-exhibition.blend'),file('Exhibition & individual models','.GLB','Eight inspectable pieces and an optimised open gallery.','the complete MADISON exhibition GLB and eight individual product GLBs',prefix+'/madison-exhibition.glb'),file('Complete rebuild project','.ZIP','Native scene, authored geometry scripts, textures, source references and audit.','the complete MADISON Blender project, textures and rebuild sources','downloads/madison/madison-project.zip'),file('Madison reference spreads','.PDF','Only the Madison pages from the supplied MARINER classic catalogue.','the original MADISON catalogue reference pages','downloads/madison/MADISON-reference-pages.pdf'),file('Original 4K renders','4K PNG','Four actual Blender renders and two material-detail images.','all MADISON original 4K Blender renders and detail images','downloads/madison/render-proof.json')]}
collection['renders'].insert(4,render('cabinet','The rounded TV piece','A front view of the open cubbies, inset marble and fixed burl panel. Original Blender render: 3840 × 2160.'))
collection['files'][0]['description']='Eight SKUs, twelve placements, packed PBR maps and seven cameras.'
collection['files'][-1]['description']='Five actual 4K Blender renders and two material-detail images.'
(ASSET/'collection.json').write_text(json.dumps(collection,indent=2),encoding='utf8')
(BASE/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
(ASSET/'asset-audit.json').write_text(json.dumps({'collection':'MADISON','sourcePDFSHA256':source['source_pdf_sha256'],'files':copies,'renderProof':proof},indent=2),encoding='utf8')
print('MADISON_PACKAGED',json.dumps({'renders':proof,'nativeBytes':(DOWN/'madison-exhibition.blend').stat().st_size,'zipBytes':(DOWN/'madison-project.zip').stat().st_size}),flush=True)
