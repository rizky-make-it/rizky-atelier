"""Rebuild the editable MADISON living collection as a wall-free exhibition."""
import bpy,math,sys,json,random,time
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import core as c
import sofas,casegoods
started=time.perf_counter();random.seed(50532)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.materials();scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='METERS'
scene['collection']='MADISON';scene['layout']='exhibition';scene['walls']=0;scene['roof']=False
scene['reference']='MARINER CLASSIC FURNITURE CATALOG 2023, PDF pages13–20'
c.set_parent(None);staging=c.empty('MADISON | authored open exhibition',props={'kind':'exhibition','walls':0,'roof':False});c.set_parent(staging)
c.box('Continuous pale stone floor',(5,4.7,-.11),(13,12,.22),'stone',.045)['kind']='exhibition-floor'
zones={
 'salon':{'name':'The grand salon','center':[3,6.7],'size':[6.2,6.2],'bounds':[-.4,3.4,6.4,10],'camera':[[5.9,3.2,1.65],[2.7,7.1,.75],45]},
 'lounge':{'name':'The intimate lounge','center':[8.4,7.1],'size':[4,5.3],'bounds':[6.45,4.3,10.5,10],'camera':[[10.2,4.7,1.65],[8.2,7.9,.6],45]},
 'consoles':{'name':'The console gallery','center':[5,1.4],'size':[10.4,3.1],'bounds':[-.4,-.25,10.6,3.05],'camera':[[6,-.8,1.65],[4.8,1.4,.55],43]},
 'aisle':{'name':'The gallery promenade','bounds':[-.4,3.05,10.6,4.3],'camera':[[5.8,3.5,1.65],[8.6,3.5,1.35],45]},
}
for key,z in zones.items():
    if key=='aisle':continue
    x,y=z['center'];w,d=z['size'];c.box('Flush display inlay '+key,(x,y,-.012),(w,d,.025),'plinth',.012)
    c.curve('Fine bronze floor inlay '+key,[(x-w/2,y-d/2,.006),(x+w/2,y-d/2,.006),(x+w/2,y+d/2,.006),(x-w/2,y+d/2,.006)],.0025,'bronze',True)

def rug(name,x,y,w,d):
    c.box(name,(x,y,.015),(w,d,.028),'rug',.012)
    for inset in (.035,.065,.085):
        c.curve(name+' woven border',[(x-w/2+inset,y-d/2+inset,.030),(x+w/2-inset,y-d/2+inset,.030),(x+w/2-inset,y+d/2-inset,.030),(x-w/2+inset,y+d/2-inset,.030)],.0013,'cloth_light',True)
    # Geometric small Art Deco fans echo the quiet catalogue rug styling.
    for i in range(9):
        xx=x-w*.42+i*w*.105
        for sign in (-1,1):
            yy=y+sign*d*.40
            c.curve(name+' fan border',[(xx+.065*math.cos(t*math.pi/12),yy+sign*.065*math.sin(t*math.pi/12),.031) for t in range(13)],.0008,'cloth_light')
rug('Grand salon woven taupe rug',3,6.65,5.55,4.35)
rug('Intimate lounge woven taupe rug',8.3,7.3,3.6,3.6)
placements=[]
def place(sku,zone,position,rotation=0):
    c.set_parent(None)
    module=sofas if sku in ('50532.0','50533.0','50534.0') else casegoods
    root=module.create(sku,instance=zone+'-'+str(len(placements)+1));root.location=position;root.rotation_euler.z=math.radians(rotation);root['room']=zone
    placements.append({'sku':sku,'room':zone,'position':list(position),'rotation':rotation,'instance':root['instance_id']});c.set_parent(staging);return root
place('50532.0','salon',(3,8.04,.030))
place('50534.0','salon',(1.04,6.24,.030),90)
place('50534.0','salon',(4.96,6.24,.030),-90)
place('50535.0','salon',(3,6.30,.030))
place('50353.0','salon',(.95,7.72,.030));place('50353.0','salon',(5.05,7.72,.030))
place('50536.0','salon',(3,4.23,0),180)
place('50533.0','lounge',(8.28,8.04,.030))
place('50353.0','lounge',(9.86,7.65,.030))
place('50535.0','lounge',(8.24,6.49,.030))
place('50537.0','consoles',(2.80,1.55,0))
place('50538.0','consoles',(7.88,1.55,0))

def books(x,y,z):
    for i,mat in enumerate(('black','paper','wood_dark')):c.box('Interpreted design volume',(x,y,z+.013+i*.027),(.24,.17,.026),mat,.002,rot=(0,0,.05*(-1)**i))
def vase(x,y,z):
    c.lathe('Interpreted fluted ceramic vase',(x,y,z),[(0,0),(.09,0),(.12,.03),(.14,.16),(.11,.22),(.055,.24),(.048,.24),(.052,.22)],'ceramic',48)
    for i in range(6):
        a=i*2.4;end=(x+math.cos(a)*.20,y+math.sin(a)*.18,z+.42+i*.024)
        c.rod('Styling olive stem',(x,y,z+.12),end,.0018,'bronze')
        for j in range(2):
            leaf=c.sphere('Styling olive leaf',(end[0]+j*.018,end[1],end[2]-j*.045),(.040,.013,.005),'leaf',12,6);leaf.rotation_euler=(.4,-.4,a)
def crystal(x,y,z):
    c.cylinder('Polished bronze styling tray',(x,y,z+.008),.17,.016,'gold')
    for dx in (-.055,.055):
        c.lathe('Fluted crystal glass',(x+dx,y,z+.020),[(0,0),(.035,0),(.028,.01),(.023,.10),(.033,.17),(.029,.17),(.019,.102),(.024,.015)],'glass',40)
vase(2.68,6.38,.53);books(3.3,6.18,.53);crystal(5.05,7.72,.71)
books(7.75,6.5,.53);vase(8.7,6.55,.53)
vase(2.37,1.55,.90);books(3.22,1.55,.90);crystal(7.88,1.55,.90)
world=bpy.data.worlds.new('MADISON soft ivory studio');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.62,.67,.72,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.45
c.set_parent(None)
c.light('Broad daylight key','AREA',(-3,1,8),1700,(1,.92,.80),target=(4,6,.5),size=7)
c.light('Large neutral fill','AREA',(11,3,8),1450,(.86,.93,1),target=(5,6,.7),size=6)
c.light('Soft rim reflection','AREA',(4,12,7),2100,(1,.94,.83),target=(4,6,.5),size=6)
sun=c.light('Warm directional daylight','SUN',(-4,-6,10),1.15,(1,.94,.84),target=(4,5,0));sun.data.angle=.18
cameras={
 'overview':((15,-10,12.0),(5,4.7,.4),46),
 'salon':((7.4,2.75,2.75),(2.83,6.85,.63),49),
 'lounge':((11.8,3.5,2.7),(8.25,7.4,.65),51),
 'consoles':((10.5,-8,3.5),(5,1.5,.5),48),
 'cabinet':((5.25,8.40,1.60),(3,4.23,.30),58),
 'detail-burl':((3.50,4.90,.48),(3.35,5.65,.39),90),
 'detail-tuft':((5.83,6.10,1.04),(4.96,6.30,.67),80),
}
for key,(loc,target,lens) in cameras.items():
    data=bpy.data.cameras.new('Lens '+key);obj=bpy.data.objects.new('Camera '+key,data);scene.collection.objects.link(obj);obj.location=loc;obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler();data.lens=lens;data.clip_start=.02;data.clip_end=180
scene.camera=bpy.data.objects['Camera salon'];scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=True
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast'
scene.render.film_transparent=False;scene.render.image_settings.compression=25
info={'collection':'MADISON','units':'metres','layout':'exhibition','walls':0,'roof':False,'floorBounds':[-1,-1,11,10.5],'rooms':zones,'placements':placements,'colliders':[],
      'overview':{'position':[15,12,10],'target':[5,.4,-4.7],'fov':45},'source':'CLASSIC_FURNITURE_CATALOG_2023.pdf','sourcePages':list(range(13,21)),'finish':'NO / OA (19/231)',
      'interpretations':['Open exhibition and complementary styling','Unseen joinery and underside details','Procedural material calibration','Fixed TV centre panel; no unverified opening hardware']}
scene['web_scene_info']=json.dumps(info);(BASE/'scene.json').write_text(json.dumps(info,indent=2),encoding='utf8')
# Keep authored product pieces in accessible native Blender collections.
def ancestor(obj):
    while obj:
        if obj.get('kind')=='product':return obj
        obj=obj.parent
    return None
product_cols={}
for obj in list(scene.objects):
    root=ancestor(obj)
    if not root:continue
    if root.name not in product_cols:
        col=bpy.data.collections.new(root['product_id']+' | '+root['instance_id']);scene.collection.children.link(col);product_cols[root.name]=col
    col=product_cols[root.name];col.objects.link(obj)
    for old in list(obj.users_collection):
        if old!=col:old.objects.unlink(obj)
bpy.ops.file.pack_all()
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.region_3d.view_camera_zoom=0
            area.spaces.active.shading.type='MATERIAL'
report={'collection':'MADISON','products':8,'placements':len(placements),'movingParts':0,'objects':len(scene.objects),'meshes':sum(o.type=='MESH' for o in scene.objects),'walls':0,'roof':False,'seconds':round(time.perf_counter()-started,2)}
(BASE/'build-report.json').write_text(json.dumps(report,indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'madison-exhibition.blend'),compress=True)
print('MADISON_BUILD_COMPLETE',json.dumps(report),flush=True)
