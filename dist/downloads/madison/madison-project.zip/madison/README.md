# MADISON — classic living collection

Independent visual reconstruction by Muhammad Rizky from the owner-supplied
MARINER CLASSIC FURNITURE CATALOG 2023, PDF pages13–20 (printed24–39).

Eight distinct catalogue items: 50532.0 /50533.0 /50534.0 sofas,50535.0 coffee,
50353.0 side table,50536.0 TV furniture,50537.0 /50538.0 consoles. Dimensions
are width × depth × height in millimetres; round tables use diameter for width
and depth. Exact source dimensions, images and source SHA256 are in
reference/products.json. Seven images retain original JPEG bytes; the
armchair is a native-resolution lifestyle crop. No AI enhancement.

The native madison-exhibition.blend contains12 placements, editable product
collections, seven cameras, packed authored PBR maps, real tuft/button/cushion
geometry, modelled bronze relief and an open exhibition with no walls/roof.
The TV's centre panel is fixed: the reference does not establish its hardware.
Sofa seat cushions are distinct3/2/1 counts. Dark wood is an interpretation
of high-gloss walnut burl VENEER, not a claim of solid walnut construction.

Rebuild with Blender5.2 background mode and --python build_scene.py. Reopen
the saved native scene with --python validate_native.py, then export_web.py
and render_scene.py -- all. Render defaults to EEVEE; --cycles selects Cycles.
Five room/product views are3840×2160; two details1600×1600. prepare_assets.py packages
to the existing Rizky Atelier website. Python/PyMuPDF is required for PDF/image
packaging; use your own installed package or the documented workspace path.

Native source maps are authored procedural walnut burl, Calacatta and woven
taupe interpretations, not measured manufacturer PBR. Unseen construction,
exact cast ornament motifs, marble-vein placement, fabric/finish calibration,
complementary staging and coffee-table hidden leg count are interpretations.
Original designs/catalogue images remain with their rights holders. Confirm
commercial reuse permission with MARINER. This is not official manufacturer
CAD, fabrication documentation, an endorsed storefront or a purchase system.

The browser GLBs use reduced display geometry and embedded texture maps;
lighting/gloss differ from native renders. Native geometry is preserved in
the .blend. Every file request on the website opens Muhammad Rizky's WhatsApp
draft; no message sends automatically. Public assets remain directly accessible.
