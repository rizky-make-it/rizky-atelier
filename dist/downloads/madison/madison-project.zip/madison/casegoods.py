"""MADISON casegoods reconstructed from original Mariner catalogue photographs.

Metric geometry, local X width / Y depth (front -Y) / Z up.  This is an
independent visual reconstruction, not manufacturer CAD or certified joinery.
All five items are fixed assemblies: the catalogue does not demonstrate any
opening mechanism for the TV centre panel, so none is invented here.

Public API: create(sku, instance='main') -> product empty, at floor centre.
Call core.materials() first.  Only the caller-owned core.PARENT is modified,
and its previous value is restored even if geometry construction raises.
"""
import math
from contextlib import contextmanager
from mathutils import Vector
import core as c

TAU = math.tau
SPECS = {
    '50535.0': ('Madison coffee table', (1500, 1500, 500)),
    '50353.0': ('Madison side table', (500, 500, 680)),
    '50536.0': ('Madison TV furniture', (2200, 450, 600)),
    '50537.0': ('Madison console 170', (1700, 450, 900)),
    '50538.0': ('Madison console 100', (1000, 450, 900)),
}


@contextmanager
def parent_to(ob):
    previous = c.PARENT
    c.set_parent(ob)
    try:
        yield
    finally:
        c.set_parent(previous)


class Relief:
    """Batch the fine casting/chasing into a small number of material meshes."""
    def __init__(self):
        self.data = {}

    def part(self, material):
        return self.data.setdefault(material, [[], []])

    def tube(self, points, radius, material='gold', sides=5, closed=False):
        if len(points) < 2:
            return
        points = [Vector(p) for p in points]
        if closed:
            points.append(points[0])
        verts, faces = self.part(material)
        base = len(verts)
        previous_u = None
        for i, point in enumerate(points):
            tangent = points[min(i+1, len(points)-1)]-points[max(0, i-1)]
            if tangent.length < 1.e-9:
                tangent = Vector((0, 0, 1))
            tangent.normalize()
            reference = Vector((0, 0, 1)) if abs(tangent.z) < .94 else Vector((1, 0, 0))
            u = tangent.cross(reference).normalized()
            if previous_u is not None and u.dot(previous_u) < 0:
                u.negate()
            v = tangent.cross(u).normalized()
            previous_u = u
            for j in range(sides):
                a = j*TAU/sides
                verts.append(tuple(point+radius*(u*math.cos(a)+v*math.sin(a))))
        for i in range(len(points)-1):
            for j in range(sides):
                q = base+i*sides+j
                r = base+i*sides+(j+1) % sides
                faces.append((q, r, r+sides, q+sides))
        faces.append(tuple(base+i for i in reversed(range(sides))))
        end = base+(len(points)-1)*sides
        faces.append(tuple(end+i for i in range(sides)))

    def bead(self, center, radius, material='gold', segments=6, rings=4):
        verts, faces = self.part(material)
        base = len(verts)
        for j in range(rings+1):
            t = math.pi*j/rings
            for i in range(segments):
                a = TAU*i/segments
                verts.append((center[0]+radius*math.sin(t)*math.cos(a),
                              center[1]+radius*math.sin(t)*math.sin(a),
                              center[2]+radius*math.cos(t)))
        for j in range(rings):
            for i in range(segments):
                q = base+j*segments+i
                n = base+j*segments+(i+1) % segments
                faces.append((q, n, n+segments, q+segments))

    def leaf(self, center, angle, z0, height, lower_radius, upper_radius):
        """Embossed tapered acanthus blade, with a raised midrib and lobes."""
        verts, faces = self.part('bronze')
        start = len(verts)
        for j in range(11):
            t = j/10
            width = .135*math.sin(math.pi*t)**.75*(.8+.2*math.cos(6*math.pi*t))
            radial = lower_radius+(upper_radius-lower_radius)*t
            for k in range(5):
                s = (k-2)/2
                a = angle+s*width
                raised = .0016*(1-s*s)*math.sin(math.pi*t)
                r = radial+.001+raised
                verts.append((center[0]+r*math.cos(a), center[1]+r*math.sin(a), z0+height*t))
        for j in range(10):
            for k in range(4):
                q = start+j*5+k
                faces.append((q, q+1, q+6, q+5))
        self.tube([(center[0]+(lower_radius+(upper_radius-lower_radius)*t+.003)*math.cos(angle),
                    center[1]+(lower_radius+(upper_radius-lower_radius)*t+.003)*math.sin(angle),
                    z0+height*t) for t in [i/12 for i in range(13)]], .00065, 'gold', 4)

    def finish(self, prefix):
        for material, (verts, faces) in self.data.items():
            if verts:
                c.mesh(prefix+' | '+material+' modelled relief', verts, faces, material, smooth=True)


def roundrect(w, d, radius, samples=16):
    r = min(radius, w/2, d/2)
    points = []
    for x, y, a0 in [(w/2-r, d/2-r, 0), (-w/2+r, d/2-r, math.pi/2),
                     (-w/2+r, -d/2+r, math.pi), (w/2-r, -d/2+r, 3*math.pi/2)]:
        for j in range(samples+1):
            a = a0+j*math.pi/(2*samples)
            points.append((x+r*math.cos(a), y+r*math.sin(a)))
    return points


def slab(name, w, d, corner, bottom, top, mat, inset=.0025):
    """Solid rounded slab with genuine bevel rings (no render-only bevel)."""
    edge = min(inset, (top-bottom)*.22)
    profile = [(w-2*edge, d-2*edge, corner-edge, bottom),
               (w, d, corner, bottom+edge), (w, d, corner, top-edge),
               (w-2*edge, d-2*edge, corner-edge, top)]
    verts, faces = [], []
    for ww, dd, rr, z in profile:
        verts.extend((x, y, z) for x, y in roundrect(ww, dd, max(.002, rr)))
    n = len(verts)//len(profile)
    for j in range(len(profile)-1):
        for i in range(n):
            q = j*n+i
            faces.append((q, j*n+(i+1) % n, (j+1)*n+(i+1) % n, q+n))
    faces.extend([tuple(reversed(range(n))), tuple((len(profile)-1)*n+i for i in range(n))])
    return c.mesh(name, verts, faces, mat, smooth=False)


def outline(name, w, d, corner, z, radius, mat='gold'):
    return c.curve(name, [(x, y, z) for x, y in roundrect(w, d, corner)], radius, mat, cyclic=True)


def circular_slab(name, radius, bottom, top, mat, segments=128):
    e = min(.0023, (top-bottom)*.2)
    ob = c.lathe(name, (0, 0, 0), [(0, bottom), (radius-e, bottom), (radius, bottom+e),
                                (radius, top-e), (radius-e, top), (0, top)], mat, segments)
    # The lathe's cylindrical UVs are useful on the burl apron, but collapse a
    # flat cap to a line. Give the marble and shelf caps their proper planar
    # mapping so the Calacatta veins run across the whole real stone surface.
    uv = ob.data.uv_layers.active
    for polygon in ob.data.polygons:
        if abs(polygon.normal.z) > .8:
            polygon.use_smooth = False
            for li in polygon.loop_indices:
                co = ob.data.vertices[ob.data.loops[li].vertex_index].co
                uv.data[li].uv = (co.x/(radius*2)+.5, co.y/(radius*2)+.5)
    return ob


def circular_chasing(relief, radius, z, band_height, units):
    """Linked leaf/lozenge chasing, deliberately restrained at catalogue scale."""
    for i in range(units):
        a0 = i*TAU/units
        # Fine repeating foliate diamonds on the substantial gold fillet.
        pts = []
        for j in range(17):
            t = j/16
            a = a0+t*TAU/units
            zz = z+band_height*.34*math.sin(TAU*t)
            pts.append((radius*math.cos(a), radius*math.sin(a), zz))
        relief.tube(pts, .00048, 'bronze', 4)
        a = a0+TAU/(2*units)
        relief.bead((radius*math.cos(a), radius*math.sin(a), z), .0009, 'gold', 5, 3)


def perimeter_chasing(relief, w, d, corner, z, band_height):
    path = roundrect(w, d, corner, 28)
    # Resample by arc length, so relief density does not pile up at corners.
    lengths = [0.0]
    for i in range(len(path)):
        a, b = path[i], path[(i+1) % len(path)]
        lengths.append(lengths[-1]+math.hypot(b[0]-a[0], b[1]-a[1]))
    total = lengths[-1]
    units = max(20, int(total/.025))
    points = []
    index = 0
    for j in range(units*10+1):
        dist = total*j/(units*10)
        while index < len(path)-1 and lengths[index+1] < dist:
            index += 1
        a, b = path[index], path[(index+1) % len(path)]
        t = (dist-lengths[index])/max(1.e-9, lengths[index+1]-lengths[index])
        points.append((a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t,
                       z+band_height*.34*math.sin(TAU*j/10)))
    relief.tube(points, .0005, 'bronze', 4)


def leg(name, x, y, apron_bottom, relief, foot_height=.052, radius=.018, collar_height=.112):
    """Long ebony taper, cast foliate bronze collar and turned gilt toe."""
    shoulder = apron_bottom-collar_height
    c.lathe(name+' | tapered ebony', (x, y, 0),
            [(0, foot_height-.006), (radius*.56, foot_height-.006),
             (radius*.67, foot_height+.018), (radius*.92, shoulder-.012),
             (radius, shoulder+.007), (0, shoulder+.007)], 'black', 32)
    c.lathe(name+' | turned gold toe', (x, y, 0),
            [(0, 0), (radius*.44, 0), (radius*.51, .008),
             (radius*.63, foot_height-.004), (radius*.68, foot_height),
             (radius*.68, foot_height+.004), (0, foot_height+.004)], 'gold', 32)
    bottom_r, top_r = radius*1.02, radius*1.33
    c.lathe(name+' | acanthus cast collar', (x, y, 0),
            [(0, shoulder), (bottom_r, shoulder), (bottom_r*1.07, shoulder+.005),
             (bottom_r, shoulder+.011), (top_r*.93, apron_bottom-.019),
             (top_r*1.12, apron_bottom-.009), (top_r*1.2, apron_bottom-.004),
             (top_r*1.16, apron_bottom), (0, apron_bottom)], 'bronze', 48)
    for j in range(8):
        a = j*TAU/8
        relief.leaf((x, y), a, shoulder+.012, collar_height-.031, bottom_r, top_r*.94)
        # Small flutes between the cast acanthus leaves.
        angle = a+TAU/16
        relief.tube([(x+(bottom_r+(top_r-bottom_r)*t+.0007)*math.cos(angle),
                      y+(bottom_r+(top_r-bottom_r)*t+.0007)*math.sin(angle),
                      shoulder+.014+(collar_height-.035)*t) for t in [k/8 for k in range(9)]],
                    .00055, 'gold', 4)
    for z, rad in [(shoulder+.004, bottom_r*1.06), (apron_bottom-.007, top_r*1.13)]:
        relief.tube([(x+rad*math.cos(a*TAU/48), y+rad*math.sin(a*TAU/48), z)
                     for a in range(48)], .0012, 'gold', 5, True)
    # Rosette/cast pearl ring just beneath the apron; batched, not 24 objects.
    for k in range(24):
        a = k*TAU/24
        relief.bead((x+top_r*1.12*math.cos(a), y+top_r*1.12*math.sin(a), apron_bottom-.010),
                    .0015, 'gold', 5, 3)


def round_table(sku):
    coffee = sku == '50535.0'
    diameter, height = (1.5, .5) if coffee else (.5, .68)
    radius = diameter/2
    apron_bottom = height-(.105 if coffee else .105)
    marble_bottom = height-.023
    relief = Relief()
    circular_slab('Solid polished burl circular apron', radius-.002, apron_bottom, marble_bottom, 'wood')
    circular_slab('Inset Calacatta marble | softened stone edge', radius-.008, marble_bottom, height, 'marble')
    # Double inlaid gold fillets at each apron edge; each is true geometry.
    for z, depth in [(apron_bottom+.007, .010), (marble_bottom-.006, .008)]:
        circular_slab('Gilt chased rim fillet', radius, z-depth/2, z+depth/2, 'gold')
        circular_chasing(relief, radius+.00005, z, depth, 170 if coffee else 62)
    for z in [apron_bottom+.015, marble_bottom-.013]:
        circular_slab('Burl apron fine shadow bead', radius-.001, z-.0014, z+.0014, 'bronze')
    shelf_z = .102 if coffee else .141
    shelf_r = radius-(.025 if coffee else .018)
    circular_slab('Glossy dark lower display shelf', shelf_r, shelf_z, shelf_z+.017, 'wood_dark')
    circular_slab('Lower shelf gold perimeter', shelf_r+.001, shelf_z-.002, shelf_z+.007, 'gold')
    circular_slab('Lower shelf dark upper inset', shelf_r-.005, shelf_z+.007, shelf_z+.018, 'wood_dark')
    count = 6 if coffee else 3
    leg_radius = radius-(.082 if coffee else .045)
    for i in range(count):
        a = -math.pi/2+i*TAU/count
        x, y = leg_radius*math.cos(a), leg_radius*math.sin(a)
        leg('Leg %02d' % (i+1), x, y, apron_bottom, relief,
            .057 if coffee else .060, .019 if coffee else .017, .107 if coffee else .125)
        # Tidy shelf collars where the legs penetrate the display tier.
        c.lathe('Shelf socket %02d' % (i+1), (x, y, 0),
                [(0, shelf_z-.003), (.017, shelf_z-.003), (.017, shelf_z+.025), (0, shelf_z+.025)],
                'black', 24)
    relief.finish('Cast and chased round table details')


def console(sku):
    w = 1.7 if sku == '50537.0' else 1.0
    d, h, corner = .45, .9, .043
    relief = Relief()
    apron_bottom, marble_bottom = .807, .879
    slab('Burl veneered slim rounded console apron', w-.003, d-.003, corner, apron_bottom, marble_bottom, 'wood')
    slab('Inset Calacatta marble console top', w-.012, d-.012, corner-.006, marble_bottom, h, 'marble')
    for z, depth in [(apron_bottom+.006, .009), (marble_bottom-.005, .007)]:
        slab('Chased gold console perimeter', w, d, corner, z-depth/2, z+depth/2, 'gold', .001)
        perimeter_chasing(relief, w+.00005, d+.00005, corner, z, depth)
    for z in [apron_bottom+.014, marble_bottom-.012]:
        outline('Fine bronze beading along burl apron', w-.002, d-.002, corner, z, .0012, 'bronze')
    # Shelf has a real dark top, not only four horizontal support rods.
    shelf_z = .154
    slab('Long lower lacquer display shelf', w-.022, d-.025, corner-.007, shelf_z, shelf_z+.015, 'wood_dark')
    slab('Gold edge on lower console shelf', w-.019, d-.022, corner-.005, shelf_z-.003, shelf_z+.006, 'gold')
    slab('Inset ebony lower shelf face', w-.032, d-.035, corner-.011, shelf_z+.006, shelf_z+.016, 'wood_dark')
    for i, (x, y) in enumerate([(x, y) for x in [-w/2+.046, w/2-.046] for y in [-d/2+.043, d/2-.043]]):
        leg('Console leg %02d' % (i+1), x, y, apron_bottom, relief, .055, .017, .108)
    relief.finish('Console fine cast and chased details')


def wrap_end(name, side, w, d, radius, thickness, z0, z1):
    """Round wraparound end wall, open at front rather than a box cabinet."""
    points = []
    # Right-hand U-return: front, convex side, back. Mirror for left end.
    for j in range(21):
        a = -math.pi/2+j*math.pi/40
        points.append((w/2-radius+radius*math.cos(a), -d/2+radius+radius*math.sin(a)))
    for j in range(21):
        a = j*math.pi/40
        points.append((w/2-radius+radius*math.cos(a), d/2-radius+radius*math.sin(a)))
    verts, faces = [], []
    for z in [z0, z1]:
        for inner in [False, True]:
            for x, y in points:
                # A parallel inner curve with the same nominal corner centre.
                if inner:
                    center_y = -d/2+radius if y < 0 else d/2-radius
                    center_x = w/2-radius
                    delta = Vector((x-center_x, y-center_y))
                    if delta.length:
                        delta.normalize()
                    x -= thickness*delta.x
                    y -= thickness*delta.y
                verts.append((side*x, y, z))
    n = len(points)
    for i in range(n-1):
        faces.extend([(i, i+1, 2*n+i+1, 2*n+i),
                      (n+i+1, n+i, 3*n+i, 3*n+i+1),
                      (i+1, i, n+i, n+i+1),
                      (2*n+i, 2*n+i+1, 3*n+i+1, 3*n+i)])
    faces.extend([(0, 2*n, 3*n, n), (n-1, 2*n-1, 4*n-1, 3*n-1)])
    return c.mesh(name, verts, faces, 'wood', smooth=True)


def vertical_panel_outline(name, w, h, corner, y, center_z, radius, material):
    points = [(x, y, center_z+z) for x, z in roundrect(w, h, corner, 20)]
    return c.curve(name, points, radius, material, cyclic=True)


def tv_furniture():
    w, d, h = 2.2, .45, .6
    relief = Relief()
    slab('Recessed ebony plinth', 2.14, .411, .084, 0, .032, 'black')
    slab('Burl wraparound bottom rail', w-.004, d-.004, .097, .025, .065, 'wood')
    slab('Dark polished open cubby floor', 2.102, .407, .073, .063, .078, 'wood_dark')
    wrap_end('Left continuous rounded burl end', -1, w, d, .10, .033, .040, .568)
    wrap_end('Right continuous rounded burl end', 1, w, d, .10, .033, .040, .568)
    c.box('Dark back panel visible inside open cubbies', (0, .204, .282), (2.012, .022, .423), 'wood_dark', .003)
    # Central fixed panel and two real open cavities, with no invented handles.
    c.box('Fixed central burl feature panel | NOT an animated door', (0, -.207, .264), (.604, .032, .401), 'wood', .012)
    c.box('Left centre divider', (-.317, .003, .274), (.027, .402, .401), 'wood_dark', .003)
    c.box('Right centre divider', (.317, .003, .274), (.027, .402, .401), 'wood_dark', .003)
    for x in [-1.014, 1.014]:
        c.box('Polished dark rounded front corner stile', (x, -.210, .274), (.027, .035, .409), 'black', .010)
    vertical_panel_outline('Outer rounded gold inlay on fixed centre panel', .558, .351, .043, -.2251, .264, .0024, 'gold')
    vertical_panel_outline('Inner rounded gold inlay on fixed centre panel', .535, .328, .038, -.2254, .264, .00135, 'gold')
    # The top is a recessed stone tray inside a raised dark wraparound rim.
    slab('Burl front and perimeter top fascia', w, d, .10, .468, .553, 'wood')
    slab('Top fascia lower gilt fillet', w-.001, d-.001, .10, .469, .476, 'gold', .001)
    perimeter_chasing(relief, w-.001, d-.001, .10, .4725, .006)
    slab('Top fascia upper gilt fillet', w-.001, d-.001, .10, .548, .555, 'gold', .001)
    perimeter_chasing(relief, w-.001, d-.001, .10, .5515, .006)
    slab('Dark polished tray support', w-.010, d-.010, .097, .554, .575, 'wood_dark')
    slab('Recessed Calacatta marble tray surface', w-.048, d-.048, .078, .568, .586, 'marble', .002)
    # Sculpted continuous lip: front lower than sides/back, as in source.
    front = [(-w/2+.10, -d/2+.009, .579), (w/2-.10, -d/2+.009, .579)]
    c.curve('Low front polished marble retaining lip', front, .008, 'black')
    rimpath = roundrect(w-.016, d-.016, .092, 24)
    # Raise the back and sides; original catalogue shows a lipped tray silhouette.
    lip = []
    for x, y in rimpath:
        transition = min(1, max(0, (y+d/2-.015)/.065))
        z = .579+.013*transition
        lip.append((x, y, z))
    c.curve('Raised rounded ebony tray perimeter', lip, .008, 'black', cyclic=True)
    relief.finish('TV furniture chased gilt perimeter')


def create(sku, instance='main'):
    sku = str(sku)
    if sku not in SPECS:
        raise ValueError('Unknown Madison casegood SKU: '+sku)
    name, dimensions = SPECS[sku]
    root = c.empty(name+' | '+str(instance), props={
        'kind': 'product', 'product_id': sku, 'instance_id': str(instance),
        'dimensions_mm': list(dimensions), 'collection': 'Madison',
        'source': 'CLASSIC_FURNITURE_CATALOG_2023.pdf / original Madison photographs',
        'reconstruction_note': 'Visual reconstruction; hidden joinery and calibrated physical finish are not manufacturer-certified.',
        'moving_parts': 0,
    })
    with parent_to(root):
        if sku in ['50535.0', '50353.0']:
            round_table(sku)
        elif sku == '50536.0':
            tv_furniture()
        else:
            console(sku)
    return root
