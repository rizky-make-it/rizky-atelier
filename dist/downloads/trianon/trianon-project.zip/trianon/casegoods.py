"""TRIANON living-room casegoods, reconstructed from Mariner catalogue p44–47.

Native metric mesh geometry: X width, Y depth (front -Y), Z up. The apron
carvings, flutes, capitals, rosettes and gilt sabots are geometry, never photo
planes. Four fixed assemblies: no unsupported drawers or moving hardware.
The rectangular 50476.1 adapts the visible square-table design to its printed
170 x 95 cm footprint; the spread supplies one shared table close-up.
This is an independent visual reconstruction, not official manufacturer CAD.
"""
import math
from contextlib import contextmanager
from mathutils import Vector
import core as c

TAU = math.tau
SPECS = {
    '50476.1': ('Trianon rectangular Emperor coffee table', (1700, 950, 470)),
    '50475.1': ('Trianon square Emperor coffee table', (1400, 1400, 470)),
    '50411.0': ('Trianon Calacatta console', (1310, 490, 880)),
    '50412.1': ('Trianon Emperor side table', (710, 710, 630)),
}


@contextmanager
def parent_to(ob):
    previous = c.PARENT
    c.set_parent(ob)
    try:
        yield
    finally:
        c.set_parent(previous)


def bezier(a, b, c0, d, steps=16):
    return [tuple((1-t)**3*a[k]+3*(1-t)**2*t*b[k]+3*(1-t)*t*t*c0[k]+t**3*d[k]
                  for k in range(len(a))) for t in [j/steps for j in range(steps+1)]]


class Relief:
    """Batch many small cast details into one mesh per physical material."""
    def __init__(self):
        self.data = {}

    def part(self, mat):
        return self.data.setdefault(mat, [[], []])

    def tube(self, points, radius, mat='gold', sides=5, closed=False):
        if len(points) < 2:
            return
        points = [Vector(p) for p in points]
        if closed:
            points.append(points[0])
        verts, faces = self.part(mat)
        start = len(verts)
        previous = None
        for i, p in enumerate(points):
            tangent = points[min(i+1, len(points)-1)]-points[max(0, i-1)]
            if tangent.length < 1e-9:
                tangent = Vector((0, 0, 1))
            tangent.normalize()
            ref = Vector((0, 0, 1)) if abs(tangent.z) < .94 else Vector((1, 0, 0))
            u = tangent.cross(ref).normalized()
            if previous is not None and previous.dot(u) < 0:
                u.negate()
            v = tangent.cross(u).normalized()
            previous = u
            for k in range(sides):
                a = TAU*k/sides
                verts.append(tuple(p+radius*(u*math.cos(a)+v*math.sin(a))))
        for j in range(len(points)-1):
            for k in range(sides):
                q = start+j*sides+k
                r = start+j*sides+(k+1) % sides
                faces.append((q, r, r+sides, q+sides))
        faces.append(tuple(start+k for k in reversed(range(sides))))
        last = start+(len(points)-1)*sides
        faces.append(tuple(last+k for k in range(sides)))

    def bead(self, pos, radius, mat='gold', seg=7, rings=4):
        verts, faces = self.part(mat)
        start = len(verts)
        for j in range(rings+1):
            t = math.pi*j/rings
            for k in range(seg):
                a = TAU*k/seg
                verts.append((pos[0]+radius*math.sin(t)*math.cos(a),
                              pos[1]+radius*math.sin(t)*math.sin(a),
                              pos[2]+radius*math.cos(t)))
        for j in range(rings):
            for k in range(seg):
                q = start+j*seg+k
                r = start+j*seg+(k+1) % seg
                faces.append((q, r, r+seg, q+seg))

    def blade(self, mapping, path, width, mat='gold', depth=.0045, lobes=3):
        """A lobed, cupped relief leaf with closed sides and a raised midrib."""
        verts, faces = self.part(mat)
        start = len(verts)
        count = len(path)
        front = []
        for j, (u, v) in enumerate(path):
            t = j/(count-1)
            prev, nxt = path[max(0, j-1)], path[min(count-1, j+1)]
            dx, dy = nxt[0]-prev[0], nxt[1]-prev[1]
            length = max(1e-9, math.hypot(dx, dy))
            px, py = -dy/length, dx/length
            spread = width*math.sin(math.pi*t)**.72*(.76+.24*math.cos(TAU*lobes*t))
            for k in range(3):
                s = k-1
                rise = depth*(.18+.82*(1-s*s))*math.sin(math.pi*t)**.7
                front.append(mapping(u+px*s*spread, v+py*s*spread, rise))
        verts.extend(front)
        # Reverse face at the mount plane gives an actual embossed solid.
        for j, (u, v) in enumerate(path):
            t = j/(count-1)
            prev, nxt = path[max(0, j-1)], path[min(count-1, j+1)]
            dx, dy = nxt[0]-prev[0], nxt[1]-prev[1]
            length = max(1e-9, math.hypot(dx, dy))
            px, py = -dy/length, dx/length
            spread = width*math.sin(math.pi*t)**.72*(.76+.24*math.cos(TAU*lobes*t))
            for k in range(3):
                s = k-1
                verts.append(mapping(u+px*s*spread, v+py*s*spread, -.00025))
        n = count*3
        for j in range(count-1):
            for k in range(2):
                q = start+j*3+k
                faces.append((q, q+1, q+4, q+3))
                faces.append((q+n+3, q+n+4, q+n+1, q+n))
            q = start+j*3
            faces.append((q, q+3, q+n+3, q+n))
            q += 2
            faces.append((q+n, q+n+3, q+3, q))
        self.tube([mapping(u, v, depth*.98*math.sin(math.pi*j/(count-1))+.0005)
                   for j, (u, v) in enumerate(path)], min(.00065, width*.085), 'antique_gold', 4)

    def finish(self, name):
        for mat, (verts, faces) in self.data.items():
            if verts:
                c.mesh(name+' | '+mat+' physical relief', verts, faces, mat, smooth=True)


def rectangle(w, d, r=.0025, samples=4):
    r = min(r, w/2, d/2)
    pts = []
    for x, y, a0 in [(w/2-r, d/2-r, 0), (-w/2+r, d/2-r, math.pi/2),
                     (-w/2+r, -d/2+r, math.pi), (w/2-r, -d/2+r, 3*math.pi/2)]:
        for j in range(samples+1):
            a = a0+j*math.pi/(2*samples)
            pts.append((x+r*math.cos(a), y+r*math.sin(a)))
    return pts


def slab(name, w, d, z0, z1, mat, corner=.0025, bevel=.0012):
    """True stepped solid, flat-shaded caps and normalized planar marble UVs."""
    bevel = min(bevel, (z1-z0)*.25)
    profiles = [(w-2*bevel, d-2*bevel, max(.0003, corner-bevel), z0),
                (w, d, corner, z0+bevel), (w, d, corner, z1-bevel),
                (w-2*bevel, d-2*bevel, max(.0003, corner-bevel), z1)]
    verts, faces = [], []
    for ww, dd, rr, z in profiles:
        verts.extend((x, y, z) for x, y in rectangle(ww, dd, rr))
    n = len(verts)//len(profiles)
    for j in range(len(profiles)-1):
        for k in range(n):
            q = j*n+k
            faces.append((q, j*n+(k+1) % n, (j+1)*n+(k+1) % n, q+n))
    faces.extend([tuple(reversed(range(n))), tuple(3*n+k for k in range(n))])
    ob = c.mesh(name, verts, faces, mat, smooth=False)
    uv = ob.data.uv_layers.active
    for p in ob.data.polygons:
        if abs(p.normal.z) > .8:
            for li in p.loop_indices:
                co = ob.data.vertices[ob.data.loops[li].vertex_index].co
                uv.data[li].uv = (co.x/w+.5, co.y/d+.5)
    return ob


def face_mapping(side, fixed, z0, offset=0):
    """u horizontal, v vertical, relief depth outwards from an apron face."""
    if side == 'front':
        return lambda u, v, r: (u, -fixed-offset-r, z0+v)
    if side == 'back':
        return lambda u, v, r: (-u, fixed+offset+r, z0+v)
    if side == 'right':
        return lambda u, v, r: (fixed+offset+r, u, z0+v)
    return lambda u, v, r: (-fixed-offset-r, -u, z0+v)


def scroll_unit(relief, mapping, center, pitch, band_h, mirror=False):
    """A continuous curling stem with four deeply cupped acanthus leaves."""
    scale_x, scale_y = pitch/.084, band_h/.054
    sign = -1 if mirror else 1
    def point(u, v, depth):
        return mapping(center+sign*u*scale_x, v*scale_y, depth)
    stem = bezier((-.040, -.020), (-.025, .027), (.040, .030), (.029, -.002), 14)
    # Complete a returning volute at the end of the stem.
    spiral = []
    for j in range(19):
        t = j/18
        a = -t*TAU*1.05
        r = .011*(1-t)+.0011
        spiral.append((.017+r*math.cos(a), -.002+r*math.sin(a)))
    relief.tube([point(u, v, .004) for u, v in stem+spiral], .0018, 'antique_gold', 5)
    for a, b, ctrl, end, width in [
        ((-.034, -.012), (-.041, .006), (-.029, .023), (-.020, .023), .013),
        ((-.024, .005), (-.029, .022), (-.017, .031), (-.008, .022), .012),
        ((-.010, .015), (-.012, .001), (.003, -.025), (.014, -.022), .013),
        ((.004, .020), (.002, .008), (.014, -.010), (.024, -.009), .010),
    ]:
        path = bezier(a, b, ctrl, end, 7)
        relief.blade(point, path, width, 'gold', .007, 3)


def rosette(relief, mapping, center_u, radius, petals=10, depth=.004):
    """Full petalled bronze flower with raised gilt rim and chased centre."""
    for k in range(petals):
        angle = TAU*k/petals
        ux, vy = math.cos(angle), math.sin(angle)
        path = [(center_u+ux*(radius*.12+radius*.78*t), vy*(radius*.12+radius*.78*t))
                for t in [j/7 for j in range(8)]]
        relief.blade(mapping, path, radius*.205, 'gold', depth, 1)
    relief.tube([mapping(center_u+radius*math.cos(TAU*j/48), radius*math.sin(TAU*j/48), .001)
                 for j in range(48)], .0013, 'antique_gold', 5, True)
    relief.bead(mapping(center_u, 0, depth*.8), radius*.19, 'gold', 9, 5)


def apron_face(relief, side, fixed, length, z_bottom, z_top, block, large=False):
    height = z_top-z_bottom
    zmid = (z_bottom+z_top)/2
    mapping = face_mapping(side, fixed, zmid, .00025)
    # Perimeter double mouldings, front/back centring is symmetrical.
    for zz, radius in [(-height/2+.0055, .002), (-height/2+.0105, .001),
                       (height/2-.0055, .002), (height/2-.011, .001)]:
        relief.tube([mapping(-length/2, zz, .002), mapping(length/2, zz, .002)], radius, 'gold', 6)
    # Narrow egg-and-dart upper band, separate from the acanthus main frieze.
    egg_z = height/2-.021
    units = max(5, int(length/.024))
    pitch = length/units
    for k in range(units):
        u = -length/2+(k+.5)*pitch
        path = [(u+pitch*.29*math.sin(TAU*j/12), egg_z+.007*math.cos(TAU*j/12)) for j in range(13)]
        relief.tube([mapping(x, y, .0015) for x, y in path], .00085, 'gold', 4)
        relief.tube([mapping(u+pitch/2, egg_z-.006, .001), mapping(u+pitch/2, egg_z+.006, .001)], .00065, 'antique_gold', 4)
    # The reference has floral corner blocks with framed square medallions.
    for sign in (-1, 1):
        u = sign*(length/2-block/2)
        span = block*.43
        zb, zt = -height/2+.012, height/2-.033
        relief.tube([mapping(u-span, zb, .004), mapping(u+span, zb, .004),
                     mapping(u+span, zt, .004), mapping(u-span, zt, .004)], .002, 'gold', 5, True)
        center_v = (zt+zb)/2
        local = lambda x, y, r, u=u, center_v=center_v: mapping(x+u, y+center_v, r+.0015)
        rosette(relief, local, 0, min(span*.78, (zt-zb)*.43), 10, .004)
    inside = length-2*block-.012
    band_h = max(.032, height-.055)
    if inside > .1:
        central = .075 if large else .055
        # Continuous main cast-and-carved acanthus; not a flat texture.
        count = max(2, int(inside/.086))
        pitch = inside/count
        for k in range(count):
            u = -inside/2+(k+.5)*pitch
            if side in ('front', 'back') and abs(u) < central/2:
                continue
            local = lambda x, y, r: mapping(x, y-.011, r)
            scroll_unit(relief, local, u, pitch*.97, band_h, k % 2 == 1)
        if side in ('front', 'back'):
            local = lambda x, y, r: mapping(x, y-.009, r+.002)
            rosette(relief, local, 0, min(band_h*.55, central*.44), 12, .004)


def fluted_shaft(name, x, y, z0, z1, r0, r1, flutes=12):
    """Physical concave longitudinal channels in a gently tapered black leg."""
    seg, rows = flutes*6, 9
    verts, faces = [], []
    for j in range(rows+1):
        t = j/rows
        base = r0+(r1-r0)*t
        # Channels die into the unfluted collars at both ends.
        fade = min(1, t*8, (1-t)*9)
        for k in range(seg):
            a = TAU*k/seg
            channel = ((1+math.cos(flutes*a))/2)**3
            r = base*(1-.11*channel*fade)
            verts.append((x+r*math.cos(a), y+r*math.sin(a), z0+(z1-z0)*t))
    for j in range(rows):
        for k in range(seg):
            q, nxt = j*seg+k, j*seg+(k+1) % seg
            faces.append((q, nxt, nxt+seg, q+seg))
    faces.extend([tuple(reversed(range(seg))), tuple(rows*seg+k for k in range(seg))])
    ob = c.mesh(name, verts, faces, 'piano', smooth=True)
    for p in ob.data.polygons[-2:]:
        p.use_smooth = False
    return ob


def capital(relief, x, y, z0, z1, radius):
    """Corinthian acanthus bell, four outward volutes and pearl-neck bands."""
    h = z1-z0
    profile = [(0, z0), (radius*.58, z0), (radius*.64, z0+h*.055),
               (radius*.60, z0+h*.13), (radius*.68, z0+h*.27),
               (radius*.83, z0+h*.63), (radius*.88, z0+h*.78),
               (radius*.82, z0+h*.90), (radius, z1), (0, z1)]
    c.lathe('Carved gilded Corinthian bell capital', (x, y, 0), profile, 'antique_gold', 48)
    for k in range(8):
        a = TAU*k/8
        def mapping(u, v, r, a=a):
            # Flattened leaves wrap around the bell, with raised central lobe.
            aa = a+u/max(.01, radius*.8)
            t = v/h
            rad = radius*(.59+.29*t)+r
            return (x+rad*math.cos(aa), y+rad*math.sin(aa), z0+v)
        path = bezier((0, h*.08), (-radius*.05, h*.39), (radius*.12, h*.63),
                      (0, h*.82), 9)
        relief.blade(mapping, path, radius*.38, 'gold', radius*.20, 3)
    # Four genuinely curled scrolls at the abacus, two opposing pairs.
    for k in range(4):
        a = TAU*(k+.5)/4
        radial, tangent = Vector((math.cos(a), math.sin(a), 0)), Vector((-math.sin(a), math.cos(a), 0))
        pts = []
        for j in range(29):
            t = j/28
            ang = -math.pi/2+t*TAU*1.12
            rr = radius*(.42*(1-t)+.055)
            p = Vector((x, y, z0+h*.68))+radial*(radius*.88+rr*math.cos(ang))+Vector((0, 0, rr*math.sin(ang)))
            pts.append(p)
        relief.tube(pts, radius*.095, 'gold', 6)
        # A small chased inner scroll gives the capital a layered casting.
        relief.tube([tuple(Vector(p)+tangent*radius*.08) for p in pts], radius*.026, 'bronze', 4)
    for z, r in [(z0+h*.055, radius*.66), (z0+h*.14, radius*.63), (z1-h*.035, radius*.99)]:
        relief.tube([(x+r*math.cos(TAU*k/48), y+r*math.sin(TAU*k/48), z) for k in range(48)], .0012, 'gold', 5, True)
    for j in range(24):
        a = TAU*j/24
        relief.bead((x+radius*.66*math.cos(a), y+radius*.66*math.sin(a), z0+h*.083), .0018, 'gold', 6, 3)


def gilt_sabot(relief, x, y, height, r0, r1):
    """Turned toe and embossed upright acanthus sleeve, like the reference."""
    c.lathe('Turned gold foot and gilt sabot sleeve', (x, y, 0),
            [(0, 0), (r0*.78, 0), (r0, .004), (r0*.91, .012),
             (r0*.93, height*.18), (r0*1.16, height*.24), (r0*1.20, height*.31),
             (r0*1.08, height*.40), (r0*.87, height*.47),
             (r1, height*.94), (r1*.99, height), (0, height)], 'antique_gold', 40)
    for k in range(10):
        a = TAU*k/10
        # Long foliate ribs engraved in the upper gilt sleeve.
        pts = []
        for j in range(8):
            t = j/7
            z = height*(.43+.54*t)
            r = r0*.87+(r1-r0*.87)*t+.0007
            pts.append((x+r*math.cos(a), y+r*math.sin(a), z))
        relief.tube(pts, .00065, 'gold', 4)
        for t in (.30, .57, .79):
            z = height*(.43+.54*t)
            r = r0*.87+(r1-r0*.87)*t+.001
            for sign in (-1, 1):
                pts = [(x+(r+.0004*j/4)*math.cos(a+sign*.16*j/4),
                        y+(r+.0004*j/4)*math.sin(a+sign*.16*j/4),
                        z-height*.055*j/4) for j in range(5)]
                relief.tube(pts, .0005, 'gold', 4)
    for k in range(20):
        a = TAU*k/20
        relief.bead((x+r0*1.16*math.cos(a), y+r0*1.16*math.sin(a), height*.31), .0015, 'gold', 5, 3)


def table(sku):
    dimensions = SPECS[sku][1]
    w, d, h = [v/1000 for v in dimensions]
    console = sku == '50411.0'
    coffee = sku in ('50475.1', '50476.1')
    mat = 'calacatta' if console else 'emperor'
    stone = .022 if coffee else (.026 if console else .019)
    apron_h = .098 if coffee else (.127 if console else .098)
    marble_z = h-stone
    apron_top = marble_z-.017
    apron_bottom = apron_top-apron_h
    frame_w, frame_d = w-.040, d-.040
    block = .085 if coffee else (.090 if console else .067)
    leg_inset = .072 if coffee else (.066 if console else .055)
    relief = Relief()
    # Marble is not a smooth-shaded pseudo-inflated plane: four true eased
    # edge rings and a flat planar-UV stone face make the high gloss readable.
    slab('Polished '+('Calacatta' if console else 'Emperor')+' stone top | flat cap',
         w, d, marble_z, h, mat, .0025, .0013)
    slab('Stepped gilt cornice under marble | broad ogee shoulder',
         w-.012, d-.012, marble_z-.008, marble_z+.0002, 'gold', .0025, .0013)
    slab('Dark shadow reveal under stone', w-.021, d-.021,
         marble_z-.012, marble_z-.007, 'piano', .002, .0005)
    slab('Stepped gilt upper bolection moulding', w-.028, d-.028,
         apron_top-.001, marble_z-.011, 'gold', .0025, .0012)
    # The catalogue's apron is predominantly antiqued gilding, not a broad
    # unadorned black fascia. A darker bronze ground gives the raised leaves
    # their recessed shadow; the distinctly black lacquer belongs on shafts.
    slab('Antiqued bronze recessed fields behind gilt acanthus relief', frame_w, frame_d,
         apron_bottom, apron_top, 'bronze', .002, .001)
    # Underside is a real fixed support, no invented lower display shelf.
    slab('Dark structural table underside', frame_w-.014, frame_d-.014,
         apron_bottom+.001, apron_bottom+.012, 'wood_dark', .002, .001)
    for z0, z1, delta in [(apron_bottom-.004, apron_bottom+.002, -.006),
                           (apron_bottom+.004, apron_bottom+.010, .002)]:
        slab('Continuous gilt lower apron moulding', frame_w+delta, frame_d+delta,
             z0, z1, 'gold', .002, .0009)
    apron_face(relief, 'front', frame_d/2, frame_w, apron_bottom, apron_top, block, console)
    apron_face(relief, 'back', frame_d/2, frame_w, apron_bottom, apron_top, block, console)
    apron_face(relief, 'left', frame_w/2, frame_d, apron_bottom, apron_top, block, console)
    apron_face(relief, 'right', frame_w/2, frame_d, apron_bottom, apron_top, block, console)
    foot_h = .063 if coffee else (.135 if console else .092)
    cap_h = .078 if coffee else (.117 if console else .083)
    cap_r = .041 if coffee else (.044 if console else .034)
    shaft_bottom = foot_h-.002
    shaft_top = apron_bottom-cap_h+.003
    shaft_r0 = .014 if coffee else (.0155 if console else .012)
    shaft_r1 = .023 if coffee else (.025 if console else .019)
    for i, (x, y) in enumerate((x, y) for x in (-w/2+leg_inset, w/2-leg_inset)
                                for y in (-d/2+leg_inset, d/2-leg_inset)):
        # Square, framed corner-block abacus beneath each apron rosette.
        block_size = cap_r*2.04
        c.box('Corner leg abacus %02d' % (i+1), (x, y, apron_bottom-.006),
              (block_size, block_size, .017), 'gold', .0015)
        capital(relief, x, y, apron_bottom-cap_h-.002, apron_bottom-.013, cap_r)
        fluted_shaft('Black piano fluted tapered leg %02d' % (i+1), x, y,
                      shaft_bottom, shaft_top, shaft_r0, shaft_r1)
        gilt_sabot(relief, x, y, foot_h, shaft_r0*.95, shaft_r0*1.05)
    relief.finish('Trianon foliate carving and cast-bronze details')


def create(sku, instance='main'):
    sku = str(sku)
    if sku not in SPECS:
        raise ValueError('Unknown Trianon casegood SKU: '+sku)
    name, dimensions = SPECS[sku]
    root = c.empty(name+' | '+str(instance), props={
        'kind': 'product', 'product_id': sku, 'instance_id': str(instance),
        'dimensions_mm': list(dimensions), 'collection': 'Trianon',
        'source': 'CLASSIC_FURNITURE_CATALOG_2023.pdf | Mariner | PDF pages 23–24',
        'reconstruction_note': 'Independent visual reconstruction; hidden joinery and calibrated finishes are not manufacturer-certified.',
        'moving_parts': 0,
        'marble_variant': 'Calacatta (.0)' if sku == '50411.0' else 'Emperor (.1)',
    })
    if sku == '50476.1':
        root['reconstruction_note'] += ' Rectangular footprint adapts the shared square-table close-up to the printed 170 x 95 cm dimensions.'
    with parent_to(root):
        table(sku)
    return root
