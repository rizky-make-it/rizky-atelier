# TRIANON / Rizky Atelier

Independent, editable visual reconstruction by Muhammad Rizky of seven living-room references in the supplied MARINER CLASSIC FURNITURE CATALOG 2023, PDF pages 21–24 (printed 40–47).

## Inventory

50472.0 three-seat sofa, 50473.0 two-seat sofa, 50474.0 armchair; 50476.1 rectangular Emperor marble coffee table; 50475.1 square Emperor marble coffee table; 50411.0 Calacatta console; 50412.1 square Emperor marble side table. Dimensions are millimetres, width × depth × height, preserved in reference/products.json and product root metadata.

## Native and web deliverables

The wall-free master has ten placed furniture instances, seven cameras, packed authored texture maps and a Cycles-ready 3840 × 2160 configuration. Five delivered 4K PNGs and two 1600 × 1600 details are genuine Blender EEVEE renders, not AI images or upscaled thumbnails. The exhibition GLB uses an optimisation pass; individual GLBs retain full evaluated geometric detail. No opening mechanisms are inferred from static catalogue references.

Open trianon-exhibition.blend in Blender 5.2+. Rebuild with `blender --background --python build_scene.py`. Export with `blender --background trianon-exhibition.blend --python export_web.py`. Render with `blender --background trianon-exhibition.blend --python render_scene.py -- all` (add --preview for camera checks, or --cycles for a different rendering engine). Audit with `blender --background trianon-exhibition.blend --python validate_native.py`. The final packaging helper uses PyMuPDF and the original PDF path recorded in the evidence; geometry rebuilding does not require the PDF.

## Fidelity and provenance

Reference imagery is extracted from the user-supplied catalogue without AI enhancement. Original PDF soft masks, where present, may be composited onto the original white page colour at native density; evidence records this. The rectangular coffee table shares a detail image with the square version; its size follows the printed SKU but hidden/proportional details are an adaptation. The lifestyle spread also contains unlisted vitrines and a round coffee table, which are not relabelled as these selected SKUs. The repeated square-table listing counts once.

Modelled open wreath crests, foliate relief, scroll arms, cloth fullness, piping, fluted legs and gilt collars are true editable geometry. Walnut-burl veneer, black piano lacquer, antique gold, sage velvet, Emperor and Calacatta are authored PBR visual interpretations, not measured manufacturer material scans. Exact carving topology, underside/rear joinery, weave calibration, finish colour and marble vein placement remain unverified. This is not manufacturer engineering CAD, certified construction documentation or a claim of endorsement. Catalogue design and image rights remain with their owners; no commercial image licence is implied.

The public website stays English, preserves all previous collections, and routes visible file requests to Muhammad Rizky's WhatsApp contact dialog. Static files remain publicly accessible; the dialog is not access control.
