"""Trianon geometry bridge and authored PBR materials. All dimensions in metres.

The copied geometry.py is the project's existing geometric utility. Materials
below are procedural visual interpretations, not measured manufacturer samples.
"""
import math
from pathlib import Path
import numpy as np
import bpy
import geometry as g

BASE=Path(__file__).resolve().parent
g.BASE=BASE
M=g.M
for _name in ('set_parent','link','empty','mesh','box','sphere','lathe','cylinder','rod','curve','material','image_map','generated','light'):
    globals()[_name]=getattr(g,_name)
def __getattr__(name):
    if name=='PARENT':return g.PARENT
    raise AttributeError(name)

def field(x,y,seed=0):
    rng=np.random.default_rng(seed);value=np.zeros_like(x)
    for i in range(7):
        a,b,phase=rng.uniform(.6,2.8),rng.uniform(.6,2.8),rng.uniform(0,math.tau)
        value+=np.sin((x*a+y*b)*2**i+phase)*np.cos((x*b-y*a)*2**i-phase)/2**(i*.85)
    return value

def texture(name,rgb,noncolor=False):
    alpha=np.ones((*rgb.shape[:2],1),dtype=np.float32)
    return generated(name,np.concatenate((rgb,alpha),axis=2),noncolor)

def materials():
    (BASE/'textures').mkdir(exist_ok=True)
    n=1536;y,x=np.mgrid[0:n,0:n].astype(np.float32)/n
    # Layered, domain-warped burl eyes and bookmatched figuring; never a photo
    # of another product or a claim of calibrated NO/OA material reproduction.
    u=np.abs(x-.5)*6;v=y*6
    warp=field(u*.9,v*.9,32)
    wx=u+.30*field(u,v,7);wy=v+.28*field(v,u,81)
    grain=np.sin(wx*24+wy*4+warp*5)
    eyes=np.zeros_like(x)
    for cx,cy in [(.35,1.0),(1.3,3.8),(2.2,1.7),(.5,5.3),(2.5,5.2)]:
        radius=np.sqrt((wx-cx)**2+(wy-cy)**2*.7)
        eyes+=np.sin(radius*33+warp*1.6)*np.exp(-radius*radius*.55)
    value=np.clip(.46+.11*warp+.10*grain+.13*eyes+.035*field(u*9,v*9,4),0,1)
    dark=np.array([.036,.012,.005]);light=np.array([.42,.17,.060])
    burl=dark+(light-dark)*value[...,None]**1.25
    wood_path=texture('trianon_walnut_burl',burl)
    # Fine diagonal Calacatta veining with restrained warm secondary veins.
    warp=field(x*4,y*4,12);phase=x*17+y*10+warp*.8
    vein=np.exp(-(np.sin(phase)*15)**2)
    secondary=np.exp(-(np.sin(phase*1.7+field(x*8,y*8,42)) *30)**2)
    marble=np.stack([.82-vein*.29-secondary*.06,.80-vein*.29-secondary*.07,.75-vein*.26-secondary*.08],axis=2)
    marble+=field(x*16,y*16,29)[...,None]*.012
    marble_path=texture('trianon_calacatta',np.clip(marble,.1,1))
    # Emperor dark marble: branching cream mineral seams across warm brown.
    phase=x*13-y*19+field(x*5,y*5,91)*1.4
    vein=np.exp(-(np.sin(phase)*28)**2)
    fine=np.exp(-(np.sin(x*29+y*41+field(x*9,y*9,27))*38)**2)
    cloud=field(x*12,y*12,21)*.012
    emperor=np.stack([.075+cloud+vein*.28+fine*.09,.038+cloud*.7+vein*.21+fine*.07,.023+cloud*.6+vein*.13+fine*.04],axis=2)
    emperor_path=texture('trianon_emperor',np.clip(emperor,.005,1))
    weave=(np.sin(x*math.tau*210)*np.cos(y*math.tau*209))
    fabric=np.stack([.19+weave*.010,.26+weave*.012,.22+weave*.010],axis=2)
    fabric+=field(x*80,y*80,6)[...,None]*.005
    cloth_path=texture('trianon_sage_velvet',fabric)
    dx=np.cos(x*math.tau*210)*np.sin(y*math.tau*209)*.13
    dy=np.sin(x*math.tau*210)*np.cos(y*math.tau*209)*.13
    normal_path=texture('trianon_thread_normal',np.stack([.5-dx,.5-dy,np.ones_like(x)],axis=2),True)
    palette={
      'wood':((.13,.045,.014),.18,0),'wood_dark':((.019,.012,.009),.19,0),
      'inside':((.10,.038,.015),.32,0),'marble':((.82,.80,.75),.17,0),
      'bronze':((.48,.29,.09),.29,.85),'gold':((.64,.43,.15),.21,.86),
      'cloth':((.19,.26,.22),.68,0),'cloth_light':((.34,.42,.35),.72,0),
      'cloth_gold':((.53,.39,.20),.72,0),'cloth_dark':((.10,.17,.13),.68,0),
      'emperor':((.075,.038,.023),.16,0),'calacatta':((.82,.80,.75),.17,0),
      'piano':((.006,.005,.004),.12,0),'antique_gold':((.54,.34,.09),.30,.8),
      'stitch':((.25,.21,.16),.88,0),'black':((.009,.010,.010),.23,.08),
      'stone':((.72,.69,.61),.48,0),'plinth':((.73,.69,.58),.65,0),
      'rug':((.43,.37,.27),.97,0),'paper':((.80,.76,.64),.82,0),
      'ceramic':((.12,.16,.14),.28,.12),'leaf':((.07,.12,.045),.68,0),
      'glass':((.91,.94,.91),.08,0),'light':((1,.80,.43),.3,0),
    }
    for key,(color,r,m) in palette.items():M[key]=material('TRIANON | '+key,color,r,m)
    for key in ('wood','inside'):
        image_map(M[key],wood_path,'Base Color')
        M[key]['source']='Authored procedural walnut burl; catalogue-colour interpretation'
    image_map(M['marble'],marble_path,'Base Color')
    image_map(M['calacatta'],marble_path,'Base Color')
    image_map(M['emperor'],emperor_path,'Base Color')
    M['marble']['source']='Authored procedural Calacatta interpretation'
    for key in ('cloth','cloth_light','cloth_gold','cloth_dark','rug'):
        if key=='cloth':image_map(M[key],cloth_path,'Base Color')
        image_map(M[key],normal_path,'Normal',True,.45)
        M[key].node_tree.nodes['Principled BSDF'].inputs['Sheen Weight'].default_value=.32
    for key in ('wood','wood_dark','marble','calacatta','emperor','piano','black'):
        bs=M[key].node_tree.nodes['Principled BSDF'];bs.inputs['Coat Weight'].default_value=.5
        bs.inputs['Coat Roughness'].default_value=.12
    for key in ('bronze','gold','antique_gold'):
        nodes=M[key].node_tree.nodes;links=M[key].node_tree.links
        noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=240
        bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.16;bump.inputs['Distance'].default_value=.00015
        links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],nodes['Principled BSDF'].inputs['Normal'])
    bs=M['glass'].node_tree.nodes['Principled BSDF'];bs.inputs['Transmission Weight'].default_value=1;bs.inputs['IOR'].default_value=1.46
    bs=M['light'].node_tree.nodes['Principled BSDF'];bs.inputs['Emission Color'].default_value=(1,.78,.4,1);bs.inputs['Emission Strength'].default_value=3
    return M
