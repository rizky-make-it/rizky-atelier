"""Preserve native TRIANON evidence from the user-supplied MARINER PDF."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / '.local/catalogue-review/packages'))
import pymupdf as fitz

SOURCE = Path('C:/Users/Admin/Downloads/CLASSIC_FURNITURE_CATALOG_2023.pdf')
DEST = ROOT / 'output/trianon/reference'
DEST.mkdir(parents=True, exist_ok=True)
ORIGINALS = DEST / 'originals'
ORIGINALS.mkdir(exist_ok=True)
doc = fitz.open(SOURCE)
pages = []
for index in range(20, 24):
    page = doc[index]
    scale = 2200 / page.rect.width
    image_path = DEST / f'page-{index + 1:03}.jpg'
    page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False).save(image_path, jpg_quality=96)
    for image in page.get_image_info(xrefs=True):
        xref = image.get('xref')
        if xref:
            original = doc.extract_image(xref)
            (ORIGINALS / f'page-{index + 1:03}-xref-{xref}.{original["ext"]}').write_bytes(original['image'])
    pages.append({'pdf_page': index + 1, 'rect_pdf_points': list(page.rect),
                  'text': page.get_text(sort=True), 'text_blocks': page.get_text('blocks'),
                  'images': page.get_image_info(xrefs=True), 'preview': image_path.name})
    print(f'PAGE {index+1}\n{page.get_text(sort=True)}', flush=True)
report = {'source': str(SOURCE), 'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'page_count': len(doc), 'metadata': doc.metadata,
          'image_classification': 'Original catalogue image; not independently verified product photography',
          'pages': pages}
(DEST / 'catalogue-evidence.json').write_text(json.dumps(report, indent=2,
    default=lambda value: value.hex() if isinstance(value, bytes) else str(value)), encoding='utf8')
print('PREVIEWS_READY', DEST, flush=True)

PRODUCTS = DEST / 'catalogue'
DETAILS = DEST / 'details'
PRODUCTS.mkdir(exist_ok=True)
DETAILS.mkdir(exist_ok=True)

def source_rect(pdf_page, xref, rect_pixels):
    info = next(image for image in doc[pdf_page-1].get_image_info(xrefs=True) if image['xref'] == xref)
    bbox = fitz.Rect(info['bbox'])
    x0, y0, x1, y1 = rect_pixels
    return [bbox.x0 + x0/info['width']*bbox.width, bbox.y0 + y0/info['height']*bbox.height,
            bbox.x0 + x1/info['width']*bbox.width, bbox.y0 + y1/info['height']*bbox.height]

def extract_original(pdf_page, xref, destination):
    original = doc.extract_image(xref)
    source_path = ORIGINALS / f'page-{pdf_page:03}-xref-{xref}.{original["ext"]}'
    source_path.write_bytes(original['image'])
    smask = next((image[1] for image in doc[pdf_page-1].get_images(full=True) if image[0] == xref), 0)
    evidence = {'source_pdf_page': pdf_page, 'source_image_xref': xref,
                'source_native_pixels': [original['width'], original['height']],
                'crop_rect_native_pixels': [0,0,original['width'],original['height']],
                'crop_rect_pdf_points': source_rect(pdf_page,xref,[0,0,original['width'],original['height']]),
                'output_pixels': [original['width'], original['height']],
                'source_image_file': source_path.relative_to(DEST).as_posix(),
                'source_image_sha256': hashlib.sha256(original['image']).hexdigest(),
                'file': destination.relative_to(DEST).as_posix()}
    if smask:
        mask = doc.extract_image(smask)
        mask_path = ORIGINALS / f'page-{pdf_page:03}-mask-{smask}.{mask["ext"]}'
        mask_path.write_bytes(mask['image'])
        # Reproduce the PDF's own image+soft-mask composition, including its
        # original white page background. This is not new subject segmentation.
        composite = fitz.open()
        page = composite.new_page(width=original['width'], height=original['height'])
        page.insert_image(page.rect, stream=original['image'], mask=mask['image'])
        page.get_pixmap(alpha=False).save(destination, jpg_quality=96)
        composite.close()
        evidence.update({'source_soft_mask_xref':smask,
                         'source_soft_mask_file':mask_path.relative_to(DEST).as_posix(),
                         'source_soft_mask_sha256':hashlib.sha256(mask['image']).hexdigest(),
                         'transformation':'Original embedded JPEG and its original PDF soft mask composited on the original white page background at native pixel density; no new background removal, upscaling or subject alteration'})
    else:
        destination.write_bytes(original['image'])
        evidence['transformation'] = 'Exact original embedded JPEG bytes, no resizing or visual modification'
    evidence['sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
    return evidence

def crop_original(pdf_page, xref, rect_pixels, destination):
    original = doc.extract_image(xref)
    image_doc = fitz.open(stream=original['image'], filetype=original['ext'])
    page = image_doc[0]
    scale = original['width']/page.rect.width
    pixmap = page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=fitz.Rect(rect_pixels)/scale,alpha=False)
    pixmap.save(destination,jpg_quality=96)
    evidence = {'source_pdf_page':pdf_page,'source_image_xref':xref,
                'source_native_pixels':[original['width'],original['height']],
                'crop_rect_native_pixels':rect_pixels,'crop_rect_pdf_points':source_rect(pdf_page,xref,rect_pixels),
                'output_pixels':[pixmap.width,pixmap.height],
                'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
                'transformation':'Rectangular crop of original embedded catalogue image at native pixel density; no upscaling or subject alteration',
                'file':destination.relative_to(DEST).as_posix()}
    image_doc.close()
    return evidence

definitions = [
    {'sku':'50472.0','name':'Trianon Three-seat Sofa','type':'Sofa',
     'dimensions_mm':[2650,880,1110],'weight_kg':74,'source_pdf_page':22,'xref':105,
     'fabric_codes':['243.064','243.065'],'finish':'POE/NB / OA (425 /231)',
     'visible_details':['Three individual sage-grey green seat cushions with piped seams',
                        'Smooth gently curved upholstered back with raised central antique-gold crest and open circular wreath',
                        'Rolled upholstered arms with prominently carved gold spiral end-scrolls',
                        'Antique-gold foliate lower rails and square floral corner blocks',
                        'Six visible or inferable tapered fluted black legs with decorated gold capitals and toes',
                        'Two matching sage accent pillows and two muted champagne-gold accent pillows'],
     'reference_note':'Source pillows include a manufacturer monogram; reconstructed geometry need not reproduce that branding. Rear and underside construction are not fully evidenced.'},
    {'sku':'50473.0','name':'Trianon Two-seat Sofa','type':'Sofa',
     'dimensions_mm':[2000,880,1110],'weight_kg':65,'source_pdf_page':22,'xref':107,
     'fabric_codes':['243.064','243.065'],'finish':'POE/NB / OA (425 /231)',
     'visible_details':['Two individual sage-grey green seat cushions with piped seams',
                        'Smooth curved back and ornate raised antique-gold crest with an open circular wreath',
                        'Carved gold spiral arm scrolls and narrow gold back-edge molding',
                        'Decorated gold lower front rail with central square floral block',
                        'Black tapered fluted legs with gold collars and toes',
                        'Two sage and two champagne-gold loose accent pillows'],
     'reference_note':'The original embedded image uses the PDF soft mask; the website derivative faithfully composites that original mask over the original white page background. Hidden centre support details are unverified.'},
    {'sku':'50474.0','name':'Trianon Armchair','type':'Armchair',
     'dimensions_mm':[1230,880,1110],'weight_kg':38,'source_pdf_page':22,'xref':109,
     'fabric_codes':['243.064','243.065'],'finish':'POE/NB / OA (425 /231)',
     'visible_details':['One broad sage-grey green seat cushion',
                        'Raised antique-gold floral crest and open circular wreath above smooth curved upholstered back',
                        'Large rolled arms with carved spiral gold face trims',
                        'Four tapered black legs with gold capitals and toes',
                        'Single muted champagne-gold loose accent pillow',
                        'Carved gold lower front and side rails with circular and floral corner medallions']},
    {'sku':'50476.1','name':'Trianon Rectangular Coffee Table','type':'Coffee table',
     'dimensions_mm':[1700,950,470],'weight_kg':120,'source_pdf_page':23,'xref':113,
     'finish':'POE/NB (425)','marble':'Emperor marble',
     'visible_details':['Straight-edged rectangular dark Emperor marble slab with tan and cream veining',
                        'Elaborate antique-gold foliate carved apron with central circular floral medallion',
                        'Square corner blocks carrying flower rosettes',
                        'Layered egg-and-dart and bead molding below marble edge',
                        'Four low tapered fluted black legs with gold foliate capitals and gold toes',
                        'Open lower span without shelf'],
     'reference_note':'The original catalogue detail/lifestyle image accompanies both 50475.1 and 50476.1 labels. It is not an isolated SKU-labelled product view; rectangular-form attribution is inferred from visible proportions and the printed dimensions. Marble variants .0 are mentioned but not counted as additional evidenced products.'},
    {'sku':'50475.1','name':'Trianon Square Coffee Table','type':'Coffee table',
     'dimensions_mm':[1400,1400,470],'weight_kg':131,'source_pdf_page':24,'xref':120,
     'finish':'POE/NB (425)','marble':'Emperor marble',
     'visible_details':['Square straight-edged dark Emperor marble top with cream and tan veining',
                        'Carved antique-gold foliate apron with central circular rosette',
                        'Flower corner blocks and slim layered molding at the upper edge',
                        'Four tapered fluted black legs with ornate gold capitals and gold toes',
                        'Open lower span without a shelf'],
     'reference_note':'This SKU appears on PDF pages23 and24 and is counted once. The image here is the isolated product view on page24. The original PDF soft mask is retained and composited onto the original white page background at native density. Calacatta marble .0 availability is a source note, not a separately modelled SKU.'},
    {'sku':'50411.0','name':'Trianon Console','type':'Console',
     'dimensions_mm':[1310,490,880],'weight_kg':73,'source_pdf_page':24,'xref':116,
     'finish':'POE/NB (425)','marble':'Calacatta marble',
     'visible_details':['Straight rectangular white Calacatta marble slab with subtle grey veining and a stepped beveled edge',
                        'Deep antique-gold apron with scrolling foliage and a central medallion',
                        'Square flower-rosette corner blocks',
                        'Egg-and-dart molding immediately below the slab',
                        'Four long tapered fluted black legs',
                        'Large gold acanthus capitals and tall decorated gold foot sleeves',
                        'Open lower span without shelf'],
     'reference_note':'The source is a close perspective product image. No drawer, hinge or movable mechanism is evidenced; the apron remains fixed in reconstruction.'},
    {'sku':'50412.1','name':'Trianon Square Side Table','type':'Side table',
     'dimensions_mm':[710,710,630],'weight_kg':35,'source_pdf_page':24,'xref':118,
     'finish':'POE/NB (425)','marble':'Emperor marble',
     'visible_details':['Square straight-edged dark Emperor marble slab',
                        'Carved gold foliate apron with central round floral medallion',
                        'Square floral corner blocks',
                        'Four long tapered fluted black legs with ornate gold capitals',
                        'Decorated gold foot sleeves and open lower span without shelf'],
     'reference_note':'The original PDF soft mask is faithfully composited onto the original white page background at native pixel density. No opening mechanism is documented.'},
]
for product in definitions:
    image_evidence = extract_original(product['source_pdf_page'],product['xref'],PRODUCTS/f'{product["sku"]}.jpg')
    materials = ['Carvings decorated with antique gold leaf','Cast bronze ornaments','High-gloss black piano lacquer']
    if product.get('marble'):
        materials.append(product['marble'])
    else:
        materials.append('Sage-grey green upholstery; fabric 243.064 / 243.065')
    product.update({'collection':'TRIANON','catalogue_brand':'MARINER',
                    'sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023','sourceBrand':'MARINER',
                    'sourcePage':product['source_pdf_page'],'imageShared':False,
                    'materials':materials,'dimensions_order':'width, depth, height',
                    'source_printed_pages':{22:'42-43',23:'44-45',24:'46-47'}[product['source_pdf_page']],
                    'image_classification':'Original catalogue image, not independently verified product photography',
                    'image':image_evidence})
    product.pop('xref',None)

supporting_images = [
    extract_original(21,102,DEST/'room-living.jpg'),
    extract_original(23,113,DEST/'original-table-detail.jpg'),
    extract_original(22,108,DEST/'original-sofa-back.jpg'),
    crop_original(23,113,[260,560,1190,970],DETAILS/'original-carved-apron.jpg'),
    crop_original(22,105,[225,110,425,205],DETAILS/'original-crest.jpg'),
    crop_original(24,116,[80,220,805,510],DETAILS/'original-console-gilding.jpg'),
]
manifest = {'collection':'TRIANON','catalogue_brand':'MARINER','catalogue_title':SOURCE.name,
            'sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023','sourceBrand':'MARINER',
            'source_pdf':str(SOURCE),'source_pdf_sha256':report['source_sha256'],
            'source_pdf_page_count':len(doc),'source_pdf_pages':[21,22,23,24],
            'dimensions_unit':'millimetres','dimensions_order':'width, depth, height',
            'source_material_statement':'CASTED BRONZE ORNAMENTS, CARVINGS DECORATED WITH ANTIQUE GOLD LEAF, HIGH GLOSS WALNUT BURL VENEER, HIGH GLOSS BLACK PIANO LACQUER & MARBLE.',
            'source_variant_note':'Coffee tables 50475.1 and 50476.1 are printed as Emperor marble; the catalogue notes Calacatta marble (.0) availability. Only the seven explicitly selected printed references are counted.',
            'scope_note':'Only the TRIANON living-room section on PDF pages21-24 is in scope. The page21 contextual room image includes a round coffee table and tall vitrines not individually specified among these seven selected references. Those contextual items must not be labelled as the seven modelled SKUs. Later Trianon dining/bedroom sections are not part of this extraction.',
            'provenance_note':'Images are exact original embedded JPEG bytes, explicitly documented native-density crops, or faithful native-density composites of original JPEGs with their original PDF soft masks over the source white page background. Raw image and original mask bytes and hashes are retained. No AI replacement, super-resolution, new subject segmentation or subject alteration was performed.',
            'reconstruction_caveat':'Only catalogue dimensions and visibly documented surfaces are evidenced. Hidden joinery, exact fabric weave and finish calibration, marble veining placement, rear/underside structures and opening mechanisms are unverified interpretations. These images alone do not establish whether source imagery is photographed or rendered. The p23 rectangular coffee-table attribution is inferred from the shared catalogue composition and dimensions, not from a separate isolated labelled view.',
            'rights_note':'User-supplied MARINER catalogue; original product designs and imagery remain the rights of their owners. This evidence extraction conveys no commercial reuse licence or manufacturer endorsement.',
            'products':definitions,'supporting_images':supporting_images}
(DEST/'products.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
print('PRODUCT_REFERENCES_READY',len(definitions),DEST/'products.json',flush=True)
doc.close()
