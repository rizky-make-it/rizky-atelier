"""TRIANON seating reconstructed from supplied MARINER catalogue pp. 42-43.

All carvings, scrolls, cushion folds, fluting and open crest are editable
geometry. Hidden engineering and unprinted fabric details are interpretations.
Metres, floor-centred, X width, Y depth, opening toward -Y, Z up.
"""
import math
from contextlib import contextmanager

import bpy
from mathutils import Vector
import core as c

SPECS = {
    '50472.0': (2.650, .880, 1.110, 3, 'Trianon three-seat sofa'),
    '50473.0': (2.000, .880, 1.110, 2, 'Trianon two-seat sofa'),
    '50474.0': (1.230, .880, 1.110, 1, 'Trianon armchair'),
}
TAU = math.tau


@contextmanager
def parent(ob):
    previous = c.PARENT
    c.set_parent(ob)
    try:
        yield ob
    finally:
        c.set_parent(previous)


class Relief:
    """Batch small solid relief carvings by material, not thousands of objects."""
    def __init__(self, name, mat):
        self.name, self.mat = name, mat
        self.verts, self.faces = [], []

    def tube(self, points, radius, sides=7, radii=None, cyclic=False):
        pts = [Vector(p) for p in points]
        if cyclic: pts.append(pts[0])
        if len(pts) < 2:return
        base = len(self.verts)
        for i,p in enumerate(pts):
            tangent = (pts[min(i+1,len(pts)-1)]-pts[max(0,i-1)]).normalized()
            ref = Vector((0,1,0)) if abs(tangent.y)<.95 else Vector((0,0,1))
            normal = tangent.cross(ref).normalized()
            across = tangent.cross(normal).normalized()
            rr = radius*(radii[min(i,len(radii)-1)] if radii else 1)
            for j in range(sides):
                a = TAU*j/sides
                self.verts.append(tuple(p+rr*(normal*math.cos(a)+across*math.sin(a))))
        for i in range(len(pts)-1):
            for j in range(sides):
                q=base+i*sides+j;r=base+i*sides+(j+1)%sides
                self.faces.append((q,r,r+sides,q+sides))
        self.faces.append(tuple(base+j for j in range(sides-1,-1,-1)))
        self.faces.append(tuple(base+(len(pts)-1)*sides+j for j in range(sides)))

    def bead(self, centre, radius, squash=(1,1,1), sides=8, rings=5):
        base = len(self.verts)
        for j in range(rings+1):
            t=math.pi*j/rings
            for i in range(sides):
                a=TAU*i/sides
                self.verts.append((centre[0]+radius*squash[0]*math.sin(t)*math.cos(a),
                                   centre[1]+radius*squash[1]*math.sin(t)*math.sin(a),
                                   centre[2]+radius*squash[2]*math.cos(t)))
        for j in range(rings):
            for i in range(sides):
                q=base+j*sides+i;r=base+j*sides+(i+1)%sides
                self.faces.append((q,r,r+sides,q+sides))

    def leaf(self, start, end, width, bulge=.006, lobes=3):
        """Ribbed, serrated acanthus petal in an XZ relief plane."""
        a,b=Vector(start),Vector(end);d=b-a
        across=Vector((d.z,0,-d.x)).normalized()
        base=len(self.verts);rows=9
        for j in range(rows+1):
            t=j/rows
            w=width*(math.sin(math.pi*t)**.75)*(.79+.21*math.cos(t*TAU*lobes))
            for k in range(5):
                u=(k-2)/2
                p=a+d*t+across*(u*w)
                p.y-=bulge*math.sin(math.pi*t)*(1-abs(u)*.78)
                self.verts.append(tuple(p))
        for j in range(rows):
            for k in range(4):
                q=base+j*5+k;self.faces.append((q,q+1,q+6,q+5))
        self.tube([tuple(a+d*t+Vector((0,-bulge*math.sin(math.pi*t)-.001,0)))
                   for t in [i/10 for i in range(11)]],.0012,5)

    def finish(self):
        if self.faces:return c.mesh(self.name,self.verts,self.faces,self.mat,smooth=True)


def smooth(t):
    t=max(0,min(1,t));return t*t*(3-2*t)


def cushion(name, centre, dims, mat='cloth', rotation=(0,0,0), seat=False, phase=0):
    """Six-patch superellipsoid with filled corners and seam-tension wrinkles."""
    holder=c.empty(name,centre);holder.rotation_euler=rotation
    half=[v/2 for v in dims];power=10 if seat else 4.3;n=16
    def shape(q):
        norm=sum(abs(v)**power for v in q)**(1/power)
        p=[half[k]*q[k]/norm for k in range(3)]
        if seat:
            if abs(q[2])>.99:
                edge=math.exp(-((abs(q[1])-.86)/.14)**2)
                p[2]+=math.copysign(.0022*math.sin(q[0]*34+phase)*edge,q[2])
                if q[2]>0:p[2]-=.003*(1-q[0]**2)*(1-q[1]**2)
            if abs(q[1])>.99:
                p[1]+=math.copysign(.002*math.sin(q[0]*29+phase)*(1-q[2]**2),q[1])
        elif abs(q[1])>.99:
            edge=math.exp(-((abs(q[0])-.83)/.16)**2)+math.exp(-((abs(q[2])-.83)/.16)**2)
            fold=.0063*math.sin(q[0]*29+q[2]*8+phase)*edge
            p[1]+=math.copysign(.007*(1-q[0]**2)*(1-q[2]**2)+fold,q[1])
            p[2]+=.003*math.sin(q[0]*9+phase)*(1-q[0]**2)
        return tuple(p)
    with parent(holder):
        verts,faces,uvs=[],[],[]
        for axis,sgn in [(0,-1),(0,1),(1,-1),(1,1),(2,-1),(2,1)]:
            other=[i for i in range(3) if i!=axis];base=len(verts)
            for j in range(n+1):
                for i in range(n+1):
                    q=[0,0,0];q[axis]=sgn;q[other[0]]=-1+2*i/n;q[other[1]]=-1+2*j/n
                    verts.append(shape(q));uvs.append((q[other[0]]*half[other[0]],q[other[1]]*half[other[1]]))
            forward=sgn*(1 if axis!=1 else -1)>0
            for j in range(n):
                for i in range(n):
                    q=base+j*(n+1)+i;f=(q,q+1,q+n+2,q+n+1)
                    faces.append(f if forward else tuple(reversed(f)))
        c.mesh(name+' | stuffed fabric with sewn folds',verts,faces,mat,uvs,True)
        coords=[]
        for side in range(4):
            for j in range(18):
                t=-1+2*j/18;x,z=[(1,t),(-t,1),(-1,-t),(t,-1)][side]
                coords.append(shape((x,z,0) if seat else (x,0,z)))
        c.curve(name+' | perimeter welt',coords,.0018,'cloth_light' if mat!='cloth_gold' else 'stitch',True)
    return holder


def crown_height(x, span):
    a=abs(x)
    # Long low shoulders, rising into the two peaks beside the inset crest.
    return .883+.012*(1-a/span)+.075*math.exp(-((a-.155)/.115)**2)+.029*math.exp(-(a/.11)**2)


def upholstered_back(width, gold, antique):
    span=width/2-.235
    nx=max(48,int(width/.022));nz=24
    verts,faces,uvs=[],[],[]
    # Two padded faces and a closed top/bottom: not a paper-thin image plane.
    for side in (0,1):
        for j in range(nz+1):
            t=j/nz
            for i in range(nx+1):
                x=-span+2*span*i/nx
                top=crown_height(x,span)-.013
                z=.40+t*(top-.40)
                fullness=.029*math.sin(math.pi*t)**.6*max(.0,1-(x/span)**6)
                y=.321+.035*t if side else .273+.028*t-fullness
                if not side:y+=.0016*math.sin(x*71+math.sin(x*19))*math.exp(-((t-.91)/.13)**2)
                verts.append((x,y,z));uvs.append((x,z))
    step=(nx+1)*(nz+1)
    for side in (0,1):
        for j in range(nz):
            for i in range(nx):
                q=side*step+j*(nx+1)+i;f=(q,q+1,q+nx+2,q+nx+1)
                faces.append(f if side==0 else tuple(reversed(f)))
    for i in range(nx):
        q=nz*(nx+1)+i;faces.append((q,q+step,q+step+1,q+1))
        faces.append((i,i+1,i+step+1,i+step))
    for j in range(nz):
        for i in (0,nx):
            q=j*(nx+1)+i;faces.append((q,q+nx+1,q+step+nx+1,q+step))
    c.mesh('Continuous smooth shaped sage velvet back',verts,faces,'cloth',uvs,True)
    top=[(-span+2*span*i/160,.332,crown_height(-span+2*span*i/160,span)) for i in range(161)]
    gold.tube(top,.016,10)
    antique.tube([(x,.314,z-.013) for x,_,z in top],.0045,7)
    # Exact rail-following beading; actual small rounded leaf-gold bosses.
    count=max(35,int(2*span/.012))
    for i in range(count+1):
        x=-span+2*span*i/count;gold.bead((x,.308,crown_height(x,span)-.002),.0036,(1,.8,1),6,4)
    # The open upper wreath is intentionally a real hole, not a dark decal.
    cy=.327;cz=1.047;rx=.050;rz=.052
    ring=[(rx*math.cos(TAU*i/72),cy,cz+rz*math.sin(TAU*i/72)) for i in range(73)]
    gold.tube(ring,.010,9)
    for i in range(22):
        a=TAU*i/22
        p=(rx*math.cos(a),cy-.007,cz+rz*math.sin(a))
        q=((rx+.024)*math.cos(a+.12),cy-.009,cz+(rz+.020)*math.sin(a+.12))
        antique.leaf(p,q,.007,.003,2)
    # Symmetrical scroll-and-acanthus crest links the wreath to shaped rail.
    for sign in (-1,1):
        pts=[]
        for i in range(53):
            t=i/52;a=math.pi*1.8+t*TAU*1.15;r=.066*(1-t)+.006
            pts.append((sign*(.064+r*math.cos(a)),.298, .967+r*.68*math.sin(a)))
        gold.tube(pts,.007,8)
        # Splayed outer leaf fans plus incised central stalks.
        for i in range(6):
            a=.18+i*.23
            start=(sign*.051,.294,.958)
            end=(sign*(.072+.092*math.cos(a)),.289,.956+.074*math.sin(a))
            antique.leaf(start,end,.014,.008,3)
        gold.leaf((sign*.018,.282,.944),(sign*.048,.280,1.030),.020,.009,3)
        # Shoulder scrolls in the small recessed crown peaks.
        for i in range(3):
            xx=.18+i*.033
            antique.leaf((sign*(xx-.027),.307,crown_height(xx,span)-.002),
                         (sign*(xx+.020),.299,crown_height(xx,span)+.018),.009,.005,3)
    gold.bead((0,.275,.958),.021,(1,.44,1),12,8)
    for i in range(8):
        a=TAU*i/8
        antique.leaf((.006*math.cos(a),.266,.958+.006*math.sin(a)),
                     (.031*math.cos(a),.265,.958+.031*math.sin(a)),.006,.004,2)
    # Narrow lower back rail and vertical terminal stiles remain visible rear.
    c.box('Rear gilt frame under upholstery',(0,.348,.340),(2*span+.04,.032,.040),'gold',.004)
    for sign in (-1,1):
        c.box('Back upright gilt stile',(sign*span,.345,.617),(.026,.028,.558),'gold',.005)


def arm(width, sign, gold, antique):
    x=sign*(width/2-.118)
    # Continuous elliptic upholstered roll from front scroll into back shoulder.
    ny=35;ns=36;verts=[];faces=[];uv=[]
    for j in range(ny+1):
        t=j/ny;y=-.315+.638*t
        zz=.736+.026*t
        radius=.109*(.96+.04*math.sin(math.pi*t))
        for i in range(ns+1):
            a=TAU*i/ns
            tuck=.0018*math.sin(a*11+t*9)*math.exp(-((t-.90)/.12)**2)
            verts.append((x+sign*(radius+tuck)*math.cos(a),y,zz+.089*math.sin(a)))
            uv.append((t*.638,a*.11))
    for j in range(ny):
        for i in range(ns):
            q=j*(ns+1)+i;faces.append((q,q+1,q+ns+2,q+ns+1))
    faces += [tuple(range(ns,-1,-1)),tuple(ny*(ns+1)+i for i in range(ns+1))]
    if sign>0:faces=[tuple(reversed(f)) for f in faces]
    roll=c.mesh('Rolled upholstered '+('left' if sign<0 else 'right')+' arm',verts,faces,'cloth',uv,True)
    for poly in list(roll.data.polygons)[-2:]:poly.use_smooth=False
    # Filled side panel is gently concave under the overhanging padded arm.
    verts=[];faces=[];ny=24;nz=18
    for side in (0,1):
        for j in range(nz+1):
            t=j/nz;z=.342+t*.397
            for i in range(ny+1):
                # Rear panel ends 8mm before the roll's solid end cap: avoids
                # coplanar overlap and visible black z-fighting on rear views.
                u=i/ny;y=-.305+u*.620
                xx=x+sign*(.069 if side else -.061)
                xx-=sign*.018*math.sin(math.pi*t)*math.sin(math.pi*u)
                verts.append((xx,y,z))
    step=(ny+1)*(nz+1)
    for side in (0,1):
        for j in range(nz):
            for i in range(ny):
                q=side*step+j*(ny+1)+i;f=(q,q+1,q+ny+2,q+ny+1)
                faces.append(f if (side==1)==(sign>0) else tuple(reversed(f)))
    for j in range(nz):
        for i in (0,ny):
            q=j*(ny+1)+i;faces.append((q,q+step,q+step+ny+1,q+ny+1))
    c.mesh('Padded outer and inner arm panel',verts,faces,'cloth_light',smooth=True)
    # Main scroll arm-front winds inward, with a wide planar carved support.
    front=-.334
    c.sphere('Solid carved gilt elliptical scroll face',
             (x,front+.005,.735),(.101,.012,.081),'antique_gold',48,12)
    spiral=[]
    for i in range(81):
        t=i/80;a=-math.pi*.50+t*math.pi*3.22;r=.105*(1-t)+.006
        spiral.append((x+sign*r*math.cos(a),front,.735+r*.79*math.sin(a)))
    gold.tube(spiral,.010,9)
    antique.tube([(xx,front-.008,zz) for xx,_,zz in spiral],.0029,6)
    # Structural serpentine leaf rail sweeps down toward square leg blocks.
    spine=[]
    for i in range(31):
        t=i/30
        xx=x+sign*(-.048+.065*math.sin(t*math.pi*.7))
        z=.324+.365*t
        spine.append((xx,front+.003,z))
    gold.tube(spine,.022,9)
    for offset in (-.021,.021):
        antique.tube([(xx+offset,yy-.007,zz) for xx,yy,zz in spine],.0037,6)
    for i in range(9):
        t=.09+i*.09
        idx=int(t*30);base=spine[idx]
        for direction in (-1,1):
            antique.leaf((base[0],front-.023,base[2]),
                         (base[0]+direction*.031,front-.022,base[2]+.055),.010,.005,3)
    # Radiating leaves emphasize the classic scroll, without text or logos.
    for i in range(12):
        a=-.3+i*TAU/14
        antique.leaf((x+sign*.068*math.cos(a),front-.006,.735+.055*math.sin(a)),
                     (x+sign*.099*math.cos(a+.13),front-.005,.735+.079*math.sin(a+.13)),.008,.004,2)
    # Rear outline shows on the back-quarter catalogue view.
    c.curve('Arm panel outer sewn hem',[(x+sign*.073,-.28,.353),(x+sign*.073,.302,.353),
              (x+sign*.073,.316,.730)],.0017,'cloth')


def leg(x,y,gold,antique):
    # Genuine alternating concave flute sections, tapered toward ferrules.
    profile=[(.018,.018),(.019,.035),(.020,.052),(.022,.085),(.026,.15),(.029,.21),(.029,.226)]
    verts=[];faces=[];na=48
    for radius,z in profile:
        for j in range(na):
            a=TAU*j/na;r=radius*(.92+.08*math.cos(a*12))
            verts.append((x+r*math.cos(a),y+r*math.sin(a),z))
    for i in range(len(profile)-1):
        for j in range(na):
            q=i*na+j;r=i*na+(j+1)%na;faces.append((q,r,r+na,q+na))
    c.mesh('Black piano lacquer tapered twelve-flute leg',verts,faces,'piano',smooth=True)
    for z,r,h in [(.020,.023,.016),(.047,.023,.012),(.215,.038,.012),(.238,.042,.020),(.254,.037,.012)]:
        c.lathe('Antique-gold turned leg collar and foot',(x,y,0),[(0,z-h/2),(r*.9,z-h/2),(r,z),(r*.9,z+h/2),(0,z+h/2)],'gold',32)
    # Flowered capital trim below frame; arranged all around, not front only.
    for i in range(12):
        a=TAU*i/12
        antique.bead((x+.036*math.cos(a),y+.036*math.sin(a),.238),.004,(1,1,1.5),6,4)


def apron(width,depth,gold,antique,seats):
    length=width-.185
    for y in (-.337,.318):
        c.box('High gloss black apron shadow line',(0,y,.301),(length,.055,.092),'piano',.004)
        c.box('Gilt carved front or rear apron',(0,y+(-.031 if y<0 else .031),.300),
              (length-.026,.012,.053),'antique_gold',.003)
        for z in (.269,.331):
            c.box('Gilded apron upper or lower moulding',(0,y,.0+z),(length,.063,.007),'gold',.002)
        # Repeating crossed laurel diamonds cast in shallow geometric relief.
        count=int(length/.041)
        yy=y+(-.039 if y<0 else .039)
        for i in range(count):
            x=-length/2+(i+.5)*length/count
            coords=[(x-.017,yy,.300),(x,yy,.320),(x+.017,yy,.300),(x,yy,.280)]
            gold.tube(coords,.0019,5,cyclic=True)
            antique.leaf((x-.012,yy-.001,.288),(x+.012,yy-.001,.312),.004,.002,2)
    for sign in (-1,1):
        x=sign*(width/2-.142)
        c.box('Side polished-black structural apron',(x,-.005,.301),(.062,.668,.091),'piano',.004)
        c.box('Side gilt relief frieze',(x+sign*.033,-.005,.302),(.013,.651,.055),'antique_gold',.002)
        for z in (.269,.331):
            c.box('Side gold moulded edge',(x,-.005,z),(.071,.677,.007),'gold',.002)
        for y in (-.337,.318):
            c.box('Square gilt corner die',(x,y,.299),(.092,.089,.091),'gold',.003)
            # Frontal rosette, quatrefoil centre surrounded by real petals.
            for i in range(8):
                a=TAU*i/8
                antique.leaf((x+.005*math.cos(a),y-.048,.299+.005*math.sin(a)),
                             (x+.033*math.cos(a),y-.048,.299+.033*math.sin(a)),.006,.003,2)
            antique.bead((x,y-.049,.299),.009,(1,.5,1),8,5)
    positions=[-width/2+.142,width/2-.142]
    # The photographed three-seater has a centre leg pair; the narrower
    # two-seater retains a central apron die but only four corner legs.
    if seats>2:positions.append(0)
    for x in positions:
        for y in (-.337,.318):
            leg(x,y,gold,antique)
    if seats>1:
        for y in (-.337,.318):
            c.box('Centre apron supporting gilt die',(0,y,.299),(.077,.079,.087),'gold',.003)
            for i in range(8):
                a=TAU*i/8
                antique.leaf((0,y-.044,.299),(.029*math.cos(a),y-.044,.299+.029*math.sin(a)),.005,.002,2)


def normalize(root,body,target):
    """Convert welts then normalize real evaluated surfaces, never curve boxes."""
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get()
    for ob in list(root.children_recursive):
        if ob.type!='CURVE':continue
        data=bpy.data.meshes.new_from_object(ob.evaluated_get(graph))
        result=bpy.data.objects.new(ob.name+' | editable modelled cord',data)
        bpy.context.scene.collection.objects.link(result);result.parent=ob.parent
        result.matrix_basis=ob.matrix_basis.copy()
        for p in data.polygons:p.use_smooth=True
        old=ob.data;bpy.data.objects.remove(ob,do_unlink=True)
        if not old.users:bpy.data.curves.remove(old)
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get()
    inverse=root.matrix_world.inverted();points=[]
    for ob in root.children_recursive:
        if ob.type!='MESH':continue
        ev=ob.evaluated_get(graph)
        points.extend(inverse@ev.matrix_world@v.co for v in ev.data.vertices)
    low=[min(p[k] for p in points) for k in range(3)]
    high=[max(p[k] for p in points) for k in range(3)]
    scale=[target[k]/(high[k]-low[k]) for k in range(3)]
    body.scale=scale
    body.location=(-(low[0]+high[0])*scale[0]/2,-(low[1]+high[1])*scale[1]/2,-low[2]*scale[2])
    root['catalogue_bounds_normalized']=True
    root['construction_note']='Reference-faithful editable visual reconstruction; unshown engineering interpreted.'
    bpy.context.view_layer.update()


def create(sku,instance='main'):
    sku=str(sku);width,depth,height,seats,title=SPECS[sku]
    root=c.empty(f'{title} | {sku} | {instance}',props={
        'kind':'product','product_id':sku,'instance_id':instance,
        'dimensions_mm':[round(v*1000) for v in (width,depth,height)],
        'catalogue_reference':'MARINER TRIANON, printed pages 42-43; PDF page 22',
        'finish':'POE/NB / OA (425 / 231); antique-gold leaf and black piano lacquer',
        'fabric_reference':'243.064 / 243.065; sage velvet and gold accent interpretation',
        'seat_cushions':seats,'mechanisms':'Fixed; no unsupported moving hardware',
    })
    with parent(root):body=c.empty('Exact metric floor-centred editable geometry')
    with parent(body):
        gold=Relief('Batched sculpted gilt scrolls, wreath, beading and frieze','gold')
        antique=Relief('Batched antique-gold acanthus, rosettes and carved leaf veins','antique_gold')
        apron(width,depth,gold,antique,seats)
        c.box('Upholstered dark seat deck',(0,-.02,.359),(width-.34,.687,.065),'cloth_dark',.021)
        upholstered_back(width,gold,antique)
        arm(width,-1,gold,antique);arm(width,1,gold,antique)
        inside=width-.487;gap=.009
        cw=(inside-(seats-1)*gap)/seats
        for i in range(seats):
            xx=-inside/2+cw/2+i*(cw+gap)
            cushion(f'Tailored seat {i+1}',(xx,-.065,.447),(cw,.655,.133),'cloth',seat=True,phase=i*1.7)
        # Large sage cushions sit behind smaller gold cushions as in source.
        if seats==1:
            accents=[(-.070,.093,.664,.355,'cloth_gold',-.10,.02)]
        else:
            end=width/2-.373
            accents=[(-end,.155,.699,.394,'cloth_dark',-.13,-.13),
                     (-end+.254,.080,.674,.357,'cloth_gold',-.11,.14),
                     (end-.254,.080,.674,.357,'cloth_gold',-.11,-.14),
                     (end,.155,.699,.394,'cloth_dark',-.13,.13)]
        for i,(xx,yy,zz,size,mat,rx,rz) in enumerate(accents):
            cushion(f'Loose {"gold" if mat=="cloth_gold" else "sage"} accent cushion {i+1}',
                    (xx,yy,zz),(size,.111,size),mat,rotation=(rx,0,rz),phase=i*2.27)
        gold.finish();antique.finish()
    normalize(root,body,(width,depth,height))
    return root
