"""Package actual native Trianon geometry, renders and source evidence."""
from pathlib import Path
import sys,json,shutil,hashlib,struct,zipfile
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'.local/catalogue-review/packages'))
import pymupdf as fitz
DIST=ROOT/'sites/rizky-atelier/dist';ASSET=DIST/'assets/collections/trianon';DOWN=DIST/'downloads/trianon'
ASSET.mkdir(parents=True,exist_ok=True);DOWN.mkdir(parents=True,exist_ok=True)
source=json.loads((BASE/'reference/products.json').read_text(encoding='utf8'));proof={};copies=[]
models=json.loads((ASSET/'products.json').read_text(encoding='utf8'))
for p in models:
    p['category']='seating' if p['sku'] in ('50472.0','50473.0','50474.0') else 'tables'
    p['referenceNote']=next(x for x in source['products'] if x['sku']==p['sku']).get('reference_note','')
(ASSET/'products.json').write_text(json.dumps(models,indent=2),encoding='utf8')
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
    raw=dst.read_bytes();copies.append({'destination':dst.relative_to(DIST).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
for name in ('overview','salon','lounge','console','tables','detail-carving','detail-velvet'):
    filename=name+('.png' if name.startswith('detail') else '-4k.png');src=BASE/'renders'/filename;raw=src.read_bytes();w,h=struct.unpack('>II',raw[16:24])
    assert (w,h)==((1600,1600) if name.startswith('detail') else (3840,2160))
    copy(src,DOWN/filename);pix=fitz.Pixmap(str(src))
    if w>1920:pix=fitz.Pixmap(pix,1920,round(h*1920/w))
    pix.save(str(ASSET/(name+'.jpg')),jpg_quality=93)
    proof[name]={'file':filename,'width':w,'height':h,'sha256':hashlib.sha256(raw).hexdigest(),'engine':'BLENDER_EEVEE','nativeScene':'trianon-exhibition.blend','originalBlenderRender':True}
for p in source['products']:
    src=BASE/'reference/catalogue'/(p['sku']+'.jpg');assert hashlib.sha256(src.read_bytes()).hexdigest()==p['image']['sha256'];copy(src,ASSET/'catalogue'/src.name)
copy(BASE/'trianon-exhibition.blend',DOWN/'trianon-exhibition.blend');copy(BASE/'native-audit.json',DOWN/'native-audit.json');copy(BASE/'reference/products.json',ASSET/'source-reference.json')
(DOWN/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
doc=fitz.open(source['source_pdf']);subset=fitz.open();subset.insert_pdf(doc,from_page=20,to_page=23);subset.save(str(DOWN/'TRIANON-reference-pages.pdf'),garbage=4,deflate=True);subset.close();doc.close()
sources=('core.py','geometry.py','sofas.py','casegoods.py','build_scene.py','export_web.py','render_scene.py','validate_native.py','prepare_assets.py','scene.json','build-report.json','export-report.json','native-audit.json','README.md')
with zipfile.ZipFile(DOWN/'trianon-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for filename in sources:z.write(BASE/filename,'trianon/'+filename)
    for p in (BASE/'textures').iterdir():z.write(p,'trianon/textures/'+p.name)
    for p in (BASE/'reference/catalogue').iterdir():z.write(p,'trianon/reference/catalogue/'+p.name)
    for p in (BASE/'reference/originals').iterdir():z.write(p,'trianon/reference/originals/'+p.name)
    z.write(BASE/'reference/catalogue-evidence.json','trianon/reference/catalogue-evidence.json')
    z.write(BASE/'scripts/read_catalogue.py','trianon/scripts/read_catalogue.py');z.write(BASE/'reference/products.json','trianon/reference/products.json');z.write(BASE/'trianon-exhibition.blend','trianon/trianon-exhibition.blend');z.write(DOWN/'TRIANON-reference-pages.pdf','trianon/TRIANON-reference-pages.pdf')
for p in DOWN.iterdir():assert p.stat().st_size<95*1024*1024,('GitHub file too large',p)
prefix='assets/collections/trianon';url='https://rizky-make-it.github.io/rizky-atelier/'
def render(name,title,caption):return {'image':prefix+'/'+name+'.jpg','title':title,'caption':caption,'request':'the original TRIANON Blender render: '+title,'sourceUrl':url+'downloads/trianon/'+proof[name]['file']}
def file(title,ext,desc,request,p):return {'title':title,'extension':ext,'description':desc,'request':request,'sourceUrl':url+p}
collection={'id':'trianon','name':'TRIANON','number':'05','referenceYear':2023,'kind':'Catalogue collection','title':'A gilded frame for quiet conversation.','tagline':'Sage velvet. Antique gold. Emperor marble.',
 'description':'Seven MARINER living-room references become a wall-free exhibition. Sage velvet seating, open wreath crests and scrolling gilded arms meet Emperor marble tables and a Calacatta console. Modelled foliate relief, fluted piano-black legs and tailored cushions interpret the supplied classic catalogue. Hidden construction and precise finish calibration remain visual interpretations.',
 'finish':'POE/NB / OA (425/231)','hero':prefix+'/salon.jpg','exhibition':prefix+'/trianon-exhibition.glb','scene':prefix+'/scene.json','placementCount':10,'movingParts':0,'sourceSite':url+'#/collections/trianon','sourceRepo':'https://github.com/rizky-make-it/rizky-atelier','productCount':7,'palette':['#56695d','#b18b41','#4a3024','#eee5d4'],
 'renders':[render('overview','The open Trianon gallery','Actual Blender exhibition render, 3840 × 2160. No walls or roof.'),render('salon','The sage salon','Three-seat sofa, scrolling armchairs and square Emperor marble coffee table. Actual Blender render: 3840 × 2160.'),render('lounge','A closer conversation','Two-seat sofa, rectangular coffee table and matching side table. Actual Blender render: 3840 × 2160.'),render('console','A sculpted silhouette','Calacatta console, carved frieze and fluted piano-black legs. Actual Blender render: 3840 × 2160.'),render('tables','Emperor & antique gold','Unobstructed square coffee-table study. Actual Blender render: 3840 × 2160.'),render('detail-carving','Carved, cast & gilded','Actual geometric acanthus, rosettes and capitals. Blender detail render, 1600 × 1600.'),render('detail-velvet','Softness within the scroll','Modelled velvet fullness, piping and gilded scroll arm. Blender detail render, 1600 × 1600.')],
 'materials':[{'image':prefix+'/detail-carving.jpg','title':'Antique-gold relief','description':'Physical foliate geometry and chased metal surfaces interpret the catalogue carvings and cast bronze. A native Blender render, not a calibrated physical sample.'},{'image':prefix+'/detail-velvet.jpg','title':'Sage velvet & scrolls','description':'Sculpted upholstery, cushion piping and authored woven normals inside gilded arms. A native Blender render.'}],
 'files':[file('Native Trianon exhibition','.BLEND','Seven SKUs, ten placements, packed PBR maps and seven cameras.','the TRIANON editable Blender exhibition master (.blend)','downloads/trianon/trianon-exhibition.blend'),file('Exhibition & individual models','.GLB','Seven full-detail inspectable products and an optimised open gallery.','the complete TRIANON exhibition GLB and seven individual product GLBs',prefix+'/trianon-exhibition.glb'),file('Complete rebuild project','.ZIP','Editable scene, geometry scripts, textures, reference evidence and native audit.','the complete TRIANON Blender project, textures and rebuild sources','downloads/trianon/trianon-project.zip'),file('Trianon living-room references','.PDF','Four supplied MARINER reference spreads; PDF pages 21–24.','the original TRIANON living-room catalogue reference pages','downloads/trianon/TRIANON-reference-pages.pdf'),file('Original 4K renders','4K PNG','Five genuine 4K Blender renders and two 1600-pixel details.','all TRIANON original 4K Blender renders and detail images','downloads/trianon/render-proof.json')]}
(ASSET/'collection.json').write_text(json.dumps(collection,indent=2),encoding='utf8');(BASE/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
(ASSET/'asset-audit.json').write_text(json.dumps({'collection':'TRIANON','sourcePDFSHA256':source['source_pdf_sha256'],'files':copies,'renderProof':proof},indent=2),encoding='utf8')
print('TRIANON_PACKAGED',json.dumps({'renders':len(proof),'nativeBytes':(DOWN/'trianon-exhibition.blend').stat().st_size,'zipBytes':(DOWN/'trianon-project.zip').stat().st_size}),flush=True)
