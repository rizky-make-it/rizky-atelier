"""Editable TRIANON living-room reconstruction; wall-free authored exhibition."""
import bpy,math,sys,json,random,time
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import core as c
import sofas,casegoods
started=time.perf_counter();random.seed(50472)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.materials();scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='METERS'
scene['collection']='TRIANON';scene['layout']='exhibition';scene['walls']=0;scene['roof']=False
scene['reference']='MARINER CLASSIC FURNITURE CATALOG 2023, PDF pages 21–24'
c.set_parent(None);staging=c.empty('TRIANON | authored open exhibition',props={'kind':'exhibition','walls':0,'roof':False});c.set_parent(staging)
c.box('Continuous pale stone floor',(5,4.7,-.11),(13,12,.22),'stone',.045)['kind']='exhibition-floor'
zones={
 'salon':{'name':'The sage salon','center':[3,6.9],'size':[6.2,5.8],'bounds':[-.4,4,6.4,10],'camera':[[5.8,4.4,1.65],[2.9,7.5,.75],45]},
 'lounge':{'name':'The conversation lounge','center':[8.4,7.1],'size':[4,5.3],'bounds':[6.45,4.3,10.5,10],'camera':[[10.1,5.1,1.65],[8.2,7.9,.65],45]},
 'console':{'name':'The carving gallery','center':[5,1.4],'size':[10.4,3.1],'bounds':[-.4,-.25,10.6,3.05],'camera':[[5,-.7,1.65],[5,1.5,.6],45]},
 'aisle':{'name':'The open promenade','bounds':[-.4,3.05,10.6,4.3],'camera':[[5.8,3.5,1.65],[8.6,3.5,1.35],45]},
}
for key,z in zones.items():
    if key=='aisle':continue
    x,y=z['center'];w,d=z['size'];c.box('Flush display inlay '+key,(x,y,-.012),(w,d,.025),'plinth',.012)
    c.curve('Fine antique-gold floor inlay '+key,[(x-w/2,y-d/2,.006),(x+w/2,y-d/2,.006),(x+w/2,y+d/2,.006),(x-w/2,y+d/2,.006)],.0025,'bronze',True)
def rug(name,x,y,w,d):
    c.box(name,(x,y,.015),(w,d,.028),'rug',.012)
    for inset in (.035,.065,.085):
        c.curve(name+' woven border',[(x-w/2+inset,y-d/2+inset,.030),(x+w/2-inset,y-d/2+inset,.030),(x+w/2-inset,y+d/2-inset,.030),(x-w/2+inset,y+d/2-inset,.030)],.0013,'cloth_light',True)
rug('Sage salon quiet woven rug',3,6.9,5.6,4.7)
rug('Conversation lounge woven rug',8.3,7.3,3.6,3.6)
placements=[]
def place(sku,zone,position,rotation=0):
    c.set_parent(None);module=sofas if sku in ('50472.0','50473.0','50474.0') else casegoods
    root=module.create(sku,instance=zone+'-'+str(len(placements)+1));root.location=position;root.rotation_euler.z=math.radians(rotation);root['room']=zone
    placements.append({'sku':sku,'room':zone,'position':list(position),'rotation':rotation,'instance':root['instance_id']});c.set_parent(staging);return root
place('50472.0','salon',(3,8.3,.030))
place('50474.0','salon',(.92,6.7,.030),65)
place('50474.0','salon',(5.08,6.7,.030),-65)
place('50475.1','salon',(3,6.7,.030))
place('50412.1','salon',(.99,8.25,.030));place('50412.1','salon',(5.01,8.25,.030))
place('50473.0','lounge',(8.3,8.1,.030))
place('50476.1','lounge',(8.3,6.6,.030))
place('50412.1','lounge',(9.82,7.85,.030))
place('50411.0','console',(5,1.55,0))
def books(x,y,z):
    for i,mat in enumerate(('piano','paper','wood_dark')):c.box('Interpreted design volume',(x,y,z+.013+i*.027),(.24,.17,.026),mat,.002,rot=(0,0,.05*(-1)**i))
def vase(x,y,z):
    c.lathe('Interpreted dark ceramic vase',(x,y,z),[(0,0),(.075,0),(.11,.035),(.12,.15),(.08,.22),(.035,.26),(.03,.26),(.032,.23)],'ceramic',48)
    for i in range(5):
        a=i*2.4;end=(x+math.cos(a)*.16,y+math.sin(a)*.13,z+.43+i*.02)
        c.rod('Styling olive stem',(x,y,z+.12),end,.0018,'bronze')
        for j in range(2):
            leaf=c.sphere('Styling olive leaf',(end[0]+j*.018,end[1],end[2]-j*.045),(.040,.013,.005),'leaf',12,6);leaf.rotation_euler=(.4,-.4,a)
vase(2.7,6.84,.50);books(3.3,6.5,.50)
books(8.0,6.65,.50);vase(8.65,6.65,.50)
vase(4.6,1.55,.88);books(5.33,1.55,.88)
world=bpy.data.worlds.new('TRIANON soft ivory studio');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.62,.67,.72,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.45
c.set_parent(None)
c.light('Broad daylight key','AREA',(-3,1,8),1700,(1,.92,.80),target=(4,6,.5),size=7)
c.light('Large neutral fill','AREA',(11,3,8),1450,(.86,.93,1),target=(5,6,.7),size=6)
c.light('Soft rim reflection','AREA',(4,12,7),2100,(1,.94,.83),target=(4,6,.5),size=6)
sun=c.light('Warm directional daylight','SUN',(-4,-6,10),1.15,(1,.94,.84),target=(4,5,0));sun.data.angle=.18
cameras={
 'overview':((15,-10,12),(5,4.7,.4),46),
 'salon':((7.8,1.7,3.4),(3,7.1,.63),40),
 'lounge':((12,2.7,3.3),(8.3,7.2,.65),46),
 'console':((7,-1.9,1.60),(5,1.55,.46),58),
 'tables':((5.0,3.5,1.65),(3,6.7,.26),62),
 'detail-carving':((6.1,.50,1.0),(5.51,1.38,.72),75),
 'detail-velvet':((4.65,7.05,1.05),(4.14,7.98,.73),85),
}
for key,(loc,target,lens) in cameras.items():
    data=bpy.data.cameras.new('Lens '+key);obj=bpy.data.objects.new('Camera '+key,data);scene.collection.objects.link(obj);obj.location=loc;obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler();data.lens=lens;data.clip_start=.02;data.clip_end=180
    if key.startswith('detail'):
        data.dof.use_dof=True;data.dof.focus_distance=(Vector(target)-Vector(loc)).length;data.dof.aperture_fstop=5.6
scene.camera=bpy.data.objects['Camera salon'];scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=True
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.render.film_transparent=False;scene.render.image_settings.compression=25
info={'collection':'TRIANON','units':'metres','layout':'exhibition','walls':0,'roof':False,'floorBounds':[-1,-1,11,10.5],'rooms':zones,'placements':placements,'colliders':[],
      'overview':{'position':[15,12,10],'target':[5,.4,-4.7],'fov':45},'source':'CLASSIC_FURNITURE_CATALOG_2023.pdf','sourcePages':[21,22,23,24],'finish':'POE/NB / OA (425/231)',
      'interpretations':['Open exhibition and complementary styling','Unseen joinery and underside details','Procedural material calibration','Rectangular coffee-table adaptation from shared detail image; no unverified opening hardware']}
scene['web_scene_info']=json.dumps(info);(BASE/'scene.json').write_text(json.dumps(info,indent=2),encoding='utf8')
def ancestor(obj):
    while obj:
        if obj.get('kind')=='product':return obj
        obj=obj.parent
    return None
product_cols={}
for obj in list(scene.objects):
    root=ancestor(obj)
    if not root:continue
    if root.name not in product_cols:
        col=bpy.data.collections.new(root['product_id']+' | '+root['instance_id']);scene.collection.children.link(col);product_cols[root.name]=col
    col=product_cols[root.name];col.objects.link(obj)
    for old in list(obj.users_collection):
        if old!=col:old.objects.unlink(obj)
# Retain the authored catalogue material library even where gilding covers
# the veneer in this particular display; a subsequent save must not purge it.
for mat in bpy.data.materials:mat.use_fake_user=True
for im in bpy.data.images:
    if im.source=='FILE':im.use_fake_user=True
bpy.ops.file.pack_all()
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.region_3d.view_camera_zoom=0;area.spaces.active.shading.type='MATERIAL'
report={'collection':'TRIANON','products':7,'placements':len(placements),'movingParts':0,'objects':len(scene.objects),'meshes':sum(o.type=='MESH' for o in scene.objects),'walls':0,'roof':False,'seconds':round(time.perf_counter()-started,2)}
(BASE/'build-report.json').write_text(json.dumps(report,indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'trianon-exhibition.blend'),compress=True)
print('TRIANON_BUILD_COMPLETE',json.dumps(report),flush=True)
