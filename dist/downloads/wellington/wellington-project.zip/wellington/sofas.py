"""WELLINGTON rectilinear upholstery, reconstructed from MARINER pp.50-55.

Six printed catalogue SKUs, with genuinely different exterior treatments:
navy/white lacquer has a diamond-tufted rear and rigid medallion sides;
burgundy has diamond-tufted sides and a smooth upholstered rear. Dimensions
are metres, X width/Y depth/Z up, origin at floor centre, front toward -Y.
Hidden construction and unshown details are visual interpretations, not CAD.
"""
import math
from contextlib import contextmanager
import bpy
from mathutils import Vector
import core as c

TAU=math.tau
SPECS={
 '50292.0':(2.50,.95,.95,3,'navy','Wellington navy three-seat sofa'),
 '50293.0':(1.80,.95,.95,2,'navy','Wellington navy two-seat sofa'),
 '50294.2':(1.06,.95,.95,1,'white','Wellington white-frame navy armchair'),
 '50490.0':(2.50,.95,.95,3,'red','Wellington burgundy three-seat sofa'),
 '50491.0':(1.80,.95,.95,2,'red','Wellington burgundy two-seat sofa'),
 '50492.0':(1.06,.95,.95,1,'red','Wellington burgundy armchair'),
}

@contextmanager
def parent(ob):
    previous=c.PARENT;c.set_parent(ob)
    try:yield ob
    finally:c.set_parent(previous)


class Batch:
    """Material-batched solid gold trim, buttons and sculpted acanthus."""
    def __init__(self,name,mat):self.name=name;self.mat=mat;self.v=[];self.f=[]
    def tube(self,points,radius,sides=6,cyclic=False):
        pts=[Vector(p) for p in points]
        if cyclic:pts.append(pts[0])
        start=len(self.v)
        for i,p in enumerate(pts):
            tangent=(pts[min(i+1,len(pts)-1)]-pts[max(i-1,0)]).normalized()
            axis=Vector((0,1,0)) if abs(tangent.y)<.95 else Vector((0,0,1))
            a=tangent.cross(axis).normalized();b=tangent.cross(a).normalized()
            for j in range(sides):
                angle=TAU*j/sides;self.v.append(tuple(p+radius*(a*math.cos(angle)+b*math.sin(angle))))
        for i in range(len(pts)-1):
            for j in range(sides):
                q=start+i*sides+j;r=start+i*sides+(j+1)%sides
                self.f.append((q,r,r+sides,q+sides))
        self.f.append(tuple(start+j for j in range(sides-1,-1,-1)))
        self.f.append(tuple(start+(len(pts)-1)*sides+j for j in range(sides)))
    def sphere(self,centre,scale,sides=8,rings=6):
        base=len(self.v)
        for j in range(rings+1):
            t=math.pi*j/rings
            for i in range(sides):
                a=TAU*i/sides
                self.v.append((centre[0]+scale[0]*math.sin(t)*math.cos(a),
                               centre[1]+scale[1]*math.sin(t)*math.sin(a),
                               centre[2]+scale[2]*math.cos(t)))
        for j in range(rings):
            for i in range(sides):
                q=base+j*sides+i;r=base+j*sides+(i+1)%sides;self.f.append((q,r,r+sides,q+sides))
    def leaf(self,start,end,width,normal=(0,-1,0),bulge=.004):
        a,b,n=Vector(start),Vector(end),Vector(normal);d=b-a
        across=d.cross(n).normalized();base=len(self.v);rows=8
        for j in range(rows+1):
            t=j/rows;w=width*math.sin(math.pi*t)**.8*(.8+.2*math.cos(t*TAU*3))
            for i in range(5):
                u=(i-2)/2;p=a+d*t+across*u*w+n*bulge*math.sin(math.pi*t)*(1-.75*abs(u))
                self.v.append(tuple(p))
        for j in range(rows):
            for i in range(4):
                q=base+j*5+i;self.f.append((q,q+1,q+6,q+5))
        self.tube([tuple(a+d*t+n*(bulge*math.sin(math.pi*t)+.0006)) for t in [i/8 for i in range(9)]],.0008,5)
    def finish(self):
        if self.f:return c.mesh(self.name,self.v,self.f,self.mat,smooth=True)


def cushion(name,centre,dims,mat,rotation=(0,0,0),seat=False,piping=None,phase=0,panel=False):
    """Closed six-patch filled textile with actual seam tension and cloth folds."""
    holder=c.empty(name,centre);holder.rotation_euler=rotation
    half=[d/2 for d in dims];power=14 if panel else (10 if seat else 4.7);n=18 if seat else 16
    def shape(q):
        denominator=sum(abs(v)**power for v in q)**(1/power)
        p=[half[k]*q[k]/denominator for k in range(3)]
        if seat:
            if abs(q[2])>.99:
                edge=math.exp(-((abs(q[1])-.86)/.16)**2)
                p[2]+=math.copysign(.0036*math.sin(q[0]*39+phase+math.sin(q[0]*11))*edge,q[2])
                if q[2]>0:p[2]-=.004*(1-q[0]**2)*(1-q[1]**2)
            if abs(q[1])>.99:
                p[1]+=math.copysign(.0045*math.sin(q[0]*36+phase)*(1-q[2]**2),q[1])
                p[2]+=.0017*math.sin(q[0]*57+q[2]*4+phase)
        elif abs(q[1])>.99:
            edge=math.exp(-((abs(q[0])-.84)/.16)**2)+math.exp(-((abs(q[2])-.85)/.14)**2)
            folds=(.0018 if panel else .0060)*math.sin(q[0]*31+q[2]*10+phase)*edge
            p[1]+=math.copysign((.001 if panel else .009)*(1-q[0]**2)*(1-q[2]**2)+folds,q[1])
            p[2]+=.0031*math.sin(q[0]*8+phase)*(1-q[0]**2)
        return tuple(p)
    with parent(holder):
        verts=[];faces=[];uvs=[]
        for axis,sign in [(0,-1),(0,1),(1,-1),(1,1),(2,-1),(2,1)]:
            other=[i for i in range(3) if i!=axis];base=len(verts)
            for j in range(n+1):
                for i in range(n+1):
                    q=[0,0,0];q[axis]=sign;q[other[0]]=-1+2*i/n;q[other[1]]=-1+2*j/n
                    verts.append(shape(q));uvs.append((q[other[0]]*half[other[0]],q[other[1]]*half[other[1]]))
            forward=sign*(1 if axis!=1 else -1)>0
            for j in range(n):
                for i in range(n):
                    q=base+j*(n+1)+i;f=(q,q+1,q+n+2,q+n+1);faces.append(f if forward else tuple(reversed(f)))
        c.mesh(name+' | gathered velvet and filled corners',verts,faces,mat,uvs,True)
        coords=[]
        for side in range(4):
            for i in range(20):
                t=-1+2*i/20;x,z=[(1,t),(-t,1),(-1,-t),(t,-1)][side]
                coords.append(shape((x,z,0) if seat else (x,0,z)))
        c.curve(name+' | sewn perimeter piping',coords,.0018,piping or mat,True)
    return holder


def round_pillow(name,centre,radius,mat,rotation=(0,0,0),phase=0):
    holder=c.empty(name,centre);holder.rotation_euler=rotation
    with parent(holder):
        verts=[];faces=[];uv=[];nr=15;na=64
        for side in (-1,1):
            for j in range(nr+1):
                r=radius*j/nr;u=j/nr
                for i in range(na+1):
                    a=TAU*i/na
                    thickness=.010+.045*max(0,1-u*u)**.75
                    fold=.003*math.sin(a*19+phase)*math.exp(-((u-.91)/.15)**2)
                    verts.append((r*math.cos(a),side*(thickness+fold),r*math.sin(a)))
                    uv.append((.5+r*math.cos(a),.5+r*math.sin(a)))
        step=(nr+1)*(na+1)
        for side in range(2):
            for j in range(nr):
                for i in range(na):
                    q=side*step+j*(na+1)+i;f=(q,q+1,q+na+2,q+na+1)
                    faces.append(f if side==0 else tuple(reversed(f)))
        for i in range(na):
            q=nr*(na+1)+i;faces.append((q,q+step,q+step+1,q+1))
        c.mesh(name+' | circular gathered damask',verts,faces,mat,uv,True)
        c.curve(name+' | ivory contrast welt',[(radius*math.cos(TAU*i/96),0,radius*math.sin(TAU*i/96)) for i in range(96)],.0021,'ivory',True)
    return holder


def tuft_panel(name,origin,u_axis,normal,width,height,mat):
    """Continuous displaced diamond upholstery, recessed buttons and creases."""
    origin,u_axis,normal=Vector(origin),Vector(u_axis),Vector(normal)
    nu=max(40,int(width/.010));nv=max(36,int(height/.010))
    pu=.172;pv=.138
    def depth(u,z):
        U=u/pu+.19;V=z/pv+.08;a=U-.5*V;b=U+.5*V
        qa=abs(a-round(a));qb=abs(b-round(b))
        diamond=abs(math.sin(math.pi*a)*math.sin(math.pi*b))
        row=round(V);col=round(U-.5*row)+.5*row
        du=(U-col)*pu;dv=(V-row)*pv;r=math.hypot(du,dv)
        crease=.0038*(math.exp(-(qa/.066)**2)+math.exp(-(qb/.066)**2))
        inset=.015*math.exp(-(r/.022)**2)
        wrinkles=.002*math.sin(6*math.atan2(dv,du)+u*4)*math.exp(-r/.043)
        edge=min(u,width-u,z,height-z)
        taper=max(0,min(1,edge/.020));taper=taper*taper*(3-2*taper)
        return (.009+.033*diamond**.65-crease-inset+wrinkles)*taper
    vertices=[];faces=[];uv=[]
    for j in range(nv+1):
        z=height*j/nv
        for i in range(nu+1):
            u=width*i/nu;p=origin+u_axis*u+Vector((0,0,z))+normal*depth(u,z)
            vertices.append(tuple(p));uv.append((u,z))
    # Axis cross Z determines face winding; choose outward consistently.
    forward=u_axis.cross(Vector((0,0,1))).dot(normal)>0
    for j in range(nv):
        for i in range(nu):
            q=j*(nu+1)+i;f=(q,q+1,q+nu+2,q+nu+1)
            faces.append(f if forward else tuple(reversed(f)))
    c.mesh(name+' | genuinely displaced diamond quilting',vertices,faces,mat,uv,True)
    buttons=Batch(name+' | fabric-covered recessed buttons',mat)
    for row in range(5):
        z=(row-.08)*pv
        if z<.025 or z>height-.025:continue
        for column in range(int(width/pu)+3):
            u=(column+.5*row-.19)*pu
            if not .022<u<width-.022:continue
            p=origin+u_axis*u+Vector((0,0,z))+normal*(depth(u,z)+.001)
            buttons.sphere(tuple(p),tuple(.003 if abs(normal[k])>.9 else .0061 for k in range(3)),10,6)
    buttons.finish()
    corners=[origin,origin+u_axis*width,origin+u_axis*width+Vector((0,0,height)),origin+Vector((0,0,height))]
    c.curve(name+' | upholstered perimeter welt',[tuple(p+normal*.001) for p in corners],.0019,mat,True)


def bead_line(batch,a,b,pitch=.011,radius=.0023):
    a,b=Vector(a),Vector(b);n=max(1,round((b-a).length/pitch))
    for i in range(n+1):batch.sphere(tuple(a+(b-a)*i/n),(radius,radius,radius),5,3)


def classical_medallion(gold,antique,centre,normal,radius):
    """Sculpted classical face/leaf relief, not a printed logo or texture."""
    p=Vector(centre);n=Vector(normal);u=Vector((0,1,0)) if abs(n.x)>.9 else Vector((1,0,0));z=Vector((0,0,1))
    ring=[tuple(p+radius*(u*math.cos(TAU*i/64)+z*math.sin(TAU*i/64))) for i in range(64)]
    gold.tube(ring,radius*.045,8,True)
    # Low relief face, brows, nose, mouth and small curled hair leaves.
    scale=[radius*.27,radius*.27,radius*.37]
    for k in range(3):
        if abs(n[k])>.9:scale[k]=radius*.12
    antique.sphere(tuple(p+n*.004),tuple(scale),18,12)
    for sign in (-1,1):
        brow=p+u*(sign*radius*.12)+z*(radius*.095)+n*(radius*.125)
        gold.tube([tuple(brow-u*radius*.07),tuple(brow+z*radius*.025),tuple(brow+u*radius*.07)],radius*.016,6)
        for j in range(5):
            a=(.22+j*.38)*sign
            start=p+u*(math.sin(a)*radius*.28)+z*(math.cos(a)*radius*.30)+n*.003
            end=p+u*(math.sin(a)*radius*.58)+z*(math.cos(a)*radius*.57)+n*.004
            antique.leaf(tuple(start),tuple(end),radius*.09,normal,radius*.04)
    gold.tube([tuple(p+z*radius*.09+n*radius*.16),tuple(p-z*radius*.05+n*radius*.24),tuple(p-z*radius*.09+n*radius*.14)],radius*.033,7)
    gold.tube([tuple(p-u*radius*.08-z*radius*.18+n*radius*.11),tuple(p-z*radius*.20+n*radius*.13),tuple(p+u*radius*.08-z*radius*.18+n*radius*.11)],radius*.018,6)
    for i in range(24):
        a=TAU*i/24
        gold.sphere(tuple(p+radius*.84*(u*math.cos(a)+z*math.sin(a))+n*.002),(radius*.026,)*3,6,4)


def front_pendant(x,gold,antique):
    y=-.486
    # Matching small symmetrical lyre-and-leaf ormolu applique on each post.
    for sign in (-1,1):
        gold.tube([(x+sign*(.008+.010*math.sin(math.pi*t)),y,.694-.100*t) for t in [i/18 for i in range(19)]],.0025,6)
        for i in range(4):
            z=.686-i*.026
            antique.leaf((x+sign*.006,y-.001,z),(x+sign*.019,y-.001,z+.022),.0055,bulge=.002)
    gold.tube([(x,y,.600),(x,y,.547)],.0022,6)
    for i in range(3):
        z=.590-i*.017
        antique.leaf((x,y,z),(x+.008,y,z-.018),.004,bulge=.002)
        antique.leaf((x,y,z),(x-.008,y,z-.018),.004,bulge=.002)
    gold.sphere((x,y-.001,.713),(.005,.002,.006),8,6)


def foot(x,y,gold,antique):
    c.lathe('Short antique-gold acanthus foot',(x,y,0),[(0,.008),(.020,.008),(.021,.025),(.023,.058),(.033,.105),(.037,.119),(0,.119)],'gold',32)
    c.lathe('Foot capital collar',(x,y,0),[(0,.108),(.038,.108),(.040,.116),(.036,.124),(0,.124)],'antique_gold',32)
    for i in range(8):
        a=TAU*i/8;n=(math.cos(a),math.sin(a),0)
        start=(x+.021*n[0],y+.021*n[1],.020)
        end=(x+.035*n[0],y+.035*n[1],.109)
        antique.leaf(start,end,.008,n,.003)


def shell(width,seats,family,gold,antique):
    red=family=='red';outer='white' if family=='white' else 'piano'
    face='wood' if family=='white' else 'white';fabric='burgundy' if red else 'cloth'
    # Rigid rectangular U-front, with real thickness and two concentric trims.
    c.box('Continuous rigid lower black or white frame',(0,0,.170),(width,.930,.102),outer,.006)
    for sign in (-1,1):
        x=sign*(width/2-.061)
        c.box('Square vertical front arm post',(x,-.410,.468),(.122,.121,.644),outer,.004)
        c.box('White or figured-timber inset front upright',(x,-.475,.476),(.083,.011,.586),face,.002)
        for dx in (-.043,.043):
            gold.tube([(x+dx,-.483,.183),(x+dx,-.483,.769)],.0018,5)
            bead_line(gold,(x+dx,-.484,.185),(x+dx,-.484,.767),.009,.0018)
        front_pendant(x,gold,antique)
        # Upholstered padded inner arm and long inset top cushion.
        c.box('Solid external arm structural backing',(sign*(width/2-.077),.023,.465),(.132,.835,.600),outer,.004)
        cushion('Padded inner armrest', (sign*(width/2-.139),.021,.516),(.090,.787,.421),fabric,seat=False)
        cushion('Long tailored flat arm-top pad',(sign*(width/2-.071),.018,.780),(.135,.802,.067),fabric,seat=True)
        # Keep the top outside rectangular rather than a Trianon rolled arm.
        c.box('Long polished outer arm cap rail',(sign*(width/2-.012),.020,.783),(.026,.888,.034),outer,.003)
        bead_line(gold,(sign*(width/2-.006),-.405,.801),(sign*(width/2-.006),.435,.801),.010,.0018)
        if not red:
            # Both faces of hard side panels are closed, varnished objects.
            side_x=sign*(width/2+.001)
            c.box('Rigid side inset: lacquer or dark figured timber',(side_x,.023,.465),(.012,.794,.544),face,.002)
            for z in (.192,.737):
                gold.tube([(side_x+sign*.009,-.374,z),(side_x+sign*.009,.420,z)],.0020,6)
                bead_line(gold,(side_x+sign*.010,-.373,z),(side_x+sign*.010,.419,z),.011,.0018)
            for y in (-.376,.422):gold.tube([(side_x+sign*.009,y,.193),(side_x+sign*.009,y,.737)],.0020,6)
            disc=c.cylinder('Circular black piano-lacquer side medallion field',(side_x+sign*.014,.026,.469),.166,.012,'piano')
            disc.rotation_euler[1]=math.pi/2
            gold.tube([(side_x+sign*.022,.026+.166*math.cos(TAU*i/96),.469+.166*math.sin(TAU*i/96)) for i in range(96)],.0036,8,True)
            coin=c.cylinder('Cast bronze side medallion',(side_x+sign*.025,.026,.469),.074,.014,'antique_gold');coin.rotation_euler[1]=math.pi/2
            classical_medallion(gold,antique,(side_x+sign*.035,.026,.469),(sign,0,0),.073)
            # Navy rigid variants have small flame/acorn ormolu front finials.
            c.lathe('Front arm-top turned gold finial',(x,-.403,0),[(0,.793),(.017,.793),(.021,.802),(.010,.812),(.015,.826),(.010,.843),(0,.857)],'gold',28)
            for j in range(8):
                a=TAU*j/8
                antique.leaf((x+.006*math.cos(a),-.403+.006*math.sin(a),.815),
                             (x+.012*math.cos(a),-.403+.012*math.sin(a),.844),.004,(math.cos(a),math.sin(a),0),.002)
        else:
            # Full tufted burgundy side replaces the hard-panel/medallion set.
            tuft_panel('Burgundy diamond-tufted outer '+str(sign)+' side',
                       (sign*(width/2-.001),-.401,.169),(0,1,0),(sign,0,0),.837,.590,'burgundy')
    # Full-width front apron is an actual white/wood panel, not a screen plane.
    c.box('Broad horizontal U-front fascia',(0,-.475,.206),(width-.038,.012,.084),face,.002)
    for z in (.163,.249):
        gold.tube([(-width/2+.020,-.484,z),(width/2-.020,-.484,z)],.0019,6)
        bead_line(gold,(-width/2+.022,-.485,z),(width/2-.022,-.485,z),.010,.0018)
    ring=c.cylinder('Central apron black medallion',(0,-.490,.207),.042,.011,'piano');ring.rotation_euler[0]=math.pi/2
    coin=c.cylinder('Central apron bronze relief',(0,-.498,.207),.034,.009,'antique_gold');coin.rotation_euler[0]=math.pi/2
    classical_medallion(gold,antique,(0,-.505,.207),(0,-1,0),.033)
    # All feet are short cast leaves, never Trianon's tall black tapered legs.
    xs=[-width/2+.061,width/2-.061]
    if red and seats==3:xs.append(0)
    for x in xs:
        for y in (-.410,.414):foot(x,y,gold,antique)
    c.box('Closed rear structural backing',(0,.427,.461),(width-.063,.060,.589),outer,.005)
    if red:
        cushion('Smooth taut burgundy upholstered rear panel',(0,.477,.458),
                (width-.056,.026,.620),'burgundy',panel=True)
    else:
        tuft_panel('Navy diamond-tufted full exterior rear',(-width/2+.032,.461,.170),(1,0,0),(0,1,0),width-.064,.586,'cloth')
    c.box('Straight rear polished top rail',(0,.447,.778),(width-.020,.054,.025),outer,.003)
    bead_line(gold,(-width/2+.018,.476,.788),(width/2-.018,.476,.788),.011,.0019)
    c.box('Upholstered seat deck',(0,-.009,.254),(width-.224,.794,.065),fabric,.015)


def normalize(root,body,target):
    """Materialize curves before measuring Blender 5.2 evaluated surfaces."""
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get()
    for ob in list(root.children_recursive):
        if ob.type!='CURVE':continue
        data=bpy.data.meshes.new_from_object(ob.evaluated_get(graph))
        result=bpy.data.objects.new(ob.name+' | editable cord mesh',data);bpy.context.scene.collection.objects.link(result)
        result.parent=ob.parent;result.matrix_basis=ob.matrix_basis.copy()
        for face in data.polygons:face.use_smooth=True
        old=ob.data;bpy.data.objects.remove(ob,do_unlink=True)
        if not old.users:bpy.data.curves.remove(old)
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get();inv=root.matrix_world.inverted();points=[]
    for ob in root.children_recursive:
        if ob.type!='MESH':continue
        ev=ob.evaluated_get(graph);points.extend(inv@ev.matrix_world@v.co for v in ev.data.vertices)
    lo=[min(p[k] for p in points) for k in range(3)];hi=[max(p[k] for p in points) for k in range(3)]
    scale=[target[k]/(hi[k]-lo[k]) for k in range(3)];body.scale=scale
    body.location=(-(lo[0]+hi[0])*scale[0]/2,-(lo[1]+hi[1])*scale[1]/2,-lo[2]*scale[2])
    root['catalogue_bounds_normalized']=True
    root['construction_note']='Editable reference-based visual reconstruction; unshown construction interpreted.'
    bpy.context.view_layer.update()


def create(sku,instance='main'):
    sku=str(sku);width,depth,height,seats,family,title=SPECS[sku];red=family=='red'
    root=c.empty(f'{title} | {sku} | {instance}',props={
      'kind':'product','product_id':sku,'instance_id':instance,
      'dimensions_mm':[round(v*1000) for v in (width,depth,height)],
      'catalogue_reference':'MARINER WELLINGTON printed pages 50-55 / PDF 26-28',
      'finish':'WE.W / DB (536 / 67)' if family=='white' else 'WE.L / DB (535 / 67)',
      'fabric_reference':'243.066 / 241.188 / 241.182' if red else '243.030 / 241.201',
      'seat_cushions':seats,'exterior_sides':'Diamond-tufted burgundy' if red else 'Rigid medallion panels',
      'exterior_rear':'Smooth burgundy' if red else 'Diamond-tufted navy',
      'side_medallions':not red,'front_finials':not red,
      'mechanisms':'Fixed; no unsupported articulation',
    })
    if sku=='50491.0':root['source_image_note']='Catalogue shares a three-seater image; two-seater rebuilt to its separately printed 1800mm width.'
    with parent(root):body=c.empty('Exact metric editable Wellington geometry')
    with parent(body):
        gold=Batch('Batched gold beading, finials, pendants and medallion relief','gold')
        antique=Batch('Batched cast acanthus and classical relief','antique_gold')
        shell(width,seats,family,gold,antique)
        fabric='burgundy' if red else 'cloth';light='red_light' if red else 'cloth_light'
        inside=width-.285;gap=.012;cw=(inside-(seats-1)*gap)/seats
        for i in range(seats):
            x=-inside/2+cw/2+i*(cw+gap)
            cushion(f'Seat cushion {i+1}',(x,-.055,.357),(cw,.754,.196),fabric,seat=True,piping=light,phase=i*1.73)
            cushion(f'Large loose back cushion {i+1}',(x,.284,.712),(cw+.006,.168,.480),fabric,rotation=(-.125,0,0),piping=light,phase=i*2.7)
        if red:
            if seats>1:
                end=width/2-.330
                accents=[(-end,.134,.633,.350,'red_light',-.15,-.13),
                         (-end+.245,.056,.607,.285,'ivory',-.13,.12),
                         (end-.245,.056,.607,.285,'ivory',-.13,-.12),
                         (end,.134,.633,.350,'red_light',-.15,.13)]
                if seats==3:accents.insert(2,(0,.090,.642,.385,'burgundy',-.13,.03))
            else:accents=[]
        elif seats==1:
            accents=[(-.105,.075,.627,.330,'damask',-.13,-.13)]
        else:
            end=width/2-.320
            accents=[(-end,.126,.664,.382,'damask',-.15,-.14),
                     (-end+.223,.058,.621,.293,'cloth_light',-.13,.13),
                     (end-.223,.058,.621,.293,'cloth_light',-.13,-.13),
                     (end,.126,.664,.382,'damask',-.15,.14)]
            if seats==3:
                for i,x in enumerate((-.370,.370)):
                    round_pillow(f'Round black damask accent {i+1}',(x,.043,.611),.158,'damask',(-.10,0,(-.08 if x<0 else .08)),i*1.3)
            else:round_pillow('Round black damask centre accent',(0,.041,.604),.151,'damask',(-.10,0,.05))
        for i,(x,y,z,size,mat,rx,rz) in enumerate(accents):
            cushion(f'Loose decorative cushion {i+1}',(x,y,z),(size,.108,size),mat,
                    rotation=(rx,0,rz),piping='ivory' if mat=='damask' else mat,phase=i*2.17)
        gold.finish();antique.finish()
    normalize(root,body,(width,depth,height))
    return root
