"""Editable WELLINGTON living-room reconstruction; wall-free authored exhibition."""
import bpy,math,sys,json,random,time
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import core as c
import sofas,casegoods
started=time.perf_counter();random.seed(50292)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.materials();scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='METERS'
scene['collection']='WELLINGTON';scene['layout']='exhibition';scene['walls']=0;scene['roof']=False
scene['reference']='MARINER CLASSIC FURNITURE CATALOG 2023, PDF pages 25–31'
c.set_parent(None);staging=c.empty('WELLINGTON | authored open exhibition',props={'kind':'exhibition','walls':0,'roof':False});c.set_parent(staging)
c.box('Continuous pale stone floor',(6,5.5,-.11),(16,14,.22),'stone',.045)['kind']='exhibition-floor'
zones={
 'navy':{'name':'The navy salon','center':[3,9],'size':[6,5.3],'bounds':[-.3,6.3,6.2,12],'camera':[[5.8,6.2,1.65],[2.9,9.4,.65],45]},
 'burgundy':{'name':'The burgundy salon','center':[9,9],'size':[5.7,5.3],'bounds':[6.3,6.3,12.3,12],'camera':[[11.8,6.2,1.65],[9,9.4,.65],45]},
 'pair':{'name':'Two conversations','center':[4.5,4.3],'size':[7.6,2.7],'bounds':[.4,3,8.4,5.9],'camera':[[4.8,2.5,1.65],[4.6,4.5,.65],45]},
 'consoles':{'name':'The lacquer gallery','center':[6,1.4],'size':[12,2.5],'bounds':[-.4,-.2,12.4,2.8],'camera':[[6,-.8,1.65],[6,1.5,1.2],45]},
 'media':{'name':'The media piece','center':[10.5,4.3],'size':[3.4,2.7],'bounds':[8.7,3,12.4,5.9],'camera':[[10.5,2.8,1.65],[10.5,4.6,.45],45]},
 'aisle':{'name':'The open promenade','bounds':[-.4,5.8,12.4,6.4],'camera':[[5.8,6.1,1.65],[9.4,6.1,1.35],45]},
}
for key,z in zones.items():
    if key=='aisle':continue
    x,y=z['center'];w,d=z['size'];c.box('Flush display inlay '+key,(x,y,-.012),(w,d,.025),'plinth',.012)
    c.curve('Fine antique-gold floor inlay '+key,[(x-w/2,y-d/2,.006),(x+w/2,y-d/2,.006),(x+w/2,y+d/2,.006),(x-w/2,y+d/2,.006)],.0025,'bronze',True)
def rug(name,x,y,w,d):
    c.box(name,(x,y,.015),(w,d,.028),'rug',.012)
    for inset in (.035,.065,.085):
        c.curve(name+' woven border',[(x-w/2+inset,y-d/2+inset,.030),(x+w/2-inset,y-d/2+inset,.030),(x+w/2-inset,y+d/2-inset,.030),(x-w/2+inset,y+d/2-inset,.030)],.0013,'cloth_light',True)
rug('Navy salon quiet woven rug',3,9,5.6,4.7)
rug('Burgundy salon quiet woven rug',9,9,5.3,4.7)
placements=[]
def place(sku,zone,position,rotation=0):
    c.set_parent(None);module=sofas if sku in ('50292.0','50293.0','50294.2','50490.0','50491.0','50492.0') else casegoods
    root=module.create(sku,instance=zone+'-'+str(len(placements)+1));root.location=position;root.rotation_euler.z=math.radians(rotation);root['room']=zone
    placements.append({'sku':sku,'room':zone,'position':list(position),'rotation':rotation,'instance':root['instance_id']});c.set_parent(staging);return root
place('50292.0','navy',(3,9.8,.030))
place('50294.2','navy',(.92,8.2,.030),65);place('50294.2','navy',(5.08,8.2,.030),-65)
place('50296.0','navy',(3,8.2,.030))
place('50278.0','navy',(.99,9.72,.030));place('50278.0','navy',(5.01,9.72,.030))
place('50490.0','burgundy',(9,9.8,.030))
place('50492.0','burgundy',(7,8.2,.030),65);place('50492.0','burgundy',(11,8.2,.030),-65)
place('50295.0','burgundy',(9,8.2,.030));place('50278.0','burgundy',(11,9.72,.030))
place('50293.0','pair',(2.8,4.4,0));place('50491.0','pair',(6.2,4.4,0));place('50278.0','pair',(4.5,4.4,0))
place('50279.0','consoles',(2,1.25,0));place('50280.0','consoles',(2,1.60,.94))
place('50357.0','consoles',(6,1.25,0));place('50302.0','consoles',(6,1.60,.98))
place('50297.0','consoles',(10.5,1.35,0));place('50298.2','media',(10.5,4.6,0))
# Exhibition-only rear supports, not asserted as catalogue mirror hardware.
for x in (2,6):
    c.box('Independent mirror display support',(x,1.69,1.25),(.028,.04,2.50),'piano',.005)
    c.box('Mirror support floor foot',(x,1.74,.022),(.62,.28,.045),'piano',.012)
def books(x,y,z):
    for i,mat in enumerate(('piano','paper','wood_dark')):c.box('Interpreted design volume',(x,y,z+.013+i*.027),(.24,.17,.026),mat,.002,rot=(0,0,.05*(-1)**i))
def vase(x,y,z):
    c.lathe('Interpreted dark ceramic vase',(x,y,z),[(0,0),(.075,0),(.11,.035),(.12,.15),(.08,.22),(.035,.26),(.03,.26),(.032,.23)],'ceramic',48)
    for i in range(5):
        a=i*2.4;end=(x+math.cos(a)*.16,y+math.sin(a)*.13,z+.43+i*.02)
        c.rod('Styling olive stem',(x,y,z+.12),end,.0018,'bronze')
        for j in range(2):
            leaf=c.sphere('Styling olive leaf',(end[0]+j*.018,end[1],end[2]-j*.045),(.040,.013,.005),'leaf',12,6);leaf.rotation_euler=(.4,-.4,a)
vase(2.7,8.34,.54);books(3.3,8.0,.54)
books(8.7,8.25,.54);vase(9.35,8.25,.54)
vase(1.55,1.25,.81);books(2.4,1.25,.81);books(6.25,1.25,.82)
world=bpy.data.worlds.new('WELLINGTON soft ivory studio');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.62,.67,.72,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.45
c.set_parent(None)
c.light('Broad daylight key','AREA',(-3,1,9),2200,(1,.92,.80),target=(5,7,.5),size=8)
c.light('Large neutral fill','AREA',(14,3,9),2100,(.86,.93,1),target=(6,7,.7),size=7)
c.light('Soft rim reflection','AREA',(6,14,8),2600,(1,.94,.83),target=(6,7,.5),size=8)
sun=c.light('Warm directional daylight','SUN',(-4,-6,10),1.15,(1,.94,.84),target=(4,5,0));sun.data.angle=.18
cameras={
 'overview':((18,-14,14),(6,5.5,.55),44),
 'navy':((7.8,3.4,3.1),(3,9,.63),40),
 'burgundy':((13.5,3,3.5),(9,9,.63),40),
 'pair':((6.3,-2,2.6),(4.5,4.4,.5),44),
 'consoles':((6,-11.5,3.7),(6,1.4,1.25),40),
 'vitrine':((13.2,-3.4,2.25),(10.5,1.35,1.06),50),
 'media':((13.6,.7,1.8),(10.5,4.6,.4),60),
 'detail-lacquer':((4.2,7.2,.75),(3.55,8.0,.44),75),
 'detail-navy':((5,10.9,1.0),(4.17,9.9,.60),70),
 'detail-burgundy':((11.1,8.8,1.0),(10.22,9.6,.59),75),
}
for key,(loc,target,lens) in cameras.items():
    data=bpy.data.cameras.new('Lens '+key);obj=bpy.data.objects.new('Camera '+key,data);scene.collection.objects.link(obj);obj.location=loc;obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler();data.lens=lens;data.clip_start=.02;data.clip_end=180
    if key.startswith('detail'):
        data.dof.use_dof=True;data.dof.focus_distance=(Vector(target)-Vector(loc)).length;data.dof.aperture_fstop=5.6
scene.camera=bpy.data.objects['Camera navy'];scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=True
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.render.film_transparent=False;scene.render.image_settings.compression=25
info={'collection':'WELLINGTON','units':'metres','layout':'exhibition','walls':0,'roof':False,'floorBounds':[-1.5,-1,13,12],'rooms':zones,'placements':placements,'colliders':[],
      'overview':{'position':[18,14,14],'target':[6,.55,-5.5],'fov':45},'source':'CLASSIC_FURNITURE_CATALOG_2023.pdf','sourcePages':list(range(25,32)),'finish':'WE.L / DB (535/67), WE.W / DB (536/67)',
      'interpretations':['Open exhibition, mirror display supports and complementary styling','Unseen joinery and underside details','Procedural material calibration; material species not certified','Red two-seat proportions from dimensions and shared family image','Fixed cabinet/TV panels; no unverified opening hardware']}
scene['web_scene_info']=json.dumps(info);(BASE/'scene.json').write_text(json.dumps(info,indent=2),encoding='utf8')
def ancestor(obj):
    while obj:
        if obj.get('kind')=='product':return obj
        obj=obj.parent
    return None
product_cols={}
for obj in list(scene.objects):
    root=ancestor(obj)
    if not root:continue
    if root.name not in product_cols:
        col=bpy.data.collections.new(root['product_id']+' | '+root['instance_id']);scene.collection.children.link(col);product_cols[root.name]=col
    col=product_cols[root.name];col.objects.link(obj)
    for old in list(obj.users_collection):
        if old!=col:old.objects.unlink(obj)
# Retain the authored catalogue material library even where gilding covers
# the veneer in this particular display; a subsequent save must not purge it.
for mat in bpy.data.materials:mat.use_fake_user=True
for im in bpy.data.images:
    if im.source=='FILE':im.use_fake_user=True
bpy.ops.file.pack_all()
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.region_3d.view_camera_zoom=0;area.spaces.active.shading.type='MATERIAL'
report={'collection':'WELLINGTON','products':15,'placements':len(placements),'movingParts':0,'objects':len(scene.objects),'meshes':sum(o.type=='MESH' for o in scene.objects),'walls':0,'roof':False,'seconds':round(time.perf_counter()-started,2)}
(BASE/'build-report.json').write_text(json.dumps(report,indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'wellington-exhibition.blend'),compress=True)
print('WELLINGTON_BUILD_COMPLETE',json.dumps(report),flush=True)
