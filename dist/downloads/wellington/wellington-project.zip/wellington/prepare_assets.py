"""Package native Wellington models, actual renders and catalogue evidence."""
from pathlib import Path
import sys,json,shutil,hashlib,struct,zipfile
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'.local/catalogue-review/packages'))
import pymupdf as fitz
DIST=ROOT/'sites/rizky-atelier/dist';ASSET=DIST/'assets/collections/wellington';DOWN=DIST/'downloads/wellington'
ASSET.mkdir(parents=True,exist_ok=True);DOWN.mkdir(parents=True,exist_ok=True)
source=json.loads((BASE/'reference/products.json').read_text(encoding='utf8'));proof={};copies=[]
models=json.loads((ASSET/'products.json').read_text(encoding='utf8'))
for p in models:
    p['referenceNote']=next(x for x in source['products'] if x['sku']==p['sku']).get('reference_note','')
(ASSET/'products.json').write_text(json.dumps(models,indent=2),encoding='utf8')
def record(dst):
    raw=dst.read_bytes();copies.append({'destination':dst.relative_to(DIST).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);record(dst)
names=('overview','navy','burgundy','pair','consoles','vitrine','media','detail-lacquer','detail-navy','detail-burgundy')
for name in names:
    filename=name+('.png' if name.startswith('detail') else '-4k.png');src=BASE/'renders'/filename;raw=src.read_bytes();w,h=struct.unpack('>II',raw[16:24])
    assert (w,h)==((1600,1600) if name.startswith('detail') else (3840,2160))
    copy(src,DOWN/filename);pix=fitz.Pixmap(str(src))
    if w>1920:pix=fitz.Pixmap(pix,1920,round(h*1920/w))
    pix.save(str(ASSET/(name+'.jpg')),jpg_quality=93)
    proof[name]={'file':filename,'width':w,'height':h,'sha256':hashlib.sha256(raw).hexdigest(),'engine':'BLENDER_EEVEE','nativeScene':'wellington-exhibition.blend','originalBlenderRender':True}
for p in source['products']:
    src=BASE/'reference/catalogue'/(p['sku']+'.jpg');assert hashlib.sha256(src.read_bytes()).hexdigest()==p['image']['sha256'];copy(src,ASSET/'catalogue'/src.name)
copy(BASE/'wellington-exhibition.blend',DOWN/'wellington-exhibition.blend');copy(BASE/'native-audit.json',DOWN/'native-audit.json');copy(BASE/'reference/products.json',ASSET/'source-reference.json')
(DOWN/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8');record(DOWN/'render-proof.json')
doc=fitz.open(source['source_pdf']);subset=fitz.open();subset.insert_pdf(doc,from_page=24,to_page=30);subset.save(str(DOWN/'WELLINGTON-reference-pages.pdf'),garbage=4,deflate=True);subset.close();doc.close();record(DOWN/'WELLINGTON-reference-pages.pdf')
sources=('core.py','geometry.py','sofas.py','casegoods.py','build_scene.py','export_web.py','render_scene.py','validate_native.py','prepare_assets.py','scene.json','build-report.json','export-report.json','native-audit.json','README.md')
with zipfile.ZipFile(DOWN/'wellington-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for filename in sources:z.write(BASE/filename,'wellington/'+filename)
    for folder in ('textures','reference/catalogue','reference/originals'):
        for p in (BASE/folder).iterdir():z.write(p,'wellington/'+folder+'/'+p.name)
    for filename in ('scripts/read_catalogue.py','reference/catalogue-evidence.json','reference/products.json','wellington-exhibition.blend'):z.write(BASE/filename,'wellington/'+filename)
    z.write(DOWN/'WELLINGTON-reference-pages.pdf','wellington/WELLINGTON-reference-pages.pdf')
with zipfile.ZipFile(DOWN/'wellington-project.zip') as z:assert z.testzip() is None
record(DOWN/'wellington-project.zip')
for p in DOWN.iterdir():assert p.stat().st_size<95*1024*1024,('GitHub file too large',p)
prefix='assets/collections/wellington';url='https://rizky-make-it.github.io/rizky-atelier/'
def render(name,title,caption):return {'image':prefix+'/'+name+'.jpg','title':title,'caption':caption,'request':'the original WELLINGTON Blender render: '+title,'sourceUrl':url+'downloads/wellington/'+proof[name]['file']}
def file(title,ext,desc,request,p):return {'title':title,'extension':ext,'description':desc,'request':request,'sourceUrl':url+p}
collection={'id':'wellington','name':'WELLINGTON','number':'06','referenceYear':2023,'kind':'Catalogue collection','title':'Two colours. A classical conversation.','tagline':'Navy & burgundy. Piano lacquer. Fine gold.',
 'description':'Fifteen MARINER living-room references form an open exhibition in navy and burgundy. Distinct upholstered families meet crisp black-and-white lacquer, geometric medallions, gilded foliage and curved white stretchers. Six-leg round and four-leg square tables, two consoles and mirrors, a glazed cabinet and a media piece complete the collection. Concealed construction and calibrated materials remain visual interpretations.',
 'finish':'WE.L / DB (535/67), WE.W / DB (536/67)','hero':prefix+'/navy.jpg','exhibition':prefix+'/wellington-exhibition.glb','scene':prefix+'/scene.json','placementCount':20,'movingParts':0,'sourceSite':url+'#/collections/wellington','sourceRepo':'https://github.com/rizky-make-it/rizky-atelier','productCount':15,'palette':['#162d46','#792333','#eee7d8','#b48e44'],
 'renders':[render('overview','The Wellington exhibition','Actual wall-free Blender exhibition render, 3840 × 2160.'),render('navy','The navy salon','Navy velvet, hard medallion panels, white-frame armchairs and a six-leg round coffee table. Actual Blender render: 3840 × 2160.'),render('burgundy','The burgundy salon','A distinct upholstered family: deeply tufted outer sides and smooth rear panels. Actual Blender render: 3840 × 2160.'),render('pair','Two quieter conversations','Both dimensioned two-seat variants, with the burgundy proportions interpreted from the shared three-seat reference. Actual Blender render: 3840 × 2160.'),render('consoles','A gallery of lacquer','Both console widths, the crest and plain mirrors, and a glazed cabinet. Mirror stands are exhibition styling. Actual Blender render: 3840 × 2160.'),render('vitrine','The glazed cabinet','Three display levels, glazed sides and classical gilt detail. Actual Blender render: 3840 × 2160.'),render('media','The media piece','Open centre cubbies and fixed figured side panels. The source is a partly occluded lifestyle composition. Actual Blender render: 3840 × 2160.'),render('detail-lacquer','Lacquer, inlay & gold','Actual Blender detail render, 1600 × 1600. Black lacquer, not marble.'),render('detail-navy','The navy construction','Actual modelled upholstery and medallion detail, 1600 × 1600.'),render('detail-burgundy','Deep burgundy tufting','Actual geometric tufting and piped velvet, 1600 × 1600.')],
 'materials':[{'image':prefix+'/detail-lacquer.jpg','title':'Lacquer & gilded relief','description':'Polished black-and-white lacquer with physical laurel/inlay and cast-foliage geometry. A Blender render, not a physical material sample.'},{'image':prefix+'/detail-navy.jpg','title':'Navy & medallions','description':'Piped velvet, a rigid panel frame and sculpted medallions interpret the navy family. A native Blender render.'},{'image':prefix+'/detail-burgundy.jpg','title':'Burgundy tufting','description':'Physical diamond folds and recessed buttons form the red family outer side panels. A native Blender render.'}],
 'files':[file('Native Wellington exhibition','.BLEND','Fifteen SKUs, twenty placements, packed PBR maps and ten cameras.','the WELLINGTON editable Blender exhibition master (.blend)','downloads/wellington/wellington-exhibition.blend'),file('Exhibition & individual models','.GLB','Fifteen full-detail products and an optimised wall-free exhibition.','the complete WELLINGTON exhibition GLB and fifteen individual product GLBs',prefix+'/wellington-exhibition.glb'),file('Complete rebuild project','.ZIP','Editable scene, geometry scripts, textures, raw reference evidence and native audit.','the complete WELLINGTON Blender project, textures and rebuild sources','downloads/wellington/wellington-project.zip'),file('Wellington living-room references','.PDF','Seven supplied MARINER reference spreads; PDF pages 25–31.','the original WELLINGTON living-room catalogue reference pages','downloads/wellington/WELLINGTON-reference-pages.pdf'),file('Original 4K renders','4K PNG','Seven genuine 4K Blender renders and three 1600-pixel details.','all WELLINGTON original 4K Blender renders and detail images','downloads/wellington/render-proof.json')]}
(ASSET/'collection.json').write_text(json.dumps(collection,indent=2),encoding='utf8');(BASE/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8')
(ASSET/'asset-audit.json').write_text(json.dumps({'collection':'WELLINGTON','sourcePDFSHA256':source['source_pdf_sha256'],'files':copies,'renderProof':proof},indent=2),encoding='utf8')
print('WELLINGTON_PACKAGED',json.dumps({'renders':len(proof),'nativeBytes':(DOWN/'wellington-exhibition.blend').stat().st_size,'zipBytes':(DOWN/'wellington-project.zip').stat().st_size}),flush=True)
