"""Preserve original WELLINGTON evidence from the supplied MARINER catalogue."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / '.local/catalogue-review/packages'))
import pymupdf as fitz

SOURCE = Path('C:/Users/Admin/Downloads/CLASSIC_FURNITURE_CATALOG_2023.pdf')
DEST = ROOT / 'output/wellington/reference'
DEST.mkdir(parents=True, exist_ok=True)
ORIGINALS = DEST / 'originals'
ORIGINALS.mkdir(exist_ok=True)
doc = fitz.open(SOURCE)
pages = []
for index in range(24,31):
    page = doc[index]
    scale = 2200/page.rect.width
    image_path = DEST/f'page-{index+1:03}.jpg'
    page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False).save(image_path,jpg_quality=96)
    for image in page.get_image_info(xrefs=True):
        if image.get('xref'):
            original = doc.extract_image(image['xref'])
            (ORIGINALS/f'page-{index+1:03}-xref-{image["xref"]}.{original["ext"]}').write_bytes(original['image'])
    pages.append({'pdf_page':index+1,'rect_pdf_points':list(page.rect),
                  'text':page.get_text(sort=True),'text_blocks':page.get_text('blocks'),
                  'images':page.get_image_info(xrefs=True),'preview':image_path.name})
    print(f'PAGE {index+1}\n{page.get_text(sort=True)}',flush=True)
report = {'source':str(SOURCE),'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'page_count':len(doc),'metadata':doc.metadata,
          'image_classification':'Original catalogue image; not independently verified product photography',
          'pages':pages}
(DEST/'catalogue-evidence.json').write_text(json.dumps(report,indent=2,
    default=lambda value:value.hex() if isinstance(value,bytes) else str(value)),encoding='utf8')
print('PREVIEWS_READY',DEST,flush=True)

PRODUCTS = DEST/'catalogue'
DETAILS = DEST/'details'
PRODUCTS.mkdir(exist_ok=True)
DETAILS.mkdir(exist_ok=True)

def source_rect(pdf_page,xref,rect_pixels):
    info = next(image for image in doc[pdf_page-1].get_image_info(xrefs=True) if image['xref']==xref)
    x0,y0,x1,y1 = rect_pixels
    matrix = fitz.Matrix(info['transform'])
    corners = [fitz.Point(x/info['width'],y/info['height'])*matrix for x,y in [(x0,y0),(x1,y0),(x0,y1),(x1,y1)]]
    return [min(point.x for point in corners),min(point.y for point in corners),
            max(point.x for point in corners),max(point.y for point in corners)]

def image_orientation(pdf_page,xref):
    info = next(image for image in doc[pdf_page-1].get_image_info(xrefs=True) if image['xref']==xref)
    transform = info['transform']
    mirrored = transform[0] < 0 and transform[3] > 0
    return {'source_image_to_pdf_transform':list(transform),'source_pdf_horizontal_mirror':mirrored,
            'orientation_note':'Original embedded image orientation retained; the source PDF displays this image horizontally mirrored.' if mirrored else 'Original embedded image orientation matches the source PDF display.'}

def extract_original(pdf_page,xref,destination):
    original = doc.extract_image(xref)
    source_path = ORIGINALS/f'page-{pdf_page:03}-xref-{xref}.{original["ext"]}'
    source_path.write_bytes(original['image'])
    smask = next((image[1] for image in doc[pdf_page-1].get_images(full=True) if image[0]==xref),0)
    evidence = {'source_pdf_page':pdf_page,'source_image_xref':xref,
                'source_native_pixels':[original['width'],original['height']],
                'crop_rect_native_pixels':[0,0,original['width'],original['height']],
                'crop_rect_pdf_points':source_rect(pdf_page,xref,[0,0,original['width'],original['height']]),
                'output_pixels':[original['width'],original['height']],
                'source_image_file':source_path.relative_to(DEST).as_posix(),
                'source_image_sha256':hashlib.sha256(original['image']).hexdigest(),
                'file':destination.relative_to(DEST).as_posix()}
    if smask:
        mask = doc.extract_image(smask)
        mask_path = ORIGINALS/f'page-{pdf_page:03}-mask-{smask}.{mask["ext"]}'
        mask_path.write_bytes(mask['image'])
        composite = fitz.open()
        page = composite.new_page(width=original['width'],height=original['height'])
        page.insert_image(page.rect,stream=original['image'],mask=mask['image'])
        page.get_pixmap(alpha=False).save(destination,jpg_quality=96)
        composite.close()
        evidence.update({'source_soft_mask_xref':smask,
                         'source_soft_mask_file':mask_path.relative_to(DEST).as_posix(),
                         'source_soft_mask_sha256':hashlib.sha256(mask['image']).hexdigest(),
                         'transformation':'Original embedded JPEG and its original PDF soft mask composited on the original white page background at native pixel density; no new background removal, upscaling or subject alteration'})
    else:
        destination.write_bytes(original['image'])
        evidence['transformation'] = 'Exact original embedded JPEG bytes, no resizing or visual modification'
    evidence.update(image_orientation(pdf_page,xref))
    evidence['sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
    return evidence

def crop_original(pdf_page,xref,rect_pixels,destination):
    original = doc.extract_image(xref)
    source_path = ORIGINALS/f'page-{pdf_page:03}-xref-{xref}.{original["ext"]}'
    source_path.write_bytes(original['image'])
    image_doc = fitz.open(stream=original['image'],filetype=original['ext'])
    page = image_doc[0]
    scale = original['width']/page.rect.width
    pixmap = page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=fitz.Rect(rect_pixels)/scale,alpha=False)
    pixmap.save(destination,jpg_quality=96)
    evidence = {'source_pdf_page':pdf_page,'source_image_xref':xref,
                'source_native_pixels':[original['width'],original['height']],
                'crop_rect_native_pixels':rect_pixels,'crop_rect_pdf_points':source_rect(pdf_page,xref,rect_pixels),
                'output_pixels':[pixmap.width,pixmap.height],
                'source_image_file':source_path.relative_to(DEST).as_posix(),
                'source_image_sha256':hashlib.sha256(original['image']).hexdigest(),
                'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),
                'transformation':'Rectangular crop of original embedded catalogue image at native pixel density; no upscaling or subject alteration',
                'file':destination.relative_to(DEST).as_posix()}
    evidence.update(image_orientation(pdf_page,xref))
    image_doc.close()
    return evidence

BLUE = ['Deep midnight-blue velvet upholstery and plump piped seat/back cushions',
        'Rigid squared U-shaped white front fascia framed in high-gloss black lacquer and narrow gold bead trim',
        'Gold hanging ornament on each front arm upright and round central gold apron medallion',
        'Decorative hard side panels with large circular black-and-gold medallions',
        'Diamond-button-tufted blue outer rear upholstery',
        'Short decorated gold feet and small gold finials above front arm corners']
RED = ['Wine-red velvet upholstery with piped seat and loose back cushions',
       'Diamond-button-tufted outer side upholstery without large hard side medallions',
       'Smooth wine-red fabric rear panel rather than a tufted rear',
       'Squared white U-shaped front fascia bounded by glossy black lacquer and slim gold trim',
       'Gold hanging ornaments on the front arm uprights and short decorated gold feet']
TABLE = ['High-gloss black top with double pale inlaid perimeter lines and a pale central laurel-wreath motif',
         'Antique-gold foliate apron edged by narrow pale bands',
         'Tapered black legs with decorated gold capitals, middle sleeves and toes',
         'Curved pale lower stretchers with black edging; open spans, not a solid lower shelf']
definitions = [
    {'sku':'50292.0','name':'Wellington Blue Three-seat Sofa','type':'Sofa','dimensions_mm':[2500,950,950],
     'weight_kg':110,'source_pdf_page':26,'xref':131,'finish':'WE.L / DB (535 /67)',
     'fabric_codes':['243.030','241.201'],'fabric_statement':'Suggested Fabric: 243.030 / 241.201',
     'visible_details':BLUE+['Three individual seat cushions and three loose back cushions',
                            'Blue and patterned dark accent pillows including two round cushions'],
     'reference_note':'Rear tufting and external hard side-panel details are evidenced by the adjacent original lifestyle detail and page25 room image; hidden construction remains interpretative.'},
    {'sku':'50293.0','name':'Wellington Blue Two-seat Sofa','type':'Sofa','dimensions_mm':[1800,950,950],
     'weight_kg':100,'source_pdf_page':26,'xref':129,'finish':'WE.L / DB (535 /67)',
     'fabric_codes':['243.030','241.201'],'fabric_statement':'Suggested Fabric: 243.030 / 241.201',
     'visible_details':BLUE+['Two individual seat cushions and two loose back cushions',
                            'Blue and patterned dark accent pillows including a central round cushion']},
    {'sku':'50294.2','name':'Wellington White-frame Blue Armchair','type':'Armchair','dimensions_mm':[1060,950,950],
     'weight_kg':60,'source_pdf_page':27,'xref':135,'finish':'WE.W. /DB (536 /67)',
     'fabric_codes':['243.030'],'fabric_statement':'Fabric: 243.030',
     'visible_details':['Deep blue velvet seat, one loose back cushion and a dark accent pillow',
                        'White outer frame surrounding dark brown patterned hard side panels',
                        'Large gold-rimmed circular medallion on each external hard side panel',
                        'Diamond-button-tufted blue rear panel shown in separate rear image',
                        'Narrow gold trim, gold front-upright hanging ornaments and small top finials',
                        'Four short decorated gold feet'],
     'reference_note':'The printed WE.W finish has a white outer frame, unlike the black outer outline of the blue two/three-seat references. Dark brown patterned surfaces are visually evident but their substrate and exact material are not specified.'},
    {'sku':'50490.0','name':'Wellington Red Three-seat Sofa','type':'Sofa','dimensions_mm':[2500,950,950],
     'weight_kg':80,'source_pdf_page':28,'xref':142,'finish':'WE.L / DB (535 /67)',
     'fabric_codes':['243.066','241.188','241.182'],'fabric_statement':'Fabric: 243.066 / 241.188 / 241.182',
     'visible_details':RED+['Three individual seat cushions and three back cushions',
                           'Burgundy and pale accent pillows and a front-centre round gold medallion'],
     'imageShared':True,'imageSharedWith':['50491.0'],
     'reference_note':'The original three-seat product image is also used as a shared family reference for the separately dimensioned two-seat 50491.0; it must not be presented as an isolated two-seat catalogue photograph. Source rear view clearly shows a smooth fabric rear panel.'},
    {'sku':'50491.0','name':'Wellington Red Two-seat Sofa','type':'Sofa','dimensions_mm':[1800,950,950],
     'weight_kg':75,'source_pdf_page':28,'xref':142,'finish':'WE.L / DB (535 /67)',
     'fabric_codes':['243.066','241.188','241.182'],'fabric_statement':'Fabric: 243.066 / 241.188 / 241.182',
     'visible_details':RED+['Two-seat proportions follow the explicitly printed width; no isolated two-seat source view is supplied'],
     'imageShared':True,'imageSharedWith':['50490.0'],
     'reference_note':'SHARED FAMILY IMAGE: the catalogue provides dimensions and SKU for this two-seat sofa but no separate isolated two-seat image. This is the original three-seat 50490.0 image from the same family, not a true image of 50491.0; the reconstructed two-seat cushion count/proportions are dimension-led interpretations.'},
    {'sku':'50492.0','name':'Wellington Red Armchair','type':'Armchair','dimensions_mm':[1060,950,950],
     'weight_kg':50,'source_pdf_page':28,'xref':143,'crop':[20,490,790,1120],
     'finish':'WE.L / DB (535 /67)','fabric_codes':['243.066','241.181'],
     'fabric_statement':'Fabric: 243.066 / 241.181',
     'visible_details':RED+['One plump seat cushion and one broad loose back cushion',
                           'No gold finials above the front arm corners in this reference'],
     'reference_note':'Native-density crop of the original dark-backdrop product composition; no isolated white-background source view was created.'},
    {'sku':'50280.0','name':'Wellington Crest Mirror','type':'Mirror','dimensions_mm':[1120,70,1650],
     'weight_kg':42,'source_pdf_page':29,'xref':147,'crop':[160,70,600,695],
     'finish':'WE.L / DB (535 /67)',
     'visible_details':['Tall rectangular mirror surrounded by a broad pale lacquer frame',
                        'Glossy black corner blocks with small gold floral ornaments',
                        'Narrow antique-gold inner and outer frame molding',
                        'Large circular black crest with concentric gold medallion above the top edge',
                        'Small horizontal gold flourishes beside the top crest'],
     'reference_note':'Original lifestyle crop of the mirror; lamps, decorative objects and reflections remain and partly obscure the lower frame. The associated console is 50279.0. Exact rear mounting is not visible.'},
    {'sku':'50278.0','name':'Wellington Round Pedestal Side Table','type':'Side table','dimensions_mm':[650,650,700],
     'diameter_mm':650,'weight_kg':17,'source_pdf_page':29,'xref':149,'finish':'WE.L / DB (535 /67)',
     'visible_details':['Round high-gloss black top with double pale ring inlay and central pale laurel wreath',
                        'Pale top fascia with a narrow gold lower edge',
                        'Single glossy black flared pedestal with a decorated gold middle collar',
                        'Pale concave-sided base outlined in black and four small gold feet'],
     'reference_note':'The catalogue gives diameter and height. No marble is stated for these black lacquer tabletops.'},
    {'sku':'50279.0','name':'Wellington Wide Curved Console','type':'Console','dimensions_mm':[1700,500,810],
     'weight_kg':36,'source_pdf_page':29,'xref':147,'crop':[65,700,760,1060],
     'finish':'WE.L / DB (535 /67)',
     'visible_details':['Wide black lacquer top with softly rounded outer ends and pale perimeter inlay',
                        'Carved antique-gold apron with dark square blocks above front legs',
                        'Four tapered black legs with gold upper collars and tall gold foot sleeves',
                        'Low pale curved stretcher outlined in black with a small central finial',
                        'No full lower shelf or documented drawer'],
     'reference_note':'Original lifestyle crop; the associated crest mirror is 50280.0. Lamps and decorative objects remain. Hidden structural joints are unverified.'},
    {'sku':'50295.0','name':'Wellington Square Coffee Table','type':'Coffee table','dimensions_mm':[1300,1300,510],
     'weight_kg':55,'source_pdf_page':29,'xref':151,'finish':'WE.L / DB (535 /67)',
     'visible_details':TABLE+['Square top with softly clipped corners',
                             'Four legs and four inward-curved stretcher links']},
    {'sku':'50296.0','name':'Wellington Round Coffee Table','type':'Coffee table','dimensions_mm':[1350,1350,510],
     'diameter_mm':1350,'weight_kg':57,'source_pdf_page':29,'xref':153,'finish':'WE.L / DB (535 /67)',
     'visible_details':TABLE+['Round top and circular apron punctuated by dark square leg blocks',
                             'Multiple curved pale stretcher links forming an open symmetrical base'],
     'reference_note':'The catalogue gives diameter and height. Visible leg/stretcher placements guide reconstruction; precise hidden joinery is unverified.'},
    {'sku':'50297.0','name':'Wellington Glass Display Cabinet','type':'Cabinet','dimensions_mm':[1150,500,2120],
     'weight_kg':87,'source_pdf_page':30,'xref':159,'finish':'WE.L / DB (535 /67)',
     'visible_details':['Tall white lacquer glass vitrine with broad black-edged upper cornice',
                        'Carved antique-gold upper and lower apron panels and dark square corner blocks',
                        'Large glazed front with small gold handle and glazed side panels',
                        'Gold hanging ornaments on the front uprights',
                        'Two clearly visible glass shelves forming three display levels',
                        'Four tapered black legs with long gold sleeves and pale open curved stretcher base',
                        'Small central gold urn-like finial on the lower stretcher'],
     'reference_note':'Source shows glazed front and a small handle but does not verify hinges, opening range or construction. Any animated opening would be a conceptual mechanism, not manufacturer CAD. Glassware is styling, not additional catalogue product SKUs.'},
    {'sku':'50302.0','name':'Wellington Rectangular Mirror','type':'Mirror','dimensions_mm':[1100,50,1250],
     'weight_kg':33,'source_pdf_page':30,'xref':157,'crop':[175,145,590,625],
     'finish':'WE.L / DB (535 /67)',
     'visible_details':['Simple tall rectangular mirrored centre without a raised circular top crest',
                        'Broad pale lacquer frame with glossy black corner squares',
                        'Small gold corner ornaments and narrow gold inner/outer frame molding'],
     'reference_note':'Original lifestyle crop of mirror50302.0, paired with compact console50357.0. Lamps and vase partly obscure the lower frame and remain in the reference. Exact rear mounting is not shown.'},
    {'sku':'50357.0','name':'Wellington Compact Console','type':'Console','dimensions_mm':[1090,470,820],
     'weight_kg':27,'source_pdf_page':30,'xref':157,'crop':[185,685,665,1060],
     'finish':'WE.L / DB (535 /67)',
     'visible_details':['Straight compact rectangular black lacquer top with pale edge trim',
                        'Antique-gold foliate apron with black square leg blocks',
                        'Four tapered black legs with decorated gold upper collars and long gold foot sleeves',
                        'Open curved pale stretcher base outlined in black and a central small gold finial',
                        'No full lower shelf or documented opening panel'],
     'reference_note':'Original lifestyle crop paired with mirror50302.0; lamps and decorative objects remain. The compact console top is straight-sided rather than the visibly rounded ends of wide console50279.0.'},
    {'sku':'50298.2','name':'Wellington White-frame TV Cabinet','type':'TV furniture','dimensions_mm':[2200,500,800],
     'weight_kg':108,'source_pdf_page':31,'xref':163,'crop':[640,525,1315,855],
     'finish':'WE.W / DB (536 /67)',
     'visible_details':['Long dark top with pale edge molding and continuous carved gold upper apron',
                        'White frame and front uprights with gold hanging ornaments',
                        'Two dark brown patterned outer front panels with concentric gold medallions',
                        'Open pale centre bay with one pale shelf forming two storage levels',
                        'Black lower plinth with gold edging and short decorated gold feet'],
     'reference_note':'Native-density crop from the only supplied TV lifestyle image, retaining the embedded image orientation. The source PDF horizontally mirrors that embedded image. One outer cabinet edge is clipped by the original composition and a foreground table partly overlaps the lower cabinet. No isolated full-front source view exists here. Outer panel opening mechanics are not verified.'},
]
for product in definitions:
    destination = PRODUCTS/f'{product["sku"]}.jpg'
    evidence = crop_original(product['source_pdf_page'],product['xref'],product['crop'],destination) if product.get('crop') else extract_original(product['source_pdf_page'],product['xref'],destination)
    product.update({'collection':'WELLINGTON','catalogue_brand':'MARINER',
                    'sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023','sourceBrand':'MARINER',
                    'sourcePage':product['source_pdf_page'],'imageShared':product.get('imageShared',False),
                    'materials':['High-gloss black piano and white lacquer','Polished brass and cast bronze ornaments','Carvings decorated with antique gold leaf']+(['Velvet upholstery; printed fabric codes recorded separately'] if product['type'] in ['Sofa','Armchair'] else []),
                    'dimensions_order':'width, depth, height',
                    'source_printed_pages':f'{(product["source_pdf_page"]-1)*2}-{(product["source_pdf_page"]-1)*2+1}',
                    'image_classification':'Original catalogue image, not independently verified product photography',
                    'image':evidence})
    product.pop('xref',None)
    product.pop('crop',None)

supporting_images = [
    extract_original(25,124,DEST/'room-living.jpg'),
    extract_original(26,127,DEST/'original-blue-sofa-back.jpg'),
    extract_original(27,136,DEST/'original-white-armchair-rear.jpg'),
    extract_original(27,137,DEST/'original-blue-front-detail.jpg'),
    extract_original(28,141,DEST/'original-red-sofa-rear.jpg'),
    extract_original(28,143,DEST/'original-red-armchair-full.jpg'),
    extract_original(29,147,DEST/'original-wide-console-and-mirror.jpg'),
    extract_original(30,157,DEST/'original-compact-console-and-mirror.jpg'),
    extract_original(31,163,DEST/'original-tv-lifestyle.jpg'),
    crop_original(26,127,[0,220,800,1010],DETAILS/'original-blue-tufting.jpg'),
    crop_original(28,143,[425,620,790,1035],DETAILS/'original-red-arm-tufting.jpg'),
    crop_original(29,147,[160,90,590,300],DETAILS/'original-mirror-crest.jpg'),
    crop_original(31,163,[640,560,1315,770],DETAILS/'original-tv-medallions.jpg'),
]
manifest = {'collection':'WELLINGTON','catalogue_brand':'MARINER','catalogue_title':SOURCE.name,
            'sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023','sourceBrand':'MARINER',
            'source_pdf':str(SOURCE),'source_pdf_sha256':report['source_sha256'],
            'source_pdf_page_count':len(doc),'source_pdf_pages':list(range(25,32)),
            'dimensions_unit':'millimetres','dimensions_order':'width, depth, height',
            'source_material_statement':'HIGH GLOSS BLACK PIANO AND WHITE LACQUER WITH POLISHED BRASS CASTED BRONZE ORNAMENTS & CARVINGS DECORATED WITH ANTIQUE GOLD LEAF.',
            'source_variant_note':'Blue50292.0/50293.0 and red50490.0/50491.0/50492.0 are distinct upholstery/frame-detail families, not mere material colour variants. White-frame armchair50294.2 and white-frame TV50298.2 use printed WE.W finish references. Red two-seat50491.0 has printed dimensions but no separate image; the unaltered three-seat family image is shared and explicitly disclosed.',
            'scope_note':'Only WELLINGTON living-room pages25-31 (printed48-61) are in scope; page32 begins NANTES. Mirrors and consoles are individually dimensioned products despite sharing lifestyle compositions. Styling items and televisions are not additional catalogue product SKUs.',
            'provenance_note':'Images are exact original embedded JPEGs, documented native-density rectangular crops, or faithful native-density composites of original JPEGs with their original PDF soft masks over the original white page background. Raw source and mask bytes and hashes are retained. No AI replacement, super-resolution, new subject segmentation, synthesized missing product photo or subject alteration was performed.',
            'reconstruction_caveat':'Only printed dimensions and visibly documented surfaces are evidenced. Hidden joinery, exact material substrate, fabric weave, finish calibration and opening mechanisms are unverified interpretations. Source images alone do not establish whether imagery is photographed or rendered. Shared-family and lifestyle-crop limitations are disclosed per product.',
            'rights_note':'User-supplied MARINER catalogue; original product designs and imagery remain the rights of their owners. This evidence extraction conveys no commercial reuse licence or manufacturer endorsement.',
            'products':definitions,'supporting_images':supporting_images}
assert len(definitions)==15 and len({product['sku'] for product in definitions})==15
(DEST/'products.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
print('PRODUCT_REFERENCES_READY',len(definitions),DEST/'products.json',flush=True)
doc.close()
