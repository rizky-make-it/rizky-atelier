"""Genuine Blender renders: -- [all|camera] [--preview] [--cycles]."""
import bpy,sys,time,json
from pathlib import Path
BASE=Path(__file__).resolve().parent;args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['all']
name=args[0] if args else 'all';preview='--preview' in args;scene=bpy.context.scene
assert scene.get('collection')=='WELLINGTON'
scene.timeline_markers.clear();scene.render.engine='CYCLES' if '--cycles' in args else 'BLENDER_EEVEE'
scene.cycles.samples=24 if preview else 96;scene.eevee.taa_render_samples=16 if preview else 64
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=25 if preview else 100
scene.eevee.use_raytracing=True
out=BASE/'renders';out.mkdir(exist_ok=True)
for key in (['overview','navy','burgundy','pair','consoles','vitrine','media','detail-lacquer','detail-navy','detail-burgundy'] if name=='all' else [name]):
    started=time.perf_counter();scene.camera=bpy.data.objects['Camera '+key]
    hidden=[]
    if key in ('vitrine','media','pair','navy','burgundy'):
        # Dedicated studio view: do not let the coffee-table styling obscure
        # the TV reference-facing side. Product geometry is never altered.
        for obj in scene.objects:
            if obj.type not in {'MESH','CURVE','FONT'}:continue
            ancestor=obj
            while ancestor and ancestor.get('kind')!='product':ancestor=ancestor.parent
            keep=ancestor and (ancestor.get('room')==key if key in ('pair','navy','burgundy') else ancestor.get('product_id')==('50297.0' if key=='vitrine' else '50298.2'))
            if not keep and not obj.name.startswith('Continuous pale stone floor'):
                hidden.append((obj,obj.hide_render));obj.hide_render=True
    scene.render.resolution_x=1600 if key.startswith('detail') else 3840
    scene.render.resolution_y=1600 if key.startswith('detail') else 2160
    filename=key+('-preview.png' if preview else '.png' if key.startswith('detail') else '-4k.png')
    scene.render.filepath=str(out/filename);bpy.ops.render.render(write_still=True)
    report={'camera':key,'collection':'WELLINGTON','engine':scene.render.engine,'samples':scene.eevee.taa_render_samples,'width':round(scene.render.resolution_x*scene.render.resolution_percentage/100),'height':round(scene.render.resolution_y*scene.render.resolution_percentage/100),'seconds':round(time.perf_counter()-started,2),'walls':0,'roof':False,'originalBlenderRender':True}
    (out/(key+('-preview' if preview else '')+'-settings.json')).write_text(json.dumps(report,indent=2))
    for obj,state in hidden:obj.hide_render=state
    print('WELLINGTON_RENDER_COMPLETE',json.dumps(report),flush=True)
