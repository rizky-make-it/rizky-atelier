"""Wellington geometry bridge and authored PBR materials. All dimensions in metres.

The copied geometry.py is the project's existing geometric utility. Materials
below are procedural visual interpretations, not measured manufacturer samples.
"""
import math
from pathlib import Path
import numpy as np
import bpy
import geometry as g

BASE=Path(__file__).resolve().parent
g.BASE=BASE
M=g.M
for _name in ('set_parent','link','empty','mesh','box','sphere','lathe','cylinder','rod','curve','material','image_map','generated','light'):
    globals()[_name]=getattr(g,_name)
def __getattr__(name):
    if name=='PARENT':return g.PARENT
    raise AttributeError(name)

def field(x,y,seed=0):
    rng=np.random.default_rng(seed);value=np.zeros_like(x)
    for i in range(7):
        a,b,phase=rng.uniform(.6,2.8),rng.uniform(.6,2.8),rng.uniform(0,math.tau)
        value+=np.sin((x*a+y*b)*2**i+phase)*np.cos((x*b-y*a)*2**i-phase)/2**(i*.85)
    return value

def texture(name,rgb,noncolor=False):
    alpha=np.ones((*rgb.shape[:2],1),dtype=np.float32)
    return generated(name,np.concatenate((rgb,alpha),axis=2),noncolor)

def materials():
    (BASE/'textures').mkdir(exist_ok=True)
    n=1536;y,x=np.mgrid[0:n,0:n].astype(np.float32)/n
    # Layered, domain-warped burl eyes and bookmatched figuring; never a photo
    # of another product or a claim of calibrated NO/OA material reproduction.
    u=np.abs(x-.5)*6;v=y*6
    warp=field(u*.9,v*.9,32)
    wx=u+.30*field(u,v,7);wy=v+.28*field(v,u,81)
    grain=np.sin(wx*24+wy*4+warp*5)
    eyes=np.zeros_like(x)
    for cx,cy in [(.35,1.0),(1.3,3.8),(2.2,1.7),(.5,5.3),(2.5,5.2)]:
        radius=np.sqrt((wx-cx)**2+(wy-cy)**2*.7)
        eyes+=np.sin(radius*33+warp*1.6)*np.exp(-radius*radius*.55)
    value=np.clip(.46+.11*warp+.10*grain+.13*eyes+.035*field(u*9,v*9,4),0,1)
    dark=np.array([.036,.012,.005]);light=np.array([.42,.17,.060])
    burl=dark+(light-dark)*value[...,None]**1.25
    wood_path=texture('wellington_figured_timber',burl)
    weave=(np.sin(x*math.tau*210)*np.cos(y*math.tau*209))
    fabric=np.stack([.018+weave*.002,.047+weave*.005,.09+weave*.008],axis=2)
    fabric+=field(x*80,y*80,6)[...,None]*.005
    cloth_path=texture('wellington_navy_velvet',fabric)
    burgundy=np.stack([.095+weave*.004,.007+weave*.001,.016+weave*.002],axis=2)
    burgundy+=field(x*70,y*70,18)[...,None]*.003
    red_path=texture('wellington_burgundy_velvet',np.clip(burgundy,.002,1))
    dx=np.cos(x*math.tau*210)*np.sin(y*math.tau*209)*.13
    dy=np.sin(x*math.tau*210)*np.cos(y*math.tau*209)*.13
    normal_path=texture('wellington_thread_normal',np.stack([.5-dx,.5-dy,np.ones_like(x)],axis=2),True)
    damask=.5+.20*np.sin(x*math.tau*8)*np.cos(y*math.tau*8)+.13*np.cos((x+y)*math.tau*16)
    damask_path=texture('wellington_damask',np.stack([.018+damask*.015,.019+damask*.019,.027+damask*.023],axis=2))
    palette={
      'wood':((.13,.045,.014),.18,0),'wood_dark':((.019,.012,.009),.19,0),
      'inside':((.10,.038,.015),.32,0),
      'bronze':((.48,.29,.09),.29,.85),'gold':((.64,.43,.15),.21,.86),
      'cloth':((.018,.047,.09),.64,0),'cloth_light':((.035,.08,.14),.68,0),
      'cloth_gold':((.53,.39,.20),.72,0),'cloth_dark':((.009,.016,.03),.68,0),
      'burgundy':((.095,.007,.016),.64,0),'red_light':((.16,.012,.025),.68,0),
      'white':((.81,.79,.72),.18,0),'ivory':((.74,.71,.63),.80,0),
      'damask':((.025,.028,.04),.77,0),'mirror':((.92,.94,.95),.035,1),
      'brass':((.59,.39,.11),.28,.87),
      'piano':((.006,.005,.004),.12,0),'antique_gold':((.54,.34,.09),.30,.8),
      'stitch':((.25,.21,.16),.88,0),'black':((.009,.010,.010),.23,.08),
      'stone':((.72,.69,.61),.48,0),'plinth':((.73,.69,.58),.65,0),
      'rug':((.43,.37,.27),.97,0),'paper':((.80,.76,.64),.82,0),
      'ceramic':((.12,.16,.14),.28,.12),'leaf':((.07,.12,.045),.68,0),
      'glass':((.91,.94,.91),.08,0),'light':((1,.80,.43),.3,0),
    }
    for key,(color,r,m) in palette.items():M[key]=material('WELLINGTON | '+key,color,r,m)
    for key in ('wood','inside'):
        image_map(M[key],wood_path,'Base Color')
        M[key]['source']='Authored dark figured-timber appearance; species not declared in source'
    image_map(M['burgundy'],red_path,'Base Color');image_map(M['damask'],damask_path,'Base Color')
    for key in ('cloth','cloth_light','cloth_gold','cloth_dark','burgundy','red_light','damask','ivory','rug'):
        if key=='cloth':image_map(M[key],cloth_path,'Base Color')
        image_map(M[key],normal_path,'Normal',True,.45)
        bs=M[key].node_tree.nodes['Principled BSDF'];bs.inputs['Sheen Weight'].default_value=.22
        # White sheen overwhelms dark velvet under the broad studio key.
        # Fibre highlights retain the actual pigment family instead.
        tint=(.10,.22,.38) if key in ('cloth','cloth_light','cloth_dark') else (.36,.035,.07) if key in ('burgundy','red_light') else palette[key][0]
        bs.inputs['Sheen Tint'].default_value=(*tint,1)
    for key in ('wood','wood_dark','white','piano','black'):
        bs=M[key].node_tree.nodes['Principled BSDF'];bs.inputs['Coat Weight'].default_value=.5
        bs.inputs['Coat Roughness'].default_value=.12
    for key in ('bronze','gold','antique_gold'):
        nodes=M[key].node_tree.nodes;links=M[key].node_tree.links
        noise=nodes.new('ShaderNodeTexNoise');noise.inputs['Scale'].default_value=240
        bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.16;bump.inputs['Distance'].default_value=.00015
        links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],nodes['Principled BSDF'].inputs['Normal'])
    # Thin-sheet real-time glass: deterministic transparency keeps the actual
    # interior/shelves legible in EEVEE and the browser, without frosted SSR.
    bs=M['glass'].node_tree.nodes['Principled BSDF'];bs.inputs['Transmission Weight'].default_value=.15;bs.inputs['IOR'].default_value=1.46
    bs.inputs['Alpha'].default_value=.17;bs.inputs['Roughness'].default_value=.035
    M['glass'].surface_render_method='BLENDED';M['glass'].use_raytrace_refraction=False
    M['glass']['source']='Thin-sheet real-time transparency approximation; not a calibrated optical glass sample'
    bs=M['light'].node_tree.nodes['Principled BSDF'];bs.inputs['Emission Color'].default_value=(1,.78,.4,1);bs.inputs['Emission Strength'].default_value=3
    return M
