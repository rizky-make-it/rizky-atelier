"""WELLINGTON casegoods: Mariner 2023 catalogue PDF pages 29–31.

Independent metric visual reconstruction, not official CAD. Black lacquer,
white inlay, gilded foliate aprons and bowed white stretchers follow the
visible photographs. No marble is used. Cabinet and TV fronts are fixed:
the source does not verify an opening mechanism. The partly occluded TV
lifestyle image cannot establish hidden joinery or unseen panel details.

API: create(sku, instance='main'), X width, Y depth/front -Y, Z up, floor-
centred origin (mirror origin = bottom centre, ready to hang above console).
All ornaments and inlays are real meshes; no photo planes or curve bounds.
"""
import math
from contextlib import contextmanager
from mathutils import Vector
import core as c

TAU = math.tau
SPECS = {
    '50278.0': ('Wellington pedestal side table', (650, 650, 700)),
    '50295.0': ('Wellington square coffee table', (1300, 1300, 510)),
    '50296.0': ('Wellington round six-leg coffee table', (1350, 1350, 510)),
    '50279.0': ('Wellington curved-front console', (1700, 500, 810)),
    '50357.0': ('Wellington compact console', (1090, 470, 820)),
    '50280.0': ('Wellington crested mirror', (1120, 70, 1650)),
    '50302.0': ('Wellington plain rectangular mirror', (1100, 50, 1250)),
    '50297.0': ('Wellington glazed display cabinet', (1150, 500, 2120)),
    '50298.2': ('Wellington figured-timber TV furniture', (2200, 500, 800)),
}


@contextmanager
def parent_to(ob):
    previous = c.PARENT
    c.set_parent(ob)
    try:
        yield
    finally:
        c.set_parent(previous)


def bezier(a, b, d, e, steps=20):
    return [tuple((1-t)**3*a[k]+3*(1-t)**2*t*b[k]+3*(1-t)*t*t*d[k]+t**3*e[k]
                  for k in range(len(a))) for t in [j/steps for j in range(steps+1)]]


class Relief:
    """Fine physical gold/white details batched by material, not tiny objects."""
    def __init__(self):
        self.data = {}

    def part(self, material):
        return self.data.setdefault(material, [[], []])

    def tube(self, points, radius, mat='gold', sides=5, closed=False, vertical_radius=None):
        points = [Vector(p) for p in points]
        if len(points) < 2:
            return
        if closed:
            points.append(points[0])
        verts, faces = self.part(mat)
        base, old_u = len(verts), None
        for j, point in enumerate(points):
            tangent = points[min(j+1, len(points)-1)]-points[max(0, j-1)]
            if tangent.length < 1e-9:
                tangent = Vector((0, 0, 1))
            tangent.normalize()
            ref = Vector((0, 0, 1)) if abs(tangent.z) < .94 else Vector((1, 0, 0))
            u = tangent.cross(ref).normalized()
            if old_u is not None and old_u.dot(u) < 0:
                u.negate()
            v = tangent.cross(u).normalized()
            old_u = u
            for k in range(sides):
                a = TAU*k/sides
                vr = radius if vertical_radius is None else vertical_radius
                verts.append(tuple(point+u*radius*math.cos(a)+v*vr*math.sin(a)))
        for j in range(len(points)-1):
            for k in range(sides):
                q, r = base+j*sides+k, base+j*sides+(k+1) % sides
                faces.append((q, r, r+sides, q+sides))
        faces.append(tuple(base+k for k in reversed(range(sides))))
        last = base+(len(points)-1)*sides
        faces.append(tuple(last+k for k in range(sides)))

    def bead(self, pos, radius, mat='gold', seg=7, rings=4):
        verts, faces = self.part(mat)
        start = len(verts)
        for j in range(rings+1):
            t = math.pi*j/rings
            for k in range(seg):
                a = TAU*k/seg
                verts.append((pos[0]+radius*math.sin(t)*math.cos(a),
                              pos[1]+radius*math.sin(t)*math.sin(a),
                              pos[2]+radius*math.cos(t)))
        for j in range(rings):
            for k in range(seg):
                q, r = start+j*seg+k, start+j*seg+(k+1) % seg
                faces.append((q+seg, r+seg, r, q))

    def leaf(self, mapping, path, width, mat='gold', depth=.0035, lobes=2):
        """Closed, lobed relief leaf with a cupped section and a raised rib."""
        verts, faces = self.part(mat)
        base = len(verts)
        cols, rows = 3, len(path)
        for front in (True, False):
            for j, (u, v) in enumerate(path):
                t = j/(rows-1)
                a, b = path[max(0, j-1)], path[min(rows-1, j+1)]
                dx, dy = b[0]-a[0], b[1]-a[1]
                length = max(1e-9, math.hypot(dx, dy))
                px, py = -dy/length, dx/length
                spread = max(.00004, width*math.sin(math.pi*t)**.7*(.78+.22*math.cos(TAU*lobes*t)))
                for k in range(cols):
                    s = k-1
                    r = .00025+depth*(.23+.77*(1-s*s))*math.sin(math.pi*t) if front else -.00025
                    verts.append(mapping(u+s*px*spread, v+s*py*spread, r))
        n = rows*cols
        # Front winding is checked against the mapping's outward relief axis.
        p0, p1, p2 = (Vector(verts[base+i]) for i in (3, 4, 7))
        outward = Vector(mapping(*path[1], .01))-Vector(mapping(*path[1], 0))
        reverse = (p1-p0).cross(p2-p0).dot(outward) < 0
        new_faces = []
        for j in range(rows-1):
            for k in range(cols-1):
                q = base+j*cols+k
                new_faces.append((q, q+1, q+1+cols, q+cols))
                new_faces.append((q+n+cols, q+n+1+cols, q+n+1, q+n))
            q = base+j*cols
            new_faces.append((q+n, q+n+cols, q+cols, q))
            q += cols-1
            new_faces.append((q, q+cols, q+n+cols, q+n))
        new_faces.append(tuple([base+k for k in reversed(range(cols))]+[base+n+k for k in range(cols)]))
        last = base+(rows-1)*cols
        new_faces.append(tuple([last+k for k in range(cols)]+[last+n+k for k in reversed(range(cols))]))
        faces.extend(tuple(reversed(f)) if reverse else f for f in new_faces)
        self.tube([mapping(u, v, min(.0008, depth*.30)+depth*math.sin(math.pi*j/(rows-1)))
                   for j, (u, v) in enumerate(path)], min(width*.075, .00055), mat, 4)

    def finish(self, name):
        result = []
        for mat, (verts, faces) in self.data.items():
            if verts:
                result.append(c.mesh(name+' | '+mat+' geometric detail', verts, faces, mat, smooth=True))
        return result


def rounded_rectangle(w, d, r=.008, samples=7):
    pts = []
    for x, y, a0 in [(w/2-r, d/2-r, 0), (-w/2+r, d/2-r, math.pi/2),
                     (-w/2+r, -d/2+r, math.pi), (w/2-r, -d/2+r, 3*math.pi/2)]:
        for j in range(samples+1):
            a = a0+j*math.pi/(2*samples)
            pts.append((x+r*math.cos(a), y+r*math.sin(a)))
    return pts


def circle(radius, samples=144):
    return [(radius*math.cos(TAU*j/samples), radius*math.sin(TAU*j/samples)) for j in range(samples)]


def curved_console(w, d):
    # Straight back, gently bowed front, rounded ends: not a rectangular box.
    pts = bezier((w/2, d/2-.022), (w/2+.001, -.04), (w/2-.10, -d/2), (w/2-.22, -d/2), 18)
    pts += bezier((w/2-.22, -d/2), (w*.18, -d/2-.001), (-w*.18, -d/2-.001), (-w/2+.22, -d/2), 28)[1:]
    pts += bezier((-w/2+.22, -d/2), (-w/2+.10, -d/2), (-w/2-.001, -.04), (-w/2, d/2-.022), 18)[1:]
    pts += [(-w/2+.014, d/2), (w/2-.014, d/2)]
    # Reverse to positive CCW winding for the extruded solid.
    return list(reversed(pts))


def scale_path(path, sx=1, sy=1):
    return [(x*sx, y*sy) for x, y in path]


def prism(name, path, z0, z1, mat, bevel=.0012):
    """Physical solid with eased rings and optically flat, planar-UV caps."""
    edge = min(bevel, (z1-z0)/4)
    w, d = max(abs(x) for x, y in path)*2, max(abs(y) for x, y in path)*2
    profiles = [(1-2*edge/max(w, .001), 1-2*edge/max(d, .001), z0),
                (1, 1, z0+edge), (1, 1, z1-edge),
                (1-2*edge/max(w, .001), 1-2*edge/max(d, .001), z1)]
    verts = [(x*sx, y*sy, z) for sx, sy, z in profiles for x, y in path]
    n, faces = len(path), []
    for j in range(3):
        for k in range(n):
            q = j*n+k
            faces.append((q, j*n+(k+1) % n, (j+1)*n+(k+1) % n, q+n))
    faces.extend([tuple(reversed(range(n))), tuple(3*n+k for k in range(n))])
    ob = c.mesh(name, verts, faces, mat, smooth=False)
    uv = ob.data.uv_layers.active
    for p in ob.data.polygons:
        if abs(p.normal.z) > .8:
            for li in p.loop_indices:
                co = ob.data.vertices[ob.data.loops[li].vertex_index].co
                uv.data[li].uv = (co.x/w+.5, co.y/d+.5)
    return ob


class Perimeter:
    def __init__(self, path):
        self.path = path
        self.lengths = [0]
        for k, p in enumerate(path):
            q = path[(k+1) % len(path)]
            self.lengths.append(self.lengths[-1]+math.hypot(q[0]-p[0], q[1]-p[1]))
        self.length = self.lengths[-1]

    def point(self, length, z, relief=0):
        length %= self.length
        for j in range(len(self.path)):
            if self.lengths[j+1] >= length:
                break
        a, b = self.path[j], self.path[(j+1) % len(self.path)]
        seg = max(1e-9, self.lengths[j+1]-self.lengths[j])
        t = (length-self.lengths[j])/seg
        x, y = a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t
        nx, ny = (b[1]-a[1])/seg, -(b[0]-a[0])/seg
        return (x+nx*relief, y+ny*relief, z)


def foliage_band(relief, path, zmid, height, pitch=.042):
    perimeter = Perimeter(path)
    count = max(12, int(perimeter.length/pitch))
    pitch = perimeter.length/count
    for k in range(count):
        center = (k+.5)*pitch
        def mapping(u, v, r, center=center):
            return perimeter.point(center+u, zmid+v, r+.0008)
        # A linked upward acanthus fan with a curling leaf on either side.
        stem = bezier((-.018, -height*.34), (-.010, height*.40), (.016, height*.40), (.013, 0), 9)
        relief.tube([mapping(u*pitch/.042, v, .0016) for u, v in stem], .001, 'antique_gold', 4)
        for sign in (-1, 1):
            leaf = bezier((0, -height*.35), (sign*.004, -height*.02),
                          (sign*.015, height*.32), (sign*.014, height*.36), 6)
            relief.leaf(mapping, leaf, min(.0065, pitch*.18), 'gold', .0028, 2)
        small = bezier((-.012, -height*.20), (-.022, 0), (-.018, height*.18), (-.010, height*.21), 5)
        relief.leaf(mapping, small, .0045, 'gold', .0028, 2)


def rosette(relief, mapping, radius, petals=10, mat='gold', depth=.0035):
    for k in range(petals):
        a = TAU*k/petals
        path = [(math.cos(a)*radius*(.16+.74*t), math.sin(a)*radius*(.16+.74*t))
                for t in [j/6 for j in range(7)]]
        relief.leaf(mapping, path, radius*.18, mat, depth, 1)
    relief.tube([mapping(radius*math.cos(TAU*j/48), radius*math.sin(TAU*j/48), .001)
                 for j in range(48)], .0011, mat, 5, True)
    relief.bead(mapping(0, 0, depth*.85), min(radius*.17, depth*.8), mat, 8, 4)


def laurel(relief, radius, z, mat='white', center=(0, 0)):
    """An actual low-relief inlaid white laurel wreath, not a texture decal."""
    for side in (-1, 1):
        a0, a1 = (-math.pi/2+.10, math.pi/2-.10) if side == 1 else (math.pi/2+.10, math.pi*1.5-.10)
        arc = [(center[0]+radius*math.cos(a0+(a1-a0)*j/32),
                center[1]+radius*math.sin(a0+(a1-a0)*j/32), z) for j in range(33)]
        relief.tube(arc, .00065, mat, 4)
        for k in range(13):
            a = a0+(a1-a0)*(k+.5)/13
            tangent = Vector((-math.sin(a), math.cos(a)))
            radial = Vector((math.cos(a), math.sin(a)))
            base = Vector(center)+radial*radius
            for direction in (-1, 1):
                end = base+tangent*(.014*side)+radial*(direction*.010)
                path = bezier(tuple(base), tuple(base+tangent*.005*side),
                              tuple(end-tangent*.004*side), tuple(end), 5)
                mapping = lambda u, v, r: (u, v, z+r)
                relief.leaf(mapping, path, .0039, mat, .00020, 1)


def outline(relief, path, z, radius=.001, mat='white', flat=False):
    relief.tube([(x, y, z) for x, y in path], radius, mat, 6 if flat else 5, True,
                vertical_radius=.00014 if flat else None)


def fluted(name, x, y, z0, z1, r0, r1, mat='piano', flutes=12):
    seg, rows = flutes*6, 7
    verts, faces = [], []
    for j in range(rows+1):
        t = j/rows
        fade = min(1, t*7, (1-t)*7)
        for k in range(seg):
            a = TAU*k/seg
            r = (r0+(r1-r0)*t)*(1-.10*((1+math.cos(flutes*a))/2)**3*fade)
            verts.append((x+r*math.cos(a), y+r*math.sin(a), z0+(z1-z0)*t))
    for j in range(rows):
        for k in range(seg):
            q, r = j*seg+k, j*seg+(k+1) % seg
            faces.append((q, r, r+seg, q+seg))
    faces.extend([tuple(reversed(range(seg))), tuple(rows*seg+k for k in range(seg))])
    ob = c.mesh(name, verts, faces, mat, smooth=True)
    for p in ob.data.polygons[-2:]:
        p.use_smooth = False
    return ob


def turned(name, x, y, profile, mat, seg=40):
    ob = c.lathe(name, (x, y, 0), profile, mat, seg)
    uv = ob.data.uv_layers.active
    for p in ob.data.polygons:
        if abs(p.normal.z) > .85:
            p.use_smooth = False
            for li in p.loop_indices:
                co = ob.data.vertices[ob.data.loops[li].vertex_index].co
                uv.data[li].uv = (co.x+x, co.y+y)
    return ob


def leg(relief, x, y, top, coffee=False):
    cap_h = .067 if coffee else .083
    cap_r = .023 if coffee else .026
    toe_h = .024 if coffee else .033
    sleeve_z0 = .080 if coffee else .137
    sleeve_z1 = .145 if coffee else .280
    # Unbroken taper is visible above/below the gilded lower sleeve.
    fluted('Black lacquer fluted tapered leg', x, y, toe_h, top-cap_h+.003,
           .012 if coffee else .014, .018 if coffee else .021)
    turned('Gilded leg upper fluted capital', x, y,
           [(0, top-cap_h), (cap_r*.70, top-cap_h), (cap_r*.74, top-cap_h+.006),
            (cap_r*.91, top-.012), (cap_r, top-.004), (cap_r, top), (0, top)], 'antique_gold')
    for k in range(10):
        a = TAU*k/10
        def mapping(u, v, r, a=a):
            t = v/cap_h
            aa = a+u/cap_r
            radius = cap_r*(.70+.25*t)+r
            return (x+radius*math.cos(aa), y+radius*math.sin(aa), top-cap_h+v)
        path = bezier((0, .006), (-.001, cap_h*.4), (.002, cap_h*.8), (0, cap_h*.94), 6)
        relief.leaf(mapping, path, .0044, 'gold', .0028, 2)
    # Long gold sleeve and distinct black toe reproduce the source's striped leg.
    sleeve_radius = .0143 if coffee else .017
    fluted('Long gilded lower-leg sleeve', x, y, sleeve_z0, sleeve_z1,
           sleeve_radius*.83, sleeve_radius, 'antique_gold', 10)
    for z, rr in [(sleeve_z0+.003, sleeve_radius*.90), (sleeve_z1-.003, sleeve_radius*1.01),
                  (top-cap_h+.003, cap_r*.73), (top-.005, cap_r*.99)]:
        relief.tube([(x+rr*math.cos(TAU*j/36), y+rr*math.sin(TAU*j/36), z) for j in range(36)],
                    .001, 'gold', 4, True)
    turned('Gilt chased toe', x, y,
           [(0, 0), (.010, 0), (.012, .003), (.011, toe_h-.004), (.013, toe_h), (0, toe_h)], 'gold', 28)
    for k in range(10):
        a = TAU*k/10
        relief.bead((x+.0115*math.cos(a), y+.0115*math.sin(a), toe_h*.65), .0012, 'gold', 5, 3)


def rail(name, points, z, width=.026, thickness=.020, mat='white'):
    verts, faces = [], []
    for i, p in enumerate(points):
        a, b = points[max(0, i-1)], points[min(len(points)-1, i+1)]
        dx, dy = b[0]-a[0], b[1]-a[1]
        length = max(1e-9, math.hypot(dx, dy))
        px, py = -dy/length*width/2, dx/length*width/2
        verts.extend([(p[0]-px, p[1]-py, z-thickness/2), (p[0]+px, p[1]+py, z-thickness/2),
                      (p[0]+px, p[1]+py, z+thickness/2), (p[0]-px, p[1]-py, z+thickness/2)])
    for j in range(len(points)-1):
        for k in range(4):
            q = j*4+k
            r = j*4+(k+1) % 4
            faces.append((q, r, r+4, q+4))
    faces.extend([(3, 2, 1, 0), tuple((len(points)-1)*4+k for k in range(4))])
    return c.mesh(name, verts, faces, mat, smooth=False)


def stretchers(positions, z, console=False):
    # Separate bowed rails leave the characteristic airy, concave X opening.
    edging = Relief()
    for k, a in enumerate(positions):
        b = positions[(k+1) % len(positions)]
        path = bezier(a, (a[0]*.10, a[1]*.10), (b[0]*.10, b[1]*.10), b, 32)
        rail('White curved X/bow stretcher body', path, z, .027, .021, 'white')
        # Black chasing outlines the white rail, without enclosing its face.
        for side in (-1, 1):
            line = []
            for j, p in enumerate(path):
                prev, nxt = path[max(0, j-1)], path[min(len(path)-1, j+1)]
                dx, dy = nxt[0]-prev[0], nxt[1]-prev[1]
                length = max(1e-9, math.hypot(dx, dy))
                line.append((p[0]-side*dy/length*.0135, p[1]+side*dx/length*.0135, z+.0102))
            edging.tube(line, .0009, 'piano', 4)
            edging.tube([(x, y, z-.0102) for x, y, _ in line], .00065, 'piano', 4)
    edging.finish('Black outlines on white bowed stretchers')
    prism('White central stretcher junction', circle(.039, 40), z-.010, z+.013, 'white', .0008)
    if console:
        # Gilt central finial is visible on both consoles and cabinet stand.
        turned('Small classical gilded stretcher finial', 0, 0,
               [(0, z+.013), (.021, z+.013), (.022, z+.018), (.012, z+.025),
                (.023, z+.041), (.019, z+.053), (.011, z+.060), (.015, z+.066),
                (.005, z+.070), (0, z+.079)], 'gold', 32)


def corner_block(relief, center, normal, zmid, width=.057, height=.055):
    nx, ny = normal
    angle = math.atan2(ny, nx)-math.pi/2
    c.box('Black corner block in white and gold surround', (center[0], center[1], zmid),
          (width, .015, height), 'piano', .001, (0, 0, angle))
    tangent = (ny, -nx)
    def mapping(u, v, r):
        return (center[0]+tangent[0]*u+nx*(.008+r), center[1]+tangent[1]*u+ny*(.008+r), zmid+v)
    for inset, rad, mat in [(0, .0016, 'white'), (.003, .0008, 'gold')]:
        w, h = width/2-inset, height/2-inset
        relief.tube([mapping(-w, -h, 0), mapping(w, -h, 0), mapping(w, h, 0), mapping(-w, h, 0)],
                    rad, mat, 5, True)


def table(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    circular = sku == '50296.0'
    console = sku in ('50279.0', '50357.0')
    curved = sku == '50279.0'
    path = circle(w/2) if circular else (curved_console(w, d) if curved else rounded_rectangle(w, d, .010))
    rel = Relief()
    # All these photographed tops are black lacquer, never marble.
    prism('Black piano lacquer top with physically eased edge', path, h-.024, h, 'piano', .0015)
    outline(rel, scale_path(path, 1-.018/w, 1-.018/d), h-.019, .0013, 'white')
    outline(rel, scale_path(path, 1-.034/w, 1-.034/d), h+.00015, .00115, 'white', True)
    outline(rel, scale_path(path, 1-.057/w, 1-.057/d), h+.00015, .00115, 'white', True)
    if not console:
        laurel(rel, .107 if circular else .106, h+.00010)
    apron_top, apron_bottom = h-.028, h-.083
    inner = scale_path(path, 1-.014/w, 1-.014/d)
    prism('White upper apron edging', inner, apron_top-.004, apron_top+.002, 'white', .0008)
    prism('Gilded cast foliate apron ground', scale_path(inner, 1-.006/w, 1-.006/d),
          apron_bottom+.008, apron_top-.004, 'bronze', .0006)
    prism('White lower apron edging', inner, apron_bottom, apron_bottom+.008, 'white', .0008)
    outline(rel, scale_path(inner, 1-.006/w, 1-.006/d), apron_bottom+.010, .0009, 'gold')
    foliage_band(rel, scale_path(inner, 1-.006/w, 1-.006/d),
                 (apron_top+apron_bottom)/2+.002, .032, .043)
    if circular:
        radius = w/2-.070
        positions = [(radius*math.cos(-math.pi/2+TAU*k/6), radius*math.sin(-math.pi/2+TAU*k/6)) for k in range(6)]
        for a in [-math.pi/2+TAU*k/6 for k in range(6)]:
            rr = w/2-.013
            corner_block(rel, (rr*math.cos(a), rr*math.sin(a)), (math.cos(a), math.sin(a)),
                         (apron_top+apron_bottom)/2, .058, .054)
    else:
        inset = .064 if console else .060
        positions = [(-w/2+inset, -d/2+inset), (w/2-inset, -d/2+inset),
                     (w/2-inset, d/2-inset), (-w/2+inset, d/2-inset)]
        # Curved-console front legs move into the true rounded front corners.
        if curved:
            positions[0] = (-w/2+.145, -d/2+.054)
            positions[1] = (w/2-.145, -d/2+.054)
        for x, y in positions:
            front = y < 0
            corner_block(rel, (x, -d/2+.010 if front else d/2-.010),
                         (0, -1 if front else 1), (apron_top+apron_bottom)/2, .058, .054)
    for x, y in positions:
        leg(rel, x, y, apron_bottom+.001, not console)
    stretchers(positions, .145 if not console else .180, console)
    rel.finish('Wellington table inlays and casting')


def pedestal_side():
    h, radius = .700, .325
    rel = Relief()
    prism('Circular black lacquer top', circle(radius), h-.027, h, 'piano', .0013)
    for rr in (radius-.025, radius-.042):
        outline(rel, circle(rr), h+.00015, .00115, 'white', True)
    laurel(rel, .082, h+.0001)
    prism('White circular pedestal table apron', circle(radius-.005), h-.067, h-.028, 'white', .001)
    prism('Dark under-apron shadow', circle(radius-.009), h-.073, h-.067, 'piano', .0005)
    outline(rel, circle(radius-.007), h-.068, .0012, 'gold')
    foliage_band(rel, circle(radius-.009), h-.071, .008, .024)
    # Four-lobed concave base, not a round drum or a plain square slab.
    corners = [(-.168, -.168), (.168, -.168), (.168, .168), (-.168, .168)]
    basepath = []
    for i, a in enumerate(corners):
        b = corners[(i+1) % 4]
        basepath += bezier(a, (a[0]*.40, a[1]*.40), (b[0]*.40, b[1]*.40), b, 18)[:-1]
    prism('Black edged four-lobed pedestal plinth', basepath, .028, .056, 'piano', .001)
    prism('White concave four-lobed pedestal base', scale_path(basepath, .99, .99), .036, .069, 'white', .0012)
    outline(rel, scale_path(basepath, .985, .985), .063, .0013, 'piano')
    for x, y in corners:
        turned('Gilt bun foot under four-lobed base', x*.90, y*.90,
               [(0, 0), (.014, 0), (.021, .009), (.023, .019), (.016, .031), (0, .031)], 'gold', 32)
    turned('Black waisted turned central pedestal', 0, 0,
           [(0, .063), (.083, .063), (.083, .076), (.068, .090), (.045, .117),
            (.034, .170), (.031, .280), (.030, .365), (.034, .490), (.045, .580),
            (.053, h-.073), (0, h-.073)], 'piano', 64)
    for z, rr in [(.074, .081), (.082, .075), (.343, .034), (.372, .033)]:
        outline(rel, circle(rr, 64), z, .002, 'gold')
    # Two opposed rows of acanthus on the mid-height gold bracelet.
    for k in range(10):
        a = TAU*k/10
        for sign in (-1, 1):
            def mapping(u, v, r, a=a):
                aa = a+u/.034
                return ((.034+r)*math.cos(aa), (.034+r)*math.sin(aa), .357+v)
            path = bezier((0, 0), (-.003, sign*.008), (.003, sign*.025), (0, sign*.034), 7)
            rel.leaf(mapping, path, .006, 'gold', .0033, 2)
    rel.finish('Wellington pedestal laurel and gilding')


def vertical_rectangle(rel, w, h, y, z0, mat='gold', radius=.0015, x0=0):
    rel.tube([(x0-w/2, y, z0), (x0+w/2, y, z0), (x0+w/2, y, z0+h), (x0-w/2, y, z0+h)],
             radius, mat, 5, True)


def mirror(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    crest = sku == '50280.0'
    frame_h = h-.070 if crest else h
    band = .091 if crest else .085
    rel = Relief()
    # Exact declared depth includes a proper black backing and rebated frame.
    c.box('Thin black mirror backing behind silvered pane', (0, d/2-.003, frame_h/2),
          (w, .006, frame_h), 'piano', .001)
    face_y = -d/2+.012
    for x in (-w/2+band/2, w/2-band/2):
        c.box('Rebated black vertical frame body', (x, .006, frame_h/2),
              (band, d-.012, frame_h), 'piano', .001)
    for z in (band/2, frame_h-band/2):
        c.box('Rebated black horizontal frame body', (0, .006, z),
              (w, d-.012, band), 'piano', .001)
    c.box('Silvered mirror glass | reflective not a photograph', (0, face_y+.004, frame_h/2),
          (w-2*band+.008, .006, frame_h-2*band+.008), 'mirror', .001)
    for x in (-w/2+band/2, w/2-band/2):
        c.box('Ivory-white vertical mirror frame', (x, face_y, frame_h/2),
              (band-.012, .014, frame_h-.012), 'white', .001)
    for z in (band/2, frame_h-band/2):
        c.box('Ivory-white horizontal mirror frame', (0, face_y, z),
              (w-.012, .014, band-.012), 'white', .001)
    for x in (-w/2+.004, w/2-.004):
        c.box('Thin visible outer black mirror border', (x, -d/2+.0015, frame_h/2),
              (.008, .003, frame_h), 'piano', .0003)
    for z in (.004, frame_h-.004):
        c.box('Thin visible outer black mirror border', (0, -d/2+.0015, z),
              (w, .003, .008), 'piano', .0003)
    # Narrow inner and outer gilded rebates are true continuous geometry.
    vertical_rectangle(rel, w-.010, frame_h-.010, -d/2+.0002, .005, 'gold', .0007)
    vertical_rectangle(rel, w-2*band+.005, frame_h-2*band+.005, -d/2+.002, band-.0025, 'gold', .0014)
    for x in (-w/2+band/2, w/2-band/2):
        for z in (band/2, frame_h-band/2):
            c.box('Black mirror corner block', (x, -d/2+.007, z), (band-.003, .008, band-.003), 'piano', .0008)
            mapping = lambda u, v, r, x=x, z=z: (x+u, -d/2+.004-r, z+v)
            rosette(rel, mapping, band*.215, 8, 'gold', .0025)
    # Small, regular chased buds distinguish the fine gilt inner moulding.
    for side in (-1, 1):
        x = side*(w/2-band+.002)
        for k in range(int((frame_h-2*band)/.025)):
            rel.bead((x, face_y-.002, band+(k+.5)*.025), .0016, 'gold', 5, 3)
    if crest:
        rr, zc = .119, h-.119
        disc = c.cylinder('Top circular black medallion crest', (0, -d/2+.008, zc), rr, .010, 'piano')
        disc.rotation_euler[0] = math.pi/2
        # Cap radius reaches exactly h and is flat, not a smooth-shaded dome.
        for p in disc.data.polygons:
            if abs(p.normal.z) > .85:
                p.use_smooth = False
        face = -d/2+.003
        mapping = lambda u, v, r: (u, face-r, zc+v)
        rosette(rel, mapping, .078, 16, 'gold', .0015)
        for rr in (.089, .097):
            rel.tube([mapping(rr*math.cos(TAU*j/96), rr*math.sin(TAU*j/96), .001)
                      for j in range(96)], .0018, 'gold', 5, True)
        for side in (-1, 1):
            for k in range(6):
                x = side*(.13+k*.022)
                mapping2 = lambda u, v, r: (u, -d/2+.004-r, frame_h-band/2+v)
                p = bezier((x, 0), (x+side*.004, .012), (x+side*.018, .015), (x+side*.023, .008), 5)
                rel.leaf(mapping2, p, .006, 'gold', .002, 1)
    rel.finish('Wellington mirror cast flowers and gilt rebates')


def small_glass(name, x, y, z, height, radius, bottle=False):
    if bottle:
        profile = [(0, z), (radius*.80, z), (radius, z+.012), (radius, z+height*.60),
                   (radius*.48, z+height*.76), (radius*.29, z+height*.80),
                   (radius*.29, z+height*.97), (0, z+height*.97)]
        ob = turned(name, x, y, profile, 'glass', 24)
        stop = c.cylinder('Optional bottle stopper', (x, y, z+height), radius*.31, height*.055, 'brass')
        stop['is_staging'] = True
    else:
        profile = [(0, z), (radius*.82, z), (radius*.90, z+.004), (radius*.17, z+.009),
                   (radius*.12, z+height*.40), (radius*.67, z+height*.48),
                   (radius, z+height*.75), (radius*.85, z+height),
                   (radius*.75, z+height), (radius*.88, z+height*.76),
                   (radius*.58, z+height*.51), (0, z+height*.47)]
        ob = turned(name, x, y, profile, 'glass', 28)
    ob['is_staging'] = True
    ob['staging_note'] = 'Removable display styling; not a manufacturer furniture component.'


def cabinet():
    w, d, h = 1.15, .50, 2.12
    rel = Relief()
    # Open four-leg stand with a bowed white stretcher, not a floor cabinet.
    stand_bottom, stand_top = .490, .553
    footprint = rounded_rectangle(w-.033, d-.026, .005)
    prism('Cabinet stand black apron body', footprint, stand_bottom, stand_top, 'piano', .001)
    # The gold relief must face outward from the black support, not be buried
    # inside its sides. The lower vitrine stand has the same gold frieze as top.
    ground = scale_path(footprint, 1.001, 1.002)
    prism('Gilded vitrine stand apron field', ground, stand_bottom+.007, stand_top-.007, 'bronze', .0006)
    prism('Stand upper white edge', footprint, stand_top-.006, stand_top+.001, 'white', .0008)
    prism('Stand lower white edge', footprint, stand_bottom-.002, stand_bottom+.005, 'white', .0008)
    foliage_band(rel, ground, (stand_bottom+stand_top)/2, .034, .043)
    positions = [(-.487, -.180), (.487, -.180), (.487, .180), (-.487, .180)]
    for x, y in positions:
        leg(rel, x, y, stand_bottom, False)
        corner_block(rel, (x, -.236 if y < 0 else .236), (0, -1 if y < 0 else 1), .521, .059, .061)
    stretchers(positions, .151, True)
    # Stepped black/white plinth directly beneath the glazed vitrine.
    prism('Stepped vitrine lower black plinth', rounded_rectangle(w, d, .004), .549, .579, 'piano', .001)
    prism('White vitrine plinth step', rounded_rectangle(w-.020, d-.018, .003), .578, .593, 'white', .001)
    prism('Black plinth upper moulding', rounded_rectangle(w-.034, d-.024, .003), .591, .619, 'piano', .001)
    outline(rel, rounded_rectangle(w-.026, d-.018, .003), .582, .0016, 'gold')
    body_bottom, body_top = .614, 1.984
    body_w, body_d = 1.080, .448
    # Interior is explicitly volumetric with a back, roof and base.
    c.box('White cabinet rear panel', (0, body_d/2-.012, (body_top+body_bottom)/2),
          (body_w, .024, body_top-body_bottom), 'white', .001)
    c.box('White cabinet interior bottom', (0, 0, body_bottom+.015), (body_w, body_d, .030), 'white', .001)
    c.box('White cabinet interior ceiling', (0, 0, body_top-.014), (body_w, body_d, .028), 'white', .001)
    front_y = -body_d/2
    for x in (-body_w/2+.040, body_w/2-.040):
        c.box('White front vitrine stile', (x, front_y+.013, (body_top+body_bottom)/2),
              (.080, .038, body_top-body_bottom), 'white', .001)
        vertical_rectangle(rel, .052, body_top-body_bottom-.125, front_y-.007, body_bottom+.045, 'piano', .0009, x)
        # Cast hanging foliate ornaments below the upper cornice.
        mapping = lambda u, v, r, x=x: (x+u, front_y-.009-r, body_top-.105+v)
        for k in range(3):
            path = bezier((0, -.025*k), (-.015, -.018-.025*k), (-.010, -.037-.025*k), (0, -.041-.025*k), 6)
            rel.leaf(mapping, path, .007, 'gold', .003, 2)
            path = [(-u, v) for u, v in path]
            rel.leaf(mapping, path, .007, 'gold', .003, 2)
    # Clear side panes are framed at all four edges, not opaque side boards.
    for x in (-body_w/2+.004, body_w/2-.004):
        c.box('Clear side vitrine glass pane', (x, .002, (body_top+body_bottom)/2),
              (.005, body_d-.065, body_top-body_bottom-.054), 'glass', .0004)
        for y in (front_y+.018, body_d/2-.027):
            c.box('White vitrine side corner post', (x, y, (body_top+body_bottom)/2),
                  (.024, .035, body_top-body_bottom), 'white', .001)
    opening_w = body_w-.176
    door_z0, door_z1 = body_bottom+.042, body_top-.035
    # One framed front glazing panel, kept fixed because hardware operation is unknown.
    c.box('Fixed front glazed display panel | not an animated door', (0, front_y+.003, (door_z0+door_z1)/2),
          (opening_w, .005, door_z1-door_z0), 'glass', .0004)
    vertical_rectangle(rel, opening_w+.010, door_z1-door_z0+.012, front_y-.002, door_z0-.006, 'piano', .001)
    vertical_rectangle(rel, opening_w+.020, door_z1-door_z0+.022, front_y-.001, door_z0-.011, 'white', .003)
    # TWO clear glass shelves yield the photographed THREE display levels.
    for level, z in enumerate((1.075, 1.500), 1):
        c.box('Glass shelf %d of 2' % level, (0, -.001, z), (body_w-.074, body_d-.064, .009), 'glass', .0006)
        for x in (-body_w/2+.036, body_w/2-.036):
            for y in (-.160, .160):
                c.cylinder('Small brass glass-shelf support', (x, y, z-.009), .005, .009, 'brass')
    # A small reference-visible brass knob; no assumed hinges/opening animation.
    c.sphere('Small brass cabinet knob', (opening_w/2+.028, front_y-.012, 1.283), (.007, .010, .007), 'brass', 16, 8)
    c.rod('Brass knob spindle', (opening_w/2+.028, front_y-.002, 1.283), (opening_w/2+.028, front_y-.014, 1.283), .003, 'brass')
    # Classical stepped white cornice with black top, deep gold frieze below.
    prism('Black lower cornice fillet', rounded_rectangle(w-.030, d-.016, .003), 1.974, 1.995, 'piano', .001)
    prism('Gold cornice frieze ground', rounded_rectangle(w-.042, d-.024, .003), 1.994, 2.043, 'bronze', .001)
    foliage_band(rel, rounded_rectangle(w-.042, d-.024, .003), 2.018, .032, .044)
    prism('White stepped cornice lower shoulder', rounded_rectangle(w-.028, d-.014, .003), 2.041, 2.065, 'white', .001)
    prism('White overhanging upper crown moulding', rounded_rectangle(w-.010, d-.006, .003), 2.062, 2.106, 'white', .002)
    prism('Flat black piano lacquer cornice cap', rounded_rectangle(w, d, .003), 2.105, h, 'piano', .001)
    for x in (-.488, .488):
        corner_block(rel, (x, -.241), (0, -1), 2.019, .061, .057)
    # Removable interior styling is flagged separately in the editable master.
    for level, z in enumerate((body_bottom+.032, 1.081, 1.506)):
        for k, x in enumerate((-.29, -.10, .14, .31)):
            small_glass('Optional cabinet display '+('decanter' if k % 3 == 0 else 'stem glass'),
                        x, .005 if k % 2 else .045, z,
                        .205 if k % 3 == 0 else .154, .037 if k % 3 == 0 else .029, k % 3 == 0)
    rel.finish('Wellington vitrine cast foliate details')


def tv_furniture():
    w, d, h = 2.20, .50, .80
    rel = Relief()
    # Four small gilt feet and a stepped black/white plinth.
    for x in (-.980, .980):
        for y in (-.170, .170):
            fluted('Short gilt TV foot', x, y, 0, .085, .014, .025, 'gold', 10)
            turned('TV foot upper socket', x, y, [(0, .078), (.027, .078), (.028, .091), (0, .091)], 'antique_gold', 28)
    prism('TV black lower plinth', rounded_rectangle(w-.026, d-.018, .004), .083, .116, 'piano', .001)
    prism('TV white plinth step', rounded_rectangle(w-.018, d-.012, .004), .112, .129, 'white', .001)
    prism('TV black plinth top reveal', rounded_rectangle(w-.032, d-.020, .003), .127, .147, 'piano', .001)
    outline(rel, rounded_rectangle(w-.028, d-.018, .003), .104, .0016, 'gold')
    # Real storage cavities: a white back, floor, top and centre shelf.
    c.box('White rear case panel', (0, .230, .423), (w-.065, .030, .560), 'white', .001)
    c.box('White main cabinet floor', (0, 0, .155), (w-.050, d-.038, .030), 'white', .001)
    c.box('White top support under frieze', (0, 0, .696), (w-.032, d-.026, .035), 'white', .001)
    for x in (-1.065, 1.065):
        c.box('White outer vertical TV stile', (x, -.001, .423), (.067, d-.036, .536), 'white', .001)
        mapping = lambda u, v, r, x=x: (x+u, -.239-r, .637+v)
        for k in range(3):
            for sign in (-1, 1):
                path = bezier((0, -.029*k), (sign*.010, -.012-.029*k), (sign*.013, -.031-.029*k), (0, -.041-.029*k), 5)
                rel.leaf(mapping, path, .006, 'gold', .003, 2)
        vertical_rectangle(rel, .038, .285, -.240, .175, 'piano', .0008, x)
    for x in (-.456, .456):
        c.box('White centre-cubby divider', (x, 0, .423), (.043, d-.040, .536), 'white', .001)
    c.box('White middle shelf separating two open TV cubbies', (0, 0, .417), (.872, d-.041, .024), 'white', .001)
    # Dark figured front panels with gold rings and centred circular medallions.
    for x in (-.759, .759):
        c.box('Fixed dark figured-timber front panel | no assumed moving door', (x, -.207, .421),
              (.542, .034, .503), 'wood', .002)
        vertical_rectangle(rel, .513, .475, -.2255, .1835, 'gold', .0013, x)
        vertical_rectangle(rel, .500, .462, -.2260, .1900, 'antique_gold', .0008, x)
        mapping = lambda u, v, r, x=x: (x+u, -.227-r, .421+v)
        for radius in (.199, .204):
            rel.tube([mapping(radius*math.cos(TAU*j/128), radius*math.sin(TAU*j/128), .001)
                      for j in range(128)], .0018 if radius == .199 else .0010, 'gold', 5, True)
        # The tiny manufacturer crest is reconstructed as a radial foliate casting.
        rosette(rel, mapping, .069, 16, 'gold', .006)
        for radius in (.075, .082):
            rel.tube([mapping(radius*math.cos(TAU*j/80), radius*math.sin(TAU*j/80), .002)
                      for j in range(80)], .002, 'antique_gold', 6, True)
        for k in range(40):
            a = TAU*k/40
            rel.bead(mapping(.0785*math.cos(a), .0785*math.sin(a), .003), .0018, 'gold', 5, 3)
    apron_bottom, apron_top = .714, .776
    path = rounded_rectangle(w-.010, d-.008, .004)
    prism('TV gilded frieze ground', scale_path(path, .998, .995), apron_bottom, apron_top, 'bronze', .001)
    foliage_band(rel, scale_path(path, .998, .995), .745, .037, .045)
    prism('White lower frieze edging', path, .708, .716, 'white', .0008)
    prism('White upper frieze edging', path, .773, .781, 'white', .0008)
    prism('Black lacquer TV top with flat polished cap', rounded_rectangle(w, d, .004), .780, h, 'piano', .0014)
    outline(rel, rounded_rectangle(w-.019, d-.018, .003), .788, .0012, 'white')
    for x in (-1.060, 1.060):
        corner_block(rel, (x, -.240), (0, -1), .745, .060, .063)
    rel.finish('Wellington TV foliate medallions and inlays')


def create(sku, instance='main'):
    sku = str(sku)
    if sku not in SPECS:
        raise ValueError('Unknown Wellington casegood SKU: '+sku)
    name, dimensions = SPECS[sku]
    root = c.empty(name+' | '+str(instance), props={
        'kind': 'product', 'product_id': sku, 'instance_id': str(instance),
        'dimensions_mm': list(dimensions), 'collection': 'Wellington',
        'source': 'CLASSIC_FURNITURE_CATALOG_2023.pdf | MARINER | PDF pages 29–31',
        'moving_parts': 0,
        'reconstruction_note': 'Independent visual reconstruction; hidden joinery, exact carvings and calibrated physical finishes are not manufacturer-certified.',
        'origin_note': 'Bottom-centred; mirrors are separately positioned above consoles by the exhibition.',
    })
    if sku == '50298.2':
        root['reconstruction_note'] += ' TV furniture is partly occluded in the sole lifestyle reference; hidden sides and inner construction are interpreted. Timber species not declared.'
    if sku == '50297.0':
        root['shelf_count'] = 2
        root['display_levels'] = 3
        root['staging_note'] = 'Optional glassware and bottles are flagged is_staging and removable in the master.'
    if sku == '50296.0':
        root['leg_count'] = 6
    with parent_to(root):
        if sku == '50278.0':
            pedestal_side()
        elif sku in ('50295.0', '50296.0', '50279.0', '50357.0'):
            table(sku)
        elif sku in ('50280.0', '50302.0'):
            mirror(sku)
        elif sku == '50297.0':
            cabinet()
        else:
            tv_furniture()
    return root
