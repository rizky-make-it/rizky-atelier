# WELLINGTON / Rizky Atelier

Independent visual reconstruction by Muhammad Rizky of fifteen MARINER living-room references from the supplied CLASSIC FURNITURE CATALOG 2023, PDF pages 25–31 (printed 48–61). Page32 begins Nantes and is outside this delivery.

## Inventory and fidelity

Six seating SKUs: navy 50292.0 / 50293.0, white-frame navy armchair 50294.2, burgundy 50490.0 / 50491.0 / 50492.0. Five tables/consoles: 50278.0, 50295.0, 50296.0, 50279.0, 50357.0. Two mirrors: 50280.0 / 50302.0. Glass cabinet 50297.0 and TV furniture 50298.2. Exact dimensions, finish references, source pages and image evidence are in reference/products.json.

The navy family has hard side medallion panels, finials and rear tufting; the burgundy family has tufted outer sides, a smooth rear and no side medallions or front finials. The printed red two-seat SKU has no isolated photograph and shares the original three-seat family image; its geometry is dimension-led, never a fabricated catalogue photograph. The round coffee table has six legs and curved stretchers, the square table four. Tops are black lacquer with white inlay, not marble. The glass cabinet has two glass shelves and three display levels. Cabinet and TV assemblies remain fixed because opening mechanics are not established. Mirror stands are exhibition staging, not asserted catalogue mounting hardware.

## Delivery

The editable wall-free native master contains twenty placements, ten cameras and five packed authored PBR maps. Seven genuine EEVEE renders are 3840 × 2160 and three details are 1600 × 1600. Individual GLBs retain evaluated full-detail geometry; the exhibition uses a reduced geometry LOD. No AI image substitutes for actual native rendering or product geometry.

Open wellington-exhibition.blend with Blender 5.2+. Rebuild: `blender --background --python build_scene.py`. Export: `blender --background wellington-exhibition.blend --python export_web.py`. Render: `blender --background wellington-exhibition.blend --python render_scene.py -- all` (add --preview for reduced camera checks, or --cycles for a different engine). Audit: `blender --background wellington-exhibition.blend --python validate_native.py`. The packaging helper requires PyMuPDF and the source PDF path recorded in the reference manifest; geometry rebuilding does not require the PDF.

## Provenance and limits

Source imagery retains native density: exact embedded JPEGs, documented crops, or original soft-mask composites over the source white page background. Original image/PDF mirroring is recorded; no new segmentation, AI enhancement or super-resolution is applied. TV reference is a partially occluded lifestyle crop with one edge clipped; mirrors/consoles retain styling and occlusion. These references do not independently establish photography versus CGI.

Lacquer, velvet, damask, brass and gold finishes are authored PBR interpretations, not calibrated manufacturer scans. Glass uses a transparent thin-sheet real-time approximation so the modelled shelves and interior remain visible in EEVEE and the browser; it is not a calibrated optical sample. Figured brown panels are visually interpreted; no timber species or solid-wood construction is certified by the source. Precise casting topology, joinery, unseen undersides/rears, opening hardware and material calibration remain unverified. This is not official engineering CAD, fabrication documentation or manufacturer endorsement. Catalogue image/design rights remain with their owners; no commercial reuse licence is implied.

Website copy is English. All earlier collections remain intact. Visible data requests open Muhammad Rizky's WhatsApp contact popup without sending automatically; public static assets are not access-controlled by that popup.
