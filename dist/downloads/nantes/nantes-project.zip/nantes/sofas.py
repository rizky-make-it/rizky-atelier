"""MARINER NANTES upholstery, editable reference-led visual reconstruction.

Reference pages 66/67, 198/199 and 242-247 (PDF 34, 100, 122-124).
X width, Y depth, Z up; floor-centred root; the front faces -Y.  Unshown
construction is interpreted, not manufacturer CAD.  The distinctive curved
burl shell is NOT the rectilinear Wellington design.  Cloth has actual seams,
welts, gathered corners, quilt displacement and separately named styling.
"""
import math
from contextlib import contextmanager
import bpy
import numpy as np
from mathutils import Vector
import core as c

TAU=math.tau
SPECS={
 '50375.0':(2.500,.920,.780,'sofa',3,'Nantes three-seat sofa'),
 '50376.0':(1.800,.920,.780,'sofa',2,'Nantes two-seat sofa'),
 '50377.0':(1.090,.920,.780,'sofa',1,'Nantes armchair'),
 '50344.0':(.550,.580,.970,'chair',0,'Nantes shield-back dining chair'),
 '50345.0':(.630,.580,.970,'chair',1,'Nantes shield-back dining armchair'),
 '50381.0':(2.180,2.180,1.600,'bed',0,'Nantes upholstered bed'),
 '50384.0':(1.520,.540,.520,'bench',0,'Nantes bedroom bench'),
 '50385.0':(.540,.540,.430,'stool',0,'Nantes dressing stool'),
}


@contextmanager
def parent(ob):
    previous=c.PARENT;c.set_parent(ob)
    try:yield ob
    finally:c.set_parent(previous)


class Batch:
    """One solid editable mesh per material instead of thousands of objects."""
    def __init__(self,name,mat):self.name=name;self.mat=mat;self.v=[];self.f=[]
    def tube(self,points,radius,sides=6,cyclic=False):
        pts=[Vector(p) for p in points]
        if len(pts)<2:return
        if cyclic:pts.append(pts[0])
        base=len(self.v)
        for i,p in enumerate(pts):
            tangent=(pts[min(i+1,len(pts)-1)]-pts[max(i-1,0)]).normalized()
            axis=Vector((0,1,0)) if abs(tangent.y)<.95 else Vector((0,0,1))
            a=tangent.cross(axis).normalized();b=tangent.cross(a).normalized()
            for j in range(sides):
                ang=TAU*j/sides;self.v.append(tuple(p+radius*(a*math.cos(ang)+b*math.sin(ang))))
        for i in range(len(pts)-1):
            for j in range(sides):
                q=base+i*sides+j;r=base+i*sides+(j+1)%sides
                self.f.append((q,r,r+sides,q+sides))
        if not cyclic:
            self.f.append(tuple(base+j for j in range(sides-1,-1,-1)))
            self.f.append(tuple(base+(len(pts)-1)*sides+j for j in range(sides)))
    def sphere(self,centre,scale,sides=8,rings=5):
        base=len(self.v)
        for j in range(rings+1):
            t=math.pi*j/rings
            for i in range(sides):
                a=TAU*i/sides
                self.v.append((centre[0]+scale[0]*math.sin(t)*math.cos(a),
                               centre[1]+scale[1]*math.sin(t)*math.sin(a),
                               centre[2]+scale[2]*math.cos(t)))
        for j in range(rings):
            for i in range(sides):
                q=base+j*sides+i;r=base+j*sides+(i+1)%sides
                self.f.append((q,r,r+sides,q+sides))
    def leaf(self,start,end,width,normal=(0,-1,0),bulge=.003):
        a,b,n=Vector(start),Vector(end),Vector(normal);d=b-a
        across=d.cross(n).normalized();base=len(self.v);rows=7
        for j in range(rows+1):
            t=j/rows;w=width*math.sin(math.pi*t)**.8*(.8+.2*math.cos(t*TAU*3))
            for i in range(5):
                u=(i-2)/2;p=a+d*t+across*u*w+n*bulge*math.sin(math.pi*t)*(1-.75*abs(u))
                self.v.append(tuple(p))
        for j in range(rows):
            for i in range(4):
                q=base+j*5+i;self.f.append((q,q+1,q+6,q+5))
        self.tube([tuple(a+d*t+n*(bulge*math.sin(math.pi*t)+.0005)) for t in [i/7 for i in range(8)]],.00065,5)
    def finish(self):
        return c.mesh(self.name,self.v,self.f,self.mat,smooth=True) if self.f else None


def materials():
    """Small supplementary textile colours, preserving the shared PBR palette."""
    colors={
      'nantes_chair_silk':((.38,.405,.42),.48,0),
      'nantes_bed_taupe':((.20,.142,.105),.71,0),
      'nantes_bed_dark':((.016,.018,.027),.63,0),
      'nantes_bed_stripe':((.255,.210,.165),.65,0),
    }
    for key,(color,r,metal) in colors.items():
        if key in c.M:continue
        mat=c.material('NANTES | '+key,color,r,metal);c.M[key]=mat
        bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Sheen Weight'].default_value=.23
        bs.inputs['Sheen Tint'].default_value=(*color,1)
        # The shared baked thread map remains portable to glTF when available.
        reference=c.M.get('cloth')
        if reference:
            normal=next((n for n in reference.node_tree.nodes if n.type=='TEX_IMAGE' and n.image and 'normal' in n.image.name.lower()),None)
            if normal:
                tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=normal.image
                nm=mat.node_tree.nodes.new('ShaderNodeNormalMap');nm.inputs['Strength'].default_value=.4
                mat.node_tree.links.new(tex.outputs['Color'],nm.inputs['Color']);mat.node_tree.links.new(nm.outputs['Normal'],bs.inputs['Normal'])
        if key=='nantes_chair_silk':
            # The dining chapter uses a noticeably cool silver-blue botanical
            # damask, not the living-room's golden champagne upholstery.
            n=1024;yy,xx=np.mgrid[0:n,0:n].astype(np.float32)/n
            fx=(xx*7+.5*(np.floor(yy*7)%2))%1-.5;fy=yy*7%1-.5
            a=np.arctan2(fy,fx);rad=np.sqrt(fx*fx+fy*fy)
            blossom=np.exp(-((rad-(.13+.047*np.cos(a*7)))/.027)**2)
            scroll=np.exp(-((fx-.14*np.sin(fy*8))/.017)**2)*.30
            leaves=np.exp(-((np.abs(fx)-(.18+.07*np.sin(fy*8)))/.035)**2)*np.sin(fy*math.pi*2)**2
            motif=np.clip(blossom*.68+scroll+leaves*.52,0,1)
            weave=np.sin(xx*TAU*210)*np.cos(yy*TAU*211)*.008
            rgb=np.array([.32,.35,.375])+motif[...,None]*np.array([.16,.145,.125])+weave[...,None]
            path=c.generated('nantes_silver_blue_damask',np.concatenate((rgb,np.ones((*rgb.shape[:2],1),dtype=np.float32)),axis=2))
            c.image_map(mat,path,'Base Color')
            mat['source']='Authored silver-blue botanical damask interpretation of reference fabric 241.185, not a manufacturer scan.'


def cushion(name,centre,dims,mat,rotation=(0,0,0),seat=False,piping=None,phase=0,softness=1,n=16):
    """Six-patch closed cloth with tailored seams and small physical folds."""
    holder=c.empty(name,centre);holder.rotation_euler=rotation
    half=[d/2 for d in dims];power=10 if seat else 4.7
    def shape(q):
        den=sum(abs(v)**power for v in q)**(1/power)
        p=[half[k]*q[k]/den for k in range(3)]
        if seat:
            if abs(q[2])>.99:
                edge=math.exp(-((abs(q[1])-.86)/.17)**2)
                p[2]+=math.copysign(.0030*softness*math.sin(q[0]*37+phase+math.sin(q[0]*11))*edge,q[2])
                if q[2]>0:p[2]-=.003*softness*(1-q[0]**2)*(1-q[1]**2)
            if abs(q[1])>.99:
                p[1]+=math.copysign(.0037*softness*math.sin(q[0]*34+phase)*(1-q[2]**2),q[1])
                p[2]+=.0013*softness*math.sin(q[0]*59+q[2]*4+phase)
        elif abs(q[1])>.99:
            edge=math.exp(-((abs(q[0])-.84)/.16)**2)+math.exp(-((abs(q[2])-.85)/.14)**2)
            p[1]+=math.copysign(softness*(.008*(1-q[0]**2)*(1-q[2]**2)+.0044*math.sin(q[0]*31+q[2]*10+phase)*edge),q[1])
            p[2]+=.0028*softness*math.sin(q[0]*8+phase)*(1-q[0]**2)
        return tuple(p)
    with parent(holder):
        verts=[];faces=[];uv=[]
        for axis,sign in [(0,-1),(0,1),(1,-1),(1,1),(2,-1),(2,1)]:
            other=[i for i in range(3) if i!=axis];base=len(verts)
            for j in range(n+1):
                for i in range(n+1):
                    q=[0,0,0];q[axis]=sign;q[other[0]]=-1+2*i/n;q[other[1]]=-1+2*j/n
                    verts.append(shape(q));uv.append((q[other[0]]*half[other[0]],q[other[1]]*half[other[1]]))
            forward=sign*(1 if axis!=1 else -1)>0
            for j in range(n):
                for i in range(n):
                    q=base+j*(n+1)+i;f=(q,q+1,q+n+2,q+n+1);faces.append(f if forward else tuple(reversed(f)))
        c.mesh(name+' | filled textile and gathered corners',verts,faces,mat,uv,True)
        points=[]
        for side in range(4):
            for i in range(24):
                t=-1+2*i/24;x,z=[(1,t),(-t,1),(-1,-t),(t,-1)][side]
                points.append(shape((x,z,0) if seat else (x,0,z)))
        c.curve(name+' | continuous sewn welt',points,.0016,piping or mat,True)
    return holder


def oval(batch,centre,u_axis,v_axis,a,b,radius=.0013,sides=20):
    p,u,v=Vector(centre),Vector(u_axis),Vector(v_axis)
    batch.tube([tuple(p+u*a*math.cos(TAU*i/sides)+v*b*math.sin(TAU*i/sides)) for i in range(sides)],radius,5,True)


def chain(batch,start,end,normal,width=.030,pitch=.021,radius=.0011):
    """Physical gilt interlocking ellipses, the collection's defining border."""
    a,b,n=Vector(start),Vector(end),Vector(normal);d=b-a;u=d.normalized();v=n.cross(u).normalized()
    count=max(1,round(d.length/pitch));step=d.length/count
    for i in range(count):
        p=a+u*step*(i+.5)
        oval(batch,p,u,v,step*.76,width/2,radius,16)


def rosette(gold,antique,centre,radius=.017,normal=(0,-1,0)):
    p,n=Vector(centre),Vector(normal);u=Vector((1,0,0)) if abs(n.y)>.8 else Vector((0,1,0));v=n.cross(u).normalized()
    oval(gold,p,u,v,radius,radius,.0011,24)
    for i in range(8):
        a=TAU*i/8;direction=u*math.cos(a)+v*math.sin(a)
        antique.leaf(tuple(p+direction*radius*.18),tuple(p+direction*radius*.84),radius*.22,tuple(n),.0025)
    antique.sphere(tuple(p+n*.002),tuple(.003 if abs(n[k])>.8 else .0045 for k in range(3)),8,5)


def laurel(gold,antique,centre,width=.40,normal=(0,-1,0)):
    p=Vector(centre);n=Vector(normal);z=Vector((0,0,1));x=Vector((1,0,0))
    for sign in (-1,1):
        branch=[]
        for i in range(16):
            t=i/15;branch.append(tuple(p+x*sign*width*.5*t+z*(.004+.014*math.sin(t*math.pi))))
        gold.tube(branch,.0014,6)
        for i in range(1,10):
            t=i/10;pos=p+x*sign*width*.5*t+z*(.004+.014*math.sin(t*math.pi))
            for up in (-1,1):
                antique.leaf(tuple(pos),tuple(pos+x*sign*.021+z*up*.019),.006,tuple(n),.003)
    rosette(gold,antique,tuple(p),.020,tuple(n))
    for dx in (-.035,.035):rosette(gold,antique,tuple(p+x*dx),.012,tuple(n))


def turned_foot(name,x,y,height,gold,slender=False):
    """Black turned foot, gilt fluted melon collar, and brass toe."""
    if slender:
        profile=[(.010,0),(.013,.012),(.015,.022),(.013,.033),(.019,height*.58),(.025,height*.89),(.025,height)]
        collar_r=.032;cz=height-.028;ch=.046
    else:
        profile=[(.014,0),(.021,.008),(.023,.018),(.017,.032),(.020,.052),(.028,height-.025),(.023,height)]
        collar_r=.038;cz=height-.026;ch=.040
    c.lathe(name+' | polished black turning',(x,y,0),profile,'piano',32)
    c.lathe(name+' | solid fluted gilt collar',(x,y,cz),[(0,-ch/2),(collar_r*.75,-ch/2),(collar_r,-ch*.19),(collar_r,ch*.05),(collar_r*.73,ch/2),(0,ch/2)],'antique_gold',32)
    for i in range(20):
        a=TAU*i/20
        pts=[]
        for j in range(9):
            t=j/8;r=collar_r*(.75+.25*math.sin(math.pi*t))
            pts.append((x+r*math.cos(a),y+r*math.sin(a),cz-ch/2+ch*t))
        gold.tube(pts,.0011,5)
    if slender:
        for z in (.009,.025):oval(gold,(x,y,z),(1,0,0),(0,1,0),.012,.012,.0012,20)


def apron(name,width,depth,z,height,gold,antique,full=True):
    """Scalloped black frieze with a thin, actual solid gilt edge."""
    y=-depth/2;segments=80;verts=[];faces=[];edge=[]
    for j in range(segments+1):
        x=-width/2+width*j/segments;u=abs(x)/(width/2)
        lower=z-height/2+.020*math.exp(-((u-.89)/.055)**2)
        edge.append((x,y-.003,lower))
        verts.extend([(x,y,lower),(x,y,z+height/2),(x,y+.032,z+height/2),(x,y+.032,lower)])
    for j in range(segments):
        for k in range(4):
            q=j*4+k;r=j*4+(k+1)%4;faces.append((q,r,r+4,q+4))
    faces.extend([(3,2,1,0),tuple((segments*4+k) for k in range(4))])
    c.mesh(name+' | curved lower black-lacquer frieze',verts,faces,'piano')
    gold.tube(edge,.0015,6)
    if full:laurel(gold,antique,(0,y-.006,z),min(.45,width*.5))


def sofa_path(width,depth):
    """A continuous U plan with genuinely round rear corners, not square arms."""
    rx=min(.24,width*.21);ry=.30;back=depth/2-.007;cy=back-ry;out=[]
    for j in range(17):out.append((-width/2+.007,-depth/2+.014+(cy+depth/2-.014)*j/16))
    for j in range(1,29):
        a=math.pi-math.pi/2*j/28;out.append((-width/2+.007+rx+rx*math.cos(a),cy+ry*math.sin(a)))
    left=-width/2+.007+rx;right=width/2-.007-rx
    for j in range(1,65):out.append((left+(right-left)*j/64,back))
    for j in range(1,29):
        a=math.pi/2-math.pi/2*j/28;out.append((right+rx*math.cos(a),cy+ry*math.sin(a)))
    for j in range(1,17):out.append((width/2-.007,cy+(-depth/2+.014-cy)*j/16))
    return out


def path_normals(path):
    normals=[]
    for i in range(len(path)):
        a=Vector((*path[max(0,i-1)],0));b=Vector((*path[min(len(path)-1,i+1)],0));d=(b-a).normalized()
        normals.append(Vector((-d.y,d.x,0)))
    return normals


def ribbon(name,path,normals,z0,z1,offset,mat,rows=2,puff=0):
    verts=[];faces=[];uv=[];distance=[0]
    for a,b in zip(path,path[1:]):distance.append(distance[-1]+math.dist(a,b))
    for j in range(rows+1):
        t=j/rows;z=z0+(z1-z0)*t
        for i,(p,n) in enumerate(zip(path,normals)):
            q=Vector((*p,z))+n*(offset+puff*math.sin(math.pi*t))
            verts.append(tuple(q));uv.append((distance[i],z))
    cols=len(path)
    for j in range(rows):
        for i in range(cols-1):
            q=j*cols+i;f=(q,q+1,q+cols+1,q+cols);faces.append(f if offset>=-.03 else tuple(reversed(f)))
    return c.mesh(name,verts,faces,mat,uv,True)


def sofa(width,depth,seats,gold,antique):
    path=sofa_path(width,depth);normals=path_normals(path)
    # Closed structural U-shell: exterior, interior, top and bottom surfaces.
    verts=[];faces=[]
    for i,(p,n) in enumerate(zip(path,normals)):
        for offset,z in [(0,.144),(0,.755),(-.091,.755),(-.091,.144)]:
            verts.append(tuple(Vector((*p,z))+n*offset))
    for i in range(len(path)-1):
        for j in range(4):
            q=i*4+j;r=i*4+(j+1)%4;faces.append((q,r,r+4,q+4))
    faces.extend([(3,2,1,0),tuple((len(path)-1)*4+j for j in range(4))])
    c.mesh('Continuous curved oak-burl U-shaped structural shell',verts,faces,'wood',smooth=True)
    ribbon('Tall figured-burl wraparound exterior',path,normals,.217,.724,.001,'wood',4)
    ribbon('Curved black lower exterior rail',path,normals,.127,.216,.004,'piano')
    ribbon('Polished black curved upper rail',path,normals,.724,.766,.003,'piano')
    ribbon('Continuous padded damask inside back and arms',path,normals,.370,.766,-.101,'damask',14,puff=-.018)
    # Upholstered roll along the upper U: not the separately rolled Chesterfield arms.
    top_points=[tuple(Vector((*p,.764))+n*(-.057)) for p,n in zip(path,normals)]
    upholstery=Batch('Rounded damask top cap and inner welt','damask')
    upholstery.tube(top_points,.025,10);upholstery.finish()
    for z in (.222,.714):
        line=[tuple(Vector((*p,z))+n*.003) for p,n in zip(path,normals)]
        gold.tube(line,.0009,5)
    # Oak-burl field bordered with interlocking sycamore/gilt marquetry.
    # Distances along the real curved shell keep the motif continuous.
    length=sum(math.dist(a,b) for a,b in zip(path,path[1:]));count=max(24,round(length/.028))
    lengths=[0]
    for a,b in zip(path,path[1:]):lengths.append(lengths[-1]+math.dist(a,b))
    def point_at(distance,z):
        i=next((j for j in range(1,len(lengths)) if lengths[j]>=distance),len(path)-1)
        t=(distance-lengths[i-1])/max(.000001,lengths[i]-lengths[i-1])
        p=Vector((*path[i-1],z)).lerp(Vector((*path[i],z)),t);n=normals[i-1].lerp(normals[i],t).normalized()
        return p+n*.003,n
    for z in (.244,.692):
        for k in range(count):
            distance=(k+.5)*length/count;p,n=point_at(distance,z);u=Vector((n.y,-n.x,0))
            oval(gold,tuple(p),tuple(u),(0,0,1),length/count*.68,.0065,.00065,12)
        for dz in (-.010,.010):
            gold.tube([tuple(Vector((*p,z+dz))+n*.004) for p,n in zip(path,normals)],.0007,5)
    # Exterior panel divisions visibly separate left curve, centre burl and right curve.
    for i in (0,44,108,len(path)-1):
        p=path[i];n=normals[i]
        c.rod('Dark exterior panel separating stile',tuple(Vector((*p,.216))+n*.005),tuple(Vector((*p,.726))+n*.005),.009,'piano')
        gold.tube([tuple(Vector((*p,z))+n*.015) for z in (.238,.701)],.0008,5)
    inside=width-.214
    c.box('Hidden upholstered seat deck',(0,-.005,.294),(inside,.751,.09),'cloth',.010)
    cushion('Single continuous damask bench seat',(0,-.055,.380),(inside,.760,.247),'damask',seat=True,phase=.6,n=20)
    apron('Sofa front apron',width-.018,depth,.170,.094,gold,antique)
    # Two black front pilasters each with vertical interlocking gilt and a rosette block.
    for sign in (-1,1):
        x=sign*(width/2-.044);y=-depth/2+.006
        c.box('Black front corner pilaster',(x,y,.454),(.078,.038,.629),'piano',.002)
        for dx in (-.035,.035):gold.tube([(x+dx,y-.021,.145),(x+dx,y-.021,.763)],.0013,6)
        chain(gold,(x,y-.022,.174),(x,y-.022,.681),(0,-1,0),.038,.035,.00125)
        c.box('Square pilaster rosette plinth',(x,y-.023,.727),(.066,.010,.066),'piano',.001)
        for side in (-1,1):
            gold.tube([(x+side*.028,y-.030,.700),(x+side*.028,y-.030,.754)],.0009,5)
            gold.tube([(x-.028,y-.030,.727+side*.027),(x+.028,y-.030,.727+side*.027)],.0009,5)
        rosette(gold,antique,(x,y-.031,.727),.022)
        for yy in (-depth/2+.075,depth/2-.082):turned_foot('Sofa turned foot',sign*(width/2-.095),yy,.128,gold)
    # Loose scatter pillows in the actual catalogue arrangement; no seat seams by seat count.
    if seats==1:
        accents=[(-.16,.162,.595,.326,-.10,-.12)]
    else:
        end=width/2-.285
        accents=[(-end,.192,.609,.350,-.14,-.12),(-end+.29,.155,.611,.354,-.13,.09),
                 (end-.29,.155,.611,.354,-.13,-.09),(end,.192,.609,.350,-.14,.12)]
        if seats==3:accents.extend([(-.41,.202,.615,.346,-.15,.08),(.41,.202,.615,.346,-.15,-.08)])
    for i,(x,y,z,size,rx,rz) in enumerate(accents):
        ob=cushion('Loose champagne scatter cushion '+str(i+1),(x,y,z),(size,.106,size),'cloth_light',
                   rotation=(rx,0,rz),phase=i*1.71,piping='cloth',n=16)
        ob['kind']='styling';ob['not_a_separate_catalogue_sku']=True


def curved_rect(name,points,width,depth,mat):
    """Bent, flattened polished wood member, not a cylindrical pipe."""
    verts=[];faces=[]
    for x,y,z in points:
        verts.extend([(x-width/2,y-depth/2,z),(x+width/2,y-depth/2,z),(x+width/2,y+depth/2,z),(x-width/2,y+depth/2,z)])
    for i in range(len(points)-1):
        for j in range(4):
            q=i*4+j;r=i*4+(j+1)%4;faces.append((q,r,r+4,q+4))
    faces.extend([(3,2,1,0),tuple((len(points)-1)*4+j for j in range(4))])
    ob=c.mesh(name,verts,faces,mat)
    mod=ob.modifiers.new('Rounded polished bentwood edges','BEVEL');mod.width=.003;mod.segments=3
    mod=ob.modifiers.new('Bentwood surface normals','WEIGHTED_NORMAL');mod.keep_sharp=True
    return ob


def shield(name,centre,width,height,mat,gold):
    """Upholstered shield panel with its round lobed sides and pointed base."""
    # Clockwise boundary in the XZ plane.  The rounded shoulder is cut independently
    # from the open bent frame below it, rather than a rectangular chair back.
    outline=[]
    for i in range(25):
        t=i/24;x=-width/2+width*t;z=height/2-.008*math.sin(math.pi*t)
        outline.append((x,z))
    for i in range(1,33):
        t=i/32;outline.append((width/2*max(0,math.cos(t*math.pi/2))**.55,height/2-height*t))
    for i in range(1,33):
        t=i/32;outline.append((-width/2*max(0,math.sin(t*math.pi/2))**.55,-height/2+height*t))
    holder=c.empty(name,centre)
    with parent(holder):
        verts=[];faces=[];uv=[];nr=15;nn=len(outline)
        for side in (-1,1):
            for j in range(nr+1):
                t=j/nr
                for x,z in outline:
                    thickness=.011+.020*(1-t*t)
                    wrinkle=.0013*math.sin(z*83+x*42)*math.exp(-((t-.90)/.11)**2)
                    verts.append((x*t,side*(thickness+wrinkle),z*t));uv.append((x*t,z*t))
        step=(nr+1)*nn
        for side in range(2):
            for j in range(nr):
                for i in range(nn):
                    q=side*step+j*nn+i;r=side*step+j*nn+(i+1)%nn
                    f=(q,r,r+nn,q+nn);faces.append(f if side==0 else tuple(reversed(f)))
        for i in range(nn):
            q=nr*nn+i;r=nr*nn+(i+1)%nn;faces.append((q,q+step,r+step,r))
        c.mesh(name+' | silk shield upholstery',verts,faces,mat,uv,True)
        c.curve(name+' | polished black shield frame',[(x*1.025,.018,z*1.020) for x,z in outline],.0105,'piano',True)
        c.curve(name+' | stitched perimeter welt',[(x,-.013,z) for x,z in outline],.0016,'cloth_light',True)
        # Restrained woven flower geometry is legible at close range. The full
        # damask colour motif comes from the fabric material, not a photo plane.
        embroidery=Batch(name+' | tonal embroidered petal relief','cloth_light')
        for cx,cz,scale in [(0,.071,.020),(-.095,.115,.013),(.095,.115,.013),(0,-.090,.015)]:
            for j in range(8):
                a=TAU*j/8;embroidery.leaf((cx,-.032,cz),(cx+math.cos(a)*scale,-.033,cz+math.sin(a)*scale),scale*.17,(0,-1,0),.0004)
        embroidery.finish()
    return holder


def dining_chair(armchair,gold,antique):
    width=.63 if armchair else .55
    cushion('Blue-grey damask fitted dining seat',(0,-.024,.469),(.516,.496,.100),'nantes_chair_silk',seat=True,piping='cloth_light',phase=.45,n=18)
    c.box('Black polished seat apron',(0,-.015,.407),(.515,.473,.063),'piano',.010)
    for y in (-.252,.222):gold.tube([(-.245,y,.413),(.245,y,.413)],.0013,6)
    for x in (-.252,.252):gold.tube([(x,-.242,.413),(x,.222,.413)],.0013,6)
    for sign in (-1,1):
        turned_foot('Dining chair tapered front leg',sign*.218,-.222,.407,gold,True)
        # Rear feet sweep back, continuing into an open, waisted back upright.
        pts=[]
        for i in range(25):
            t=i/24;z=.012+.935*t
            y=.267-.100*math.sin(t*math.pi)+.003*t
            x=sign*(.220-.075*math.sin(t*math.pi)+.005*t)
            pts.append((x,y,z))
        curved_rect('Swept open black back stile',pts,.038,.034,'piano')
    shield('Shield-shaped blue-grey silk back',(0,.223,.775),.430,.390,'nantes_chair_silk',gold)
    # Three intersecting gilt loops visible in the opening below the shield.
    for x in (-.031,0,.031):oval(gold,(x,.205,.566),(1,0,0),(0,0,1),.029,.035,.0021,28)
    if armchair:
        for sign in (-1,1):
            arm=[]
            for i in range(25):
                t=i/24;arm.append((sign*(.294-.074*t),-.242+.472*t,.649+.056*t+.020*math.sin(math.pi*t)))
            curved_rect('Raised flattened black arm rail',arm,.031,.037,'piano')
            arm_support=[]
            for i in range(20):
                t=i/19;arm_support.append((sign*(.244+.047*t),-.184-.037*math.sin(math.pi*t),.431+.215*t))
            curved_rect('Outward-curved arm support',arm_support,.029,.029,'piano')
            # The front arm top has a small polished gold collar in the source.
            c.box('Arm end polished bronze inset',(sign*.294,-.242,.658),(.026,.018,.008),'bronze',.002)


def tuft_panel(name,origin,width,height,mat,gold):
    """Physically displaced diamond quilt and fabric-covered inset buttons."""
    x0,y0,z0=origin;nu=max(48,round(width/.009));nv=max(56,round(height/.010));pu=.205;pv=.180
    def dep(x,z):
        U=x/pu+.15;V=z/pv+.07;a=U-.5*V;b=U+.5*V
        diamond=abs(math.sin(math.pi*a)*math.sin(math.pi*b))
        row=round(V);col=round(U-.5*row)+.5*row
        du=(U-col)*pu;dv=(V-row)*pv;r=math.hypot(du,dv)
        crease=.0035*(math.exp(-(abs(a-round(a))/.058)**2)+math.exp(-(abs(b-round(b))/.058)**2))
        inset=.014*math.exp(-(r/.024)**2)
        wrinkles=.0018*math.sin(6*math.atan2(dv,du)+x*4)*math.exp(-r/.043)
        edge=max(0,min(x,width-x,z,height-z));taper=min(1,edge/.022);taper=taper*taper*(3-2*taper)
        return (.015+.035*diamond**.72-crease-inset+wrinkles)*taper
    verts=[];faces=[];uv=[]
    for j in range(nv+1):
        z=height*j/nv
        for i in range(nu+1):
            x=width*i/nu;verts.append((x0+x,y0-dep(x,z),z0+z));uv.append((x,z))
    for j in range(nv):
        for i in range(nu):
            q=j*(nu+1)+i;faces.append((q,q+1,q+nu+2,q+nu+1))
    c.mesh(name+' | displaced silk diamond quilting',verts,faces,mat,uv,True)
    buttons=Batch(name+' | actual recessed silk-covered buttons',mat)
    for row in range(math.ceil(height/pv)+1):
        z=(row-.07)*pv
        if not .026<z<height-.026:continue
        for col in range(math.ceil(width/pu)+2):
            x=(col+.5*row-.15)*pu
            if .025<x<width-.025:buttons.sphere((x0+x,y0-dep(x,z)-.001,z0+z),(.0054,.0028,.0054),10,6)
    buttons.finish()
    c.curve(name+' | outer sewn cushion binding',[(x0,y0-.003,z0),(x0+width,y0-.003,z0),(x0+width,y0-.003,z0+height),(x0,y0-.003,z0+height)],.0022,'cloth_gold',True)


def ribbed_stile(name,x,y,z,width,height,gold):
    c.box(name+' | black field',(x,y,z),(width,.035,height),'piano',.001)
    for j in range(max(2,round(width/.005))):
        xx=x-width*.43+width*.86*j/max(1,round(width/.005)-1)
        gold.tube([(xx,y-.021,z-height/2+.002),(xx,y-.021,z+height/2-.002)],.0012,5)


def bed(gold,antique):
    # Exact 218cm frame; a tall headboard with two padded champagne fields.
    c.box('Full headboard black structural backing',(0,1.031,.785),(2.180,.118,1.570),'piano',.008)
    c.box('Stepped upper headboard crest',(0,1.028,1.566),(1.974,.130,.061),'piano',.012)
    gold.tube([(-1.087,.958,1.568),(-1.015,.958,1.568),(-.971,.958,1.600),(.971,.958,1.600),(1.015,.958,1.568),(1.087,.958,1.568)],.0019,6)
    for x in (-1.045,1.045):
        c.box('Long headboard black border post',(x,.950,.785),(.085,.060,1.535),'piano',.002)
        for dx in (-.036,.036):gold.tube([(x+dx,.916,.035),(x+dx,.916,1.530)],.0013,6)
        chain(gold,(x,.916,.055),(x,.916,1.445),(0,-1,0),.043,.037,.00125)
        c.box('Square headboard gilt-rosette block',(x,.912,1.489),(.071,.014,.071),'piano',.001)
        rosette(gold,antique,(x,.903,1.489),.024)
    for x0 in (-.999,.049):
        c.box('Champagne headboard padded support',(x0+.475,.947,.867),(.948,.039,1.168),'cloth',.005)
        tuft_panel('Twin champagne headboard field',(x0,.920,.283),.948,1.167,'cloth',gold)
    ribbed_stile('Centre fluted gilt headboard division',0,.925,.902,.082,1.218,gold)
    c.box('Headboard straight top marquetry rail',(0,.933,1.485),(2.073,.043,.088),'piano',.002)
    for a,b in [(-.993,-.056),(.056,.993)]:
        chain(gold,(a,.906,1.484),(b,.906,1.484),(0,-1,0),.037,.029,.00115)
        for z in (1.456,1.513):gold.tube([(a,.904,z),(b,.904,z)],.0012,5)
    # Foot/side rails show oak burl, while the lower scalloped plinth is black.
    for sign in (-1,1):
        c.box('Long bookmatched oak-burl side rail',(sign*1.018,-.026,.281),(.124,2.067,.197),'wood',.006)
        c.box('Black lower bed side plinth',(sign*1.028,-.026,.160),(.102,2.082,.084),'piano',.004)
        gold.tube([(sign*1.083,-1.065,.124),(sign*1.083,.998,.124)],.0014,6)
        for yy in (-1.025,.984):turned_foot('Bed short turned foot',sign*1.006,yy,.132,gold)
    c.box('Broad oak-burl low footboard',(0,-1.035,.283),(2.170,.105,.195),'wood',.005)
    c.box('Raised polished footboard top lip',(0,-1.047,.389),(2.180,.123,.024),'wood_dark',.003)
    apron('Low footboard scalloped plinth',2.175,2.18,.157,.092,gold,antique,False)
    c.box('Internal slat support',(0,-.015,.290),(1.949,1.935,.059),'inside',.002)
    for i in range(15):c.box('Individual bed slat '+str(i+1),(0,-.88+i*.125,.335),(1.952,.085,.025),'inside',.002)
    # Bedding is decor, not a catalogue upholstery mechanism; no maker logo.
    styling=c.empty('Removable reference-inspired bed textiles',props={'kind':'styling','not_a_separate_catalogue_sku':True,'construction_note':'Decorative bedding interpretation; no manufacturer logo.'})
    with parent(styling):
        cushion('Ivory upholstered mattress',(0,-.006,.440),(1.981,1.980,.205),'ivory',seat=True,softness=.5,n=22)
        cushion('Thick ivory duvet with gathered edges',(0,-.133,.534),(2.005,1.715,.210),'ivory',seat=True,softness=2.1,n=30)
        # Continuous folded coverlet surface follows the duvet rather than floating.
        vv=[];ff=[];uv=[];nx=78;ny=44
        def cover_point(qx,qy):
            # Match the duvet's actual superellipsoid top patch.  A rectangular
            # plane at constant height intersects the puffy duvet (white spots),
            # so use its very same curved surface and add a small cloth offset.
            den=(abs(qx)**10+abs(qy)**10+1)**.1
            x=1.0025*qx/den;y=-.133+.8575*qy/den
            edge=math.exp(-((abs(qy)-.86)/.17)**2)
            z=.534+.105/den+abs(.0063*math.sin(qx*37+math.sin(qx*11))*edge)-.0063*(1-qx*qx)*(1-qy*qy)
            if abs(qy)>.99:z+=.00273*math.sin(qx*59+4)
            z+=.0065+.0008*math.sin(qx*27+qy*8)
            return (x,y,z)
        for j in range(ny+1):
            qy=-1+1.10*j/ny
            for i in range(nx+1):
                qx=-1+2*i/nx;p=cover_point(qx,qy)
                vv.append(p);uv.append((p[0],p[1]))
        for j in range(ny):
            for i in range(nx):
                q=j*(nx+1)+i;ff.append((q,q+1,q+nx+2,q+nx+1))
        cover=c.mesh('Chocolate-taupe woven bed coverlet with real folds',vv,ff,'nantes_bed_taupe',uv,True)
        solid=cover.modifiers.new('Coverlet fabric thickness','SOLIDIFY');solid.thickness=.002
        for qy in (-1,.10):c.curve('Coverlet stitched end hem',[cover_point(-1+2*i/80,qy) for i in range(81)],.0011,'stitch')
        # Three large cream pillows, thin chocolate bands, then two dark lumbar cushions.
        for i,x in enumerate((-.590,0,.590)):
            p=cushion('Striped ivory sleeping pillow '+str(i+1),(x,.619,.787),(.611,.148,.442),'ivory',rotation=(-.18,0,(-.04 if x<0 else .04)),phase=i*1.4,n=18)
            with parent(p):
                for xx in (-.232,-.200):
                    c.box('Physical taupe woven pillow stripe',(xx,-.083,.012),(.014,.002,.340),'nantes_bed_stripe',.0005)
        for i,x in enumerate((-.561,.561)):
            p=cushion('Dark lumbar accent pillow '+str(i+1),(x,.354,.707),(.568,.135,.249),'nantes_bed_dark',rotation=(-.12,0,(-.06 if x<0 else .06)),phase=i*2.6,n=18)
            with parent(p):
                for xx in (-.180,.180):c.box('Taupe lumbar end-band',(xx,-.076,.001),(.050,.002,.202),'nantes_bed_stripe',.0005)
        cushion('Plain central dark silk cushion — no logo',(0,.410,.810),(.448,.131,.359),'nantes_bed_dark',rotation=(-.14,0,.03),phase=2,n=18)


def bedroom_seat(width,depth,height,stool,gold,antique):
    if stool:
        legheight=.105;apronz=.143;apronh=.107
        cushion('Square stool upholstered body',(0,0,.301),(width-.012,depth-.012,.255),'cloth_light',seat=True,phase=1.5,n=20)
        # A horizontal upholstered seam divides the two softly padded side bands.
        c.curve('Stool horizontal continuous sewn seam',[(x,y,.296) for x,y in [(-.261,-.261),(.261,-.261),(.261,.261),(-.261,.261)]],.0016,'cloth',True)
    else:
        legheight=.295;apronz=.337;apronh=.080
        cushion('One-piece champagne bench cushion',(0,0,.438),(width-.012,depth-.012,.164),'cloth_light',seat=True,phase=.45,n=22)
        c.curve('Bench lower tailored textile seam',[(x,y,.371) for x,y in [(-width/2+.015,-depth/2+.015),(width/2-.015,-depth/2+.015),(width/2-.015,depth/2-.015),(-width/2+.015,depth/2-.015)]],.0015,'cloth',True)
    c.box('Solid black seat support',(0,0,apronz+.012),(width-.020,depth-.020,.071),'piano',.006)
    apron('Bedroom seat front frieze',width-.006,depth-.006,apronz,apronh,gold,antique,not stool)
    for sign in (-1,1):
        x=sign*(width/2-.055)
        for y in (-depth/2+.055,depth/2-.055):turned_foot('Bedroom seat turned leg',x,y,legheight,gold,not stool)
        # Side aprons remain black with the source's delicate gold lower edge.
        c.box('Side black bench/stool apron',(sign*(width/2-.025),0,apronz),(.038,depth-.034,apronh),'piano',.004)
        gold.tube([(sign*(width/2-.004),-depth/2+.02,apronz-apronh/2),(sign*(width/2-.004),depth/2-.02,apronz-apronh/2)],.0014,6)
    c.box('Rear black seat apron',(0,depth/2-.022,apronz),(width-.045,.035,apronh),'piano',.004)
    gold.tube([(-width/2+.02,depth/2-.003,apronz-apronh/2),(width/2-.02,depth/2-.003,apronz-apronh/2)],.0014,6)


def normalize(root,body,target):
    """Convert editable cords, then measure actual evaluated vertices, not boxes."""
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get()
    for ob in list(root.children_recursive):
        if ob.type!='CURVE':continue
        data=bpy.data.meshes.new_from_object(ob.evaluated_get(graph))
        result=bpy.data.objects.new(ob.name+' | editable cord mesh',data);bpy.context.scene.collection.objects.link(result)
        result.parent=ob.parent;result.matrix_basis=ob.matrix_basis.copy()
        for p in data.polygons:p.use_smooth=True
        old=ob.data;bpy.data.objects.remove(ob,do_unlink=True)
        if not old.users:bpy.data.curves.remove(old)
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get();inv=root.matrix_world.inverted();points=[]
    for ob in root.children_recursive:
        if ob.type!='MESH':continue
        ev=ob.evaluated_get(graph);points.extend(inv@ev.matrix_world@v.co for v in ev.data.vertices)
    lo=[min(p[k] for p in points) for k in range(3)];hi=[max(p[k] for p in points) for k in range(3)]
    scale=[target[k]/(hi[k]-lo[k]) for k in range(3)];body.scale=scale
    body.location=(-(lo[0]+hi[0])*scale[0]/2,-(lo[1]+hi[1])*scale[1]/2,-lo[2]*scale[2])
    root['catalogue_bounds_normalized']=True
    root['construction_note']='Editable reference-based visual reconstruction; unshown construction interpreted; not manufacturer CAD.'
    root['normalization_scale']=scale
    bpy.context.view_layer.update()


def create(sku,instance='main'):
    sku=str(sku);width,depth,height,family,count,title=SPECS[sku];materials()
    printed='66-67' if family=='sofa' else '198-199' if family=='chair' else '244-247'
    root=c.empty(f'{title} | {sku} | {instance}',props={
      'kind':'product','product_id':sku,'instance_id':instance,'name':title,
      'dimensions_mm':[round(v*1000) for v in (width,depth,height)],
      'catalogue_dimensions_mm':[round(v*1000) for v in (width,depth,height)],
      'catalogue_reference':'MARINER NANTES printed pages '+printed,
      'finish':'NAN. / OF (544 / 55)' if family not in ('chair','stool') else 'NAN. (544)',
      'fabric_reference':'241.186 / 241.184' if family=='sofa' else '241.185' if family=='chair' else '243.135',
      'mechanisms':'Fixed; no unsupported articulation',
      'materials_declared':'Oak burl veneer, sycamore inlays and cast bronze',
    })
    if family=='sofa':
        root['seat_count']=count;root['seat_cushions']=1
        root['exterior_back']='Continuous curved oak-burl U shell with real marquetry borders'
        root['source_image_note']='Printed three-seat photograph shared for 50375.0/50376.0; two-seat rebuilt to its separately printed 1800mm width.' if count==2 else 'Reference reconstructed from the separately shown front and rear views.'
    with parent(root):body=c.empty('Exact metric editable Nantes upholstery geometry')
    with parent(body):
        gold=Batch('Solid gilt ring marquetry, flutes and fine edge detail','gold')
        antique=Batch('Cast bronze petal rosettes and laurel relief','antique_gold')
        if family=='sofa':sofa(width,depth,count,gold,antique)
        elif family=='chair':dining_chair(bool(count),gold,antique)
        elif family=='bed':bed(gold,antique)
        else:bedroom_seat(width,depth,height,family=='stool',gold,antique)
        gold.finish();antique.finish()
    normalize(root,body,(width,depth,height))
    return root
