"""Isolated Nantes casegoods bounds/native geometry QA; no shared texture writes."""
import json
import hashlib
import sys
from pathlib import Path
import bpy
from mathutils import Vector

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import core as c
import casegoods
SOURCE_SHA256 = hashlib.sha256((BASE/'casegoods.py').read_bytes()).hexdigest()

bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
palette = {
    'wood': ((.24,.095,.025), .22, 0), 'wood_dark': ((.045,.023,.009), .25, 0),
    'inside': ((.18,.068,.016), .32, 0), 'piano': ((.005,.004,.003), .17, 0),
    'black': ((.009,.01,.01), .23, .08), 'gold': ((.59,.37,.10), .27, .85),
    'antique_gold': ((.42,.23,.055), .31, .80), 'bronze': ((.28,.15,.04), .34,.82),
    'brass': ((.50,.32,.09), .30,.86), 'ivory': ((.67,.57,.37), .28,0),
    'mirror': ((.92,.94,.95), .035,1), 'glass': ((.91,.94,.91), .035,0),
    'stone': ((.22,.23,.22), .56,0),
}
for key, (rgb, rough, metal) in palette.items():
    c.M[key] = c.material('Nantes isolated QA | '+key, rgb, rough, metal)
    if key in ('wood','piano'):
        c.M[key].node_tree.nodes['Principled BSDF'].inputs['Coat Weight'].default_value = .40
bs = c.M['glass'].node_tree.nodes['Principled BSDF']
bs.inputs['Transmission Weight'].default_value = 1
bs.inputs['IOR'].default_value = 1.46

report, products = [], {}
for sku in casegoods.SPECS:
    previous = c.PARENT
    root = casegoods.create(sku, 'audit')
    assert c.PARENT == previous, 'Caller parent not restored'
    bpy.context.view_layer.update()
    dg = bpy.context.evaluated_depsgraph_get()
    points, triangles, meshes, invalid = [], 0, 0, 0
    for ob in root.children_recursive:
        if ob.type != 'MESH':
            continue
        eo = ob.evaluated_get(dg)
        me = eo.to_mesh()
        points.extend(eo.matrix_world @ v.co for v in me.vertices)
        me.calc_loop_triangles()
        triangles += len(me.loop_triangles)
        invalid += sum(1 for v in me.vertices if not all(abs(q)<100 for q in v.co))
        meshes += 1
        eo.to_mesh_clear()
    lo = [min(p[k] for p in points) for k in range(3)]
    hi = [max(p[k] for p in points) for k in range(3)]
    dims = [(hi[k]-lo[k])*1000 for k in range(3)]
    expected = list(casegoods.SPECS[sku][1])
    error = [round(dims[k]-expected[k],6) for k in range(3)]
    item = {'sku':sku,'dimensions_mm':dims,'expected_mm':expected,'error_mm':error,
            'bounds_m':[lo,hi],'triangles':triangles,'mesh_count':meshes,'invalid_vertices':invalid,
            'parent_restored':True,'floor_bottom':abs(lo[2])<.0002,
            'pass':max(abs(v) for v in error)<=3 and triangles<160000 and not invalid}
    report.append(item)
    products[sku] = root
result = {'source_sha256':SOURCE_SHA256, 'products':report, 'triangle_total':sum(q['triangles'] for q in report),
          'pass':all(q['pass'] for q in report)}
(BASE/'casegoods-audit.json').write_text(json.dumps(result,indent=2))
print('NANTES_CASEGOODS_AUDIT '+json.dumps(result),flush=True)
assert result['pass'], 'See casegoods-audit.json'

if '--render' in sys.argv:
    c.set_parent(None)
    c.box('Isolated QA floor', (0,0,-.025), (100,100,.05), 'stone', .001)
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 20
    scene.cycles.use_denoising = True
    scene.render.resolution_x = 1800
    scene.render.resolution_y = 1400
    scene.render.resolution_percentage = 100
    scene.world.color = (.11,.11,.11)
    scene.view_settings.look = 'AgX - Medium High Contrast'
    c.light('QA left softbox', 'AREA', (-3,-4,5), 850, (1,.88,.72), (0,0,.7), 4)
    c.light('QA right softbox', 'AREA', (4,0,4), 700, (.83,.91,1), (0,0,.7), 3.5)
    c.light('QA edge light', 'AREA', (0,4,5), 1000, (1,.93,.82), (0,0,.7), 3)
    data = bpy.data.cameras.new('Isolated casegoods QA camera')
    cam = c.link(bpy.data.objects.new('Isolated casegoods QA camera',data))
    data.type = 'ORTHO'
    scene.camera = cam
    scene.render.image_settings.file_format = 'PNG'
    def view(name, placements, position, target, scale):
        for sku, root in products.items():
            root.location = placements.get(sku,(0,0,0))
            for ob in root.children_recursive:
                ob.hide_render = sku not in placements
        cam.location = position
        cam.rotation_euler = (Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler()
        data.ortho_scale = scale
        scene.render.filepath = str(BASE/(name+'.png'))
        bpy.ops.render.render(write_still=True)
    view('casegoods-tables-preview', {'50378.0':(-1.0,-.6,0),'50379.0':(1.0,-.3,0),'50347.0':(0,1.0,0)},
         (4.8,-6.8,4.8),(0,.1,.37),4.3)
    view('casegoods-dining-preview', {'50339.0':(-1.3,0,0),'50340.0':(1.5,.0,0)},
         (4.5,-6.5,4.0),(0,0,.45),5.3)
    view('casegoods-storage-preview', {'50343.0':(-1.50,.5,0),'50341.0':(.80,0,0),'50342.0':(.80,.18,1.12)},
         (4.2,-7.3,3.7),(0,0,1.12),4.6)
    view('casegoods-bedroom-preview', {'50383.0':(-.85,.3,0),'50348.0':(-.85,.46,.87),
          '50382.0':(1.15,-.30,0),'50386.0':(1.35,.70,0)},
         (4.3,-7.0,3.7),(0,.2,.90),4.2)
    view('casegoods-tv-commode-preview', {'50380.0':(-1.25,.4,0),'50361.0':(1.0,.1,0)},
         (3.5,-6.5,3.4),(0,.1,.48),5.0)
    print('NANTES_CASEGOODS_PREVIEWS_DONE',flush=True)
