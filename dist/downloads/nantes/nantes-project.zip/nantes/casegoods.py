"""NANTES casegoods -- independently authored, editable metric reconstruction.

Reference: MARINER CLASSIC_FURNITURE_CATALOG_2023, PDF pages 35, 99--101,
123--124. Oak-burl veneer, sycamore inlays and cast bronze; NAN/OF(544/55).
The photographed collection is Empire/Neoclassical, with rectilinear casework,
black lacquer frames, interlaced oval castings, fluted gilt collars and figured
wood. It is not generic bombé Louis-XV furniture. Photographic observations,
not manufacturer's CAD or calibrated finishes. Hidden joinery is interpreted.

API: create(sku, instance='main'). Metres, X width, Y depth, front -Y, Z up.
All relief, lattice loops, fluting and mirror surrounds are physical geometry.
No catalogue image is used as a geometry substitute. Mirrors bottom-centred.
"""
import math
from contextlib import contextmanager
from mathutils import Vector
import core as c

TAU = math.tau
SPECS = {
    '50378.0': ('Nantes glass-inset coffee table', (1300, 1300, 470)),
    '50379.0': ('Nantes side table', (700, 700, 650)),
    '50380.0': ('Nantes television furniture', (2190, 480, 760)),
    '50339.0': ('Nantes twin-pedestal dining table', (2500, 1300, 760)),
    '50340.0': ('Nantes round dining table with Lazy Susan', (1600, 1600, 810)),
    '50341.0': ('Nantes four-door sideboard', (2390, 520, 990)),
    '50342.0': ('Nantes wide landscape mirror', (2100, 60, 1060)),
    '50343.0': ('Nantes two-door glass display cabinet', (1590, 500, 2180)),
    '50347.0': ('Nantes console with curved low stretcher', (1690, 460, 910)),
    '50348.0': ('Nantes portrait mirror', (940, 60, 1040)),
    '50361.0': ('Nantes two-door commode', (1640, 530, 960)),
    '50382.0': ('Nantes three-drawer night table', (780, 450, 790)),
    '50383.0': ('Nantes dressing table', (2100, 480, 800)),
    '50386.0': ('Nantes five-drawer chest', (780, 450, 1340)),
}


@contextmanager
def parent_to(ob):
    previous = c.PARENT
    c.set_parent(ob)
    try:
        yield
    finally:
        c.set_parent(previous)


def bezier(a, b, d, e, steps=16):
    return [tuple((1-t)**3*a[k]+3*(1-t)**2*t*b[k]+3*(1-t)*t*t*d[k]+t**3*e[k]
                  for k in range(len(a))) for t in [j/steps for j in range(steps+1)]]


class Relief:
    """Repeated cast detail batched by material, avoiding thousands of objects."""
    def __init__(self):
        self.data = {}

    def part(self, mat):
        return self.data.setdefault(mat, [[], []])

    def tube(self, points, radius, mat='gold', sides=5, closed=False):
        points = [Vector(p) for p in points]
        if len(points) < 2:
            return
        if closed:
            points.append(points[0])
        verts, faces = self.part(mat)
        base, old_u = len(verts), None
        for j, p in enumerate(points):
            t = points[min(j+1, len(points)-1)]-points[max(j-1, 0)]
            if t.length < 1e-9:
                t = Vector((0, 0, 1))
            t.normalize()
            ref = Vector((0, 0, 1)) if abs(t.z) < .94 else Vector((1, 0, 0))
            u = t.cross(ref).normalized()
            if old_u is not None and old_u.dot(u) < 0:
                u.negate()
            v = t.cross(u).normalized()
            old_u = u
            for k in range(sides):
                a = TAU*k/sides
                verts.append(tuple(p+u*radius*math.cos(a)+v*radius*math.sin(a)))
        for j in range(len(points)-1):
            for k in range(sides):
                q, r = base+j*sides+k, base+j*sides+(k+1) % sides
                faces.append((q, r, r+sides, q+sides))
        faces.append(tuple(base+k for k in reversed(range(sides))))
        last = base+(len(points)-1)*sides
        faces.append(tuple(last+k for k in range(sides)))

    def bead(self, pos, radius, mat='gold', seg=6, rings=3):
        verts, faces = self.part(mat)
        base = len(verts)
        for j in range(rings+1):
            t = math.pi*j/rings
            for k in range(seg):
                a = TAU*k/seg
                verts.append((pos[0]+radius*math.sin(t)*math.cos(a),
                              pos[1]+radius*math.sin(t)*math.sin(a),
                              pos[2]+radius*math.cos(t)))
        for j in range(rings):
            for k in range(seg):
                q, r = base+j*seg+k, base+j*seg+(k+1) % seg
                faces.append((q, r, r+seg, q+seg))

    def leaf(self, mapping, path, width=.009, mat='gold', depth=.003):
        verts, faces = self.part(mat)
        base = len(verts)
        n = len(path)
        for rear in (False, True):
            for j, (u, v) in enumerate(path):
                t = j/(n-1)
                a, b = path[max(j-1, 0)], path[min(j+1, n-1)]
                dx, dy = b[0]-a[0], b[1]-a[1]
                length = max(1e-9, math.hypot(dx, dy))
                spread = max(.00006, width*math.sin(math.pi*t)**.85)
                for k in range(3):
                    s = k-1
                    r = -.0003 if rear else depth*(1-.6*s*s)*math.sin(math.pi*t)+.0002
                    verts.append(mapping(u-s*dy/length*spread, v+s*dx/length*spread, r))
        for j in range(n-1):
            for k in range(2):
                q = base+j*3+k
                faces.extend([(q, q+3, q+4, q+1),
                              (q+3*n+1, q+3*n+4, q+3*n+3, q+3*n)])
            q = base+j*3
            faces.extend([(q, q+3*n, q+3*n+3, q+3),
                          (q+2, q+5, q+3*n+5, q+3*n+2)])
        faces.extend([(base, base+1, base+2, base+3*n+2, base+3*n+1, base+3*n),
                      tuple(base+3*(n-1)+k for k in (0, 3*n, 3*n+1, 3*n+2, 2, 1))])
        self.tube([mapping(u, v, depth*math.sin(math.pi*j/(n-1))+.0009)
                   for j, (u, v) in enumerate(path)], .00065, mat, 4)

    def finish(self, name):
        return [c.mesh(name+' | '+mat+' relief', verts, faces, mat, smooth=True)
                for mat, (verts, faces) in self.data.items() if verts]


def rect(w, d, r=.006, steps=5):
    """CCW rounded rectangle with exact extrema."""
    pts = []
    for x, y, a0 in ((w/2-r, d/2-r, 0), (-w/2+r, d/2-r, math.pi/2),
                     (-w/2+r, -d/2+r, math.pi), (w/2-r, -d/2+r, 3*math.pi/2)):
        for j in range(steps+1):
            a = a0+j*math.pi/(2*steps)
            pts.append((x+r*math.cos(a), y+r*math.sin(a)))
    return pts


def circle(r, samples=112):
    return [(r*math.cos(TAU*j/samples), r*math.sin(TAU*j/samples)) for j in range(samples)]


def prism(name, path, z0, z1, mat, bevel=.001):
    edge = min(bevel, (z1-z0)/4)
    w = max(abs(x) for x, y in path)*2
    d = max(abs(y) for x, y in path)*2
    rings = [(1-2*edge/w, 1-2*edge/d, z0), (1, 1, z0+edge),
             (1, 1, z1-edge), (1-2*edge/w, 1-2*edge/d, z1)]
    verts = [(x*sx, y*sy, z) for sx, sy, z in rings for x, y in path]
    n, faces = len(path), []
    for j in range(3):
        for k in range(n):
            q = j*n+k
            faces.append((q, j*n+(k+1) % n, (j+1)*n+(k+1) % n, q+n))
    faces.extend([tuple(reversed(range(n))), tuple(3*n+k for k in range(n))])
    ob = c.mesh(name, verts, faces, mat)
    return ob


def xz_prism(name, path, front, back, mat):
    """CCW 2D X/Z outline, solid with actual front and rear surfaces."""
    n = len(path)
    verts = [(x, y, z) for y in (front, back) for x, z in path]
    faces = [tuple(range(n)), tuple(n+k for k in reversed(range(n)))]
    for k in range(n):
        j = (k+1) % n
        faces.append((k, n+k, n+j, j))
    return c.mesh(name, verts, faces, mat)


def ring(rel, mapping, w, h, radius=.0011, mat='gold', cx=0, cy=0):
    rel.tube([mapping(x+cx, z+cy, 0) for x, z in rect(w, h, min(.003, w/6, h/6), 3)], radius, mat, 5, True)


def rosette(rel, mapping, radius=.017, petals=10):
    for k in range(petals):
        a = TAU*k/petals
        path = [(radius*t*math.cos(a+.12*math.sin(math.pi*t)),
                 radius*t*math.sin(a+.12*math.sin(math.pi*t))) for t in (0, .2, .4, .65, .85, 1)]
        rel.leaf(mapping, path, radius*.24, 'gold', radius*.22)
    for r in (.30*radius, .91*radius, 1.10*radius):
        rel.tube([mapping(r*math.cos(TAU*j/32), r*math.sin(TAU*j/32), .0007) for j in range(32)],
                 max(.0005, radius*.047), 'antique_gold', 5, True)
    rel.bead(mapping(0, 0, radius*.18), radius*.18, 'bronze')


def corner(rel, mapping, size=.070):
    # Inlaid double-square medallion, a hallmark of the Nantes frames.
    ring(rel, mapping, size-.006, size-.006, .0012, 'ivory')
    ring(rel, mapping, size-.014, size-.014, .0009, 'gold')
    rosette(rel, mapping, size*.245, 10)


def lattice(rel, mapping, length, height, pitch=.025, radius=.00085, jewels=True):
    """Interlaced elongated gilt ovals on the photographed black frieze."""
    margin = .008
    n = max(2, round((length-2*margin)/pitch))
    pitch = (length-2*margin)/n
    rx, ry = pitch*.68, height*.40
    for j in range(n):
        u = -length/2+margin+(j+.5)*pitch
        rel.tube([mapping(u+rx*math.cos(TAU*k/18), ry*math.sin(TAU*k/18), .0009)
                  for k in range(18)], radius, 'gold', 5, True)
        if jewels:
            rel.bead(mapping(u, 0, .0020), min(.0037, height*.10), 'wood', 6, 3)
    for z in (-height*.49, height*.49):
        rel.tube([mapping(-length/2, z, .0002), mapping(length/2, z, .0002)], .0011, 'gold', 5)


def front_map(x, y, z):
    return lambda u, v, r: (x+u, y-r, z+v)


def horizontal_map(x, y, z):
    return lambda u, v, r: (x+u, y+v, z+r)


def side_map(x, y, z, sign):
    return lambda u, v, r: (x+sign*r, y+u, z+v)


def fluted_panel(rel, mapping, w, h, count=None, mat='gold'):
    count = count or max(4, round(w/.006))
    for j in range(count):
        u = -w/2+(j+.5)*w/count
        rel.tube([mapping(u, -h/2+.002, .001), mapping(u, h/2-.002, .001)],
                 min(.0018, w/count*.29), mat, 6)
    ring(rel, mapping, w, h, .001, 'antique_gold')


def collar(rel, x, y, z, r=.038, height=.036, ribs=24):
    """Gadrooned bronze onion collar, not an untextured sphere."""
    verts, faces = rel.part('gold')
    base, sides, rings = len(verts), ribs*2, 9
    for j in range(rings+1):
        t = j/rings
        radius = r*(.48+.52*math.sin(math.pi*t)**.7)
        for k in range(sides):
            a = TAU*k/sides
            rr = radius*(1+.065*math.cos(ribs*a))
            verts.append((x+rr*math.cos(a), y+rr*math.sin(a), z+height*t))
    for j in range(rings):
        for k in range(sides):
            q, p = base+j*sides+k, base+j*sides+(k+1) % sides
            faces.append((q, p, p+sides, q+sides))
    faces.extend([tuple(base+k for k in reversed(range(sides))),
                  tuple(base+rings*sides+k for k in range(sides))])
    for zz in (z+.001, z+height-.001):
        rr = r*.51
        rel.tube([(x+rr*math.cos(TAU*k/32), y+rr*math.sin(TAU*k/32), zz) for k in range(32)],
                 .0012, 'antique_gold', 5, True)


def short_foot(rel, x, y, height=.105, radius=.038):
    c.lathe('Black turned short bun foot', (x, y, 0),
            [(0, 0), (.015, 0), (.020, .006), (.015, .015), (.017, height*.30),
             (.024, height*.43), (.022, height*.52), (.023, height*.72), (0, height*.72)],
            'piano', 32)
    collar(rel, x, y, height*.55, radius, height*.36)
    c.lathe('Gilt foot neck and square-case socket', (x, y, 0),
            [(0, height*.87), (.021, height*.87), (.024, height*.92), (.026, height), (0, height)],
            'antique_gold', 28)


def tall_leg(rel, x, y, h, radius=.029):
    # Long tapered black legs and characteristic gilt fluted upper collars.
    c.lathe('Tapered ebonised Empire leg', (x, y, 0),
            [(0, 0), (.008, 0), (.012, .012), (.010, .023), (.013, .044),
             (.016, h*.25), (radius*.79, h*.70), (radius, h*.87),
             (radius*.82, h*.97), (0, h*.97)], 'piano', 32)
    collar(rel, x, y, h*.85, radius*1.10, h*.12)
    for zz, rr in ((.034, .012), (h*.98, radius*.82)):
        rel.tube([(x+rr*math.cos(TAU*k/28), y+rr*math.sin(TAU*k/28), zz) for k in range(28)],
                 .001, 'gold', 5, True)


def concave_shelf(w, d, inset=.045):
    """Four concave sides and rounded corners, photographed on low shelves."""
    a, b, r = w/2, d/2, .018
    path = []
    # CCW, each long side bows towards the centre rather than bulging out.
    path += bezier((a-r, -b), (a*.40, -b+inset), (-a*.40, -b+inset), (-a+r, -b), 16)
    path += bezier((-a+r, -b), (-a, -b), (-a, -b+r), (-a, -b+r), 4)[1:]
    path += bezier((-a, -b+r), (-a+inset, -b*.4), (-a+inset, b*.4), (-a, b-r), 12)[1:]
    path += bezier((-a, b-r), (-a, b), (-a+r, b), (-a+r, b), 4)[1:]
    path += bezier((-a+r, b), (-a*.4, b-inset), (a*.4, b-inset), (a-r, b), 16)[1:]
    path += bezier((a-r, b), (a, b), (a, b-r), (a, b-r), 4)[1:]
    path += bezier((a, b-r), (a-inset, b*.4), (a-inset, -b*.4), (a, -b+r), 12)[1:]
    path += bezier((a, -b+r), (a, -b), (a-r, -b), (a-r, -b), 4)[1:]
    return list(reversed(path))


def tabletop(rel, w, d, h, glass=False):
    z0 = h-.033
    if glass:
        border = .125
        # Open-centred real timber frame, separate clear inset glass sheet.
        for y in (-d/2+border/2, d/2-border/2):
            c.box('Burl coffee-top front or rear frame', (0, y, (z0+h)/2), (w, border, h-z0), 'wood', .002)
        for x in (-w/2+border/2, w/2-border/2):
            c.box('Burl coffee-top side frame', (x, 0, (z0+h)/2), (border, d-2*border, h-z0), 'wood', .002)
        c.box('Real inset transparent coffee-table glass', (0, 0, h-.013), (w-2*border, d-2*border, .010), 'glass', .0006)
        for inset, mat in ((.012, 'piano'), (.028, 'gold'), (border-.006, 'piano')):
            rel.tube([(x, y, h+.00015) for x, y in rect(w-2*inset, d-2*inset, .003)],
                     .0012 if mat == 'piano' else .0008, mat, 5, True)
    else:
        prism('Polished oak-burl tabletop', rect(w, d), z0, h, 'wood', .002)
        for inset, mat in ((.012, 'piano'), (.025, 'ivory'), (.030, 'piano')):
            rel.tube([(x, y, h+.00015) for x, y in rect(w-2*inset, d-2*inset, .003)],
                     .0011 if mat != 'ivory' else .00075, mat, 5, True)
    # Tiny black lower reveal under the polished wood edge.
    # Coffee frame stays open; four separate underframe rails avoid filling glass.
    if glass:
        for y in (-d/2+.022, d/2-.022):
            c.box('Coffee top ebonised edge reveal', (0, y, z0+.002), (w-.004, .038, .006), 'piano', .0005)
        for x in (-w/2+.022, w/2-.022):
            c.box('Coffee top ebonised side reveal', (x, 0, z0+.002), (.038, d-.004, .006), 'piano', .0005)
    else:
        prism('Ebonised tabletop under-edge', rect(w-.005, d-.005), z0-.005, z0+.001, 'piano', .0006)


def table_friezes(rel, w, d, h, fh=.077, center_block=False):
    corner_size = min(.075, fh)
    fy = d/2-.016
    z = h-.033-fh/2
    for sign in (-1, 1):
        y = sign*fy
        c.box('Black long table frieze', (0, y+(-sign)*.012, z), (w-.032, .035, fh), 'piano', .001)
        mapping = (lambda u, v, r, y=y, sign=sign: (u, y+sign*(r+.008), z+v))
        if center_block:
            block = .077
            for sx in (-1, 1):
                width = (w-2*corner_size-block)/2
                cx = sx*(width/2+block/2)
                lattice(rel, lambda u, v, r, cx=cx: mapping(u+cx, v, r), width-.006, fh*.73)
            fluted_panel(rel, mapping, block-.012, fh-.012)
        else:
            lattice(rel, mapping, w-2*corner_size-.015, fh*.73)
        for x in (-w/2+corner_size/2+.011, w/2-corner_size/2-.011):
            corner(rel, lambda u, v, r, x=x: mapping(x+u, v, r), corner_size-.006)
    for sign in (-1, 1):
        x = sign*(w/2-.016)
        c.box('Black side table frieze', (x-sign*.012, 0, z), (.035, d-.032, fh), 'piano', .001)
        mapping = lambda u, v, r, x=x, sign=sign: (x+sign*(r+.008), u, z+v)
        lattice(rel, mapping, d-2*corner_size-.015, fh*.73)
        for y in (-d/2+corner_size/2+.011, d/2-corner_size/2-.011):
            corner(rel, lambda u, v, r, y=y: mapping(y+u, v, r), corner_size-.006)


def occasional_table(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    rel = Relief()
    console = sku == '50347.0'
    glass = sku == '50378.0'
    fh = .081 if console else .077
    leg_h = h-.033-fh+.008
    for x in (-w/2+.058, w/2-.058):
        for y in (-d/2+.058, d/2-.058):
            tall_leg(rel, x, y, leg_h, .025 if glass else .029)
    table_friezes(rel, w, d, h, fh, glass or console)
    tabletop(rel, w, d, h, glass)
    if not console:
        path = concave_shelf(w-.047, d-.047, .040 if glass else .043)
        prism('Concave-edge figured-oak lower shelf', path, .078, .101, 'wood', .0016)
        rel.tube([(x, y, .099) for x, y in path], .0020, 'piano', 5, True)
        rel.tube([(x*.991, y*.991, .1005) for x, y in path], .0009, 'gold', 5, True)
    else:
        # Photograph shows an open curved stretcher, not a solid low shelf.
        a = w/2-.060
        for sign in (-1, 1):
            path = bezier((-a, sign*(d/2-.058)), (-a*.55, sign*.005),
                          (a*.55, sign*.005), (a, sign*(d/2-.058)), 34)
            strip_w = .027
            points = [(x, y-strip_w/2) for x, y in path]+[(x, y+strip_w/2) for x, y in reversed(path)]
            prism('Sinuous low open console stretcher', points, .175, .197, 'wood', .001)
            rel.tube([(x, y, .196) for x, y in path], .0009, 'gold', 5)
        c.lathe('Small central stretcher collar', (0, 0, .185), [(0, 0), (.035, 0), (.035, .016), (0, .016)], 'piano', 32)
    rel.finish('Nantes occasional-table interlace and bronze collars')


def pedestal(rel, x, y, w, d, top):
    # Stepped rectangular foot and sculpted concave-sided oak-burl support.
    for ww, dd, za, zb, mat in ((w, d, .014, .047, 'wood'),
                              (w-.018, d-.018, .045, .061, 'piano'),
                              (w-.070, d-.070, .059, .080, 'piano')):
        ob = prism('Pedestal stepped foot', rect(ww, dd, .005), za, zb, mat, .001)
        ob.location.x, ob.location.y = x, y
    # Tiny under-base pads fix the authored bottom at floor 0.
    for sx in (-1, 1):
        for sy in (-1, 1):
            c.box('Pedestal low floor pad', (x+sx*(w/2-.045), y+sy*(d/2-.045), .008), (.07, .07, .016), 'piano', .001)
    band_bottom, band_top = .080, .193
    bw, bd = w-.083, d-.083
    ob = prism('Black interlaced pedestal base', rect(bw, bd, .005), band_bottom, band_top, 'piano', .001)
    ob.location.x, ob.location.y = x, y
    for sign in (-1, 1):
        for axis in (0, 1):
            length = bw if axis == 0 else bd
            ext = bd/2 if axis == 0 else bw/2
            zz = (band_bottom+band_top)/2
            if axis == 0:
                mapping = lambda u, v, r, sign=sign, ext=ext: (x+u, y+sign*(ext+r), zz+v)
            else:
                mapping = lambda u, v, r, sign=sign, ext=ext: (x+sign*(ext+r), y+u, zz+v)
            lattice(rel, mapping, length-.155, .064, .031)
            for pos in (-length/2+.041, length/2-.041):
                corner(rel, lambda u, v, r, pos=pos: mapping(u+pos, v, r), .069)
    # Successive exact cross sections describe the smoothly concave pedestal.
    body0, body1 = band_top, top
    section = []
    for j in range(17):
        t = j/16
        # Broad bottom, drawn-in waist, modest top support. Photographed form.
        s = .58+.42*(1-t)**3+.10*t**5
        section.append((s, body0+(body1-body0)*t))
    outline = rect(bw, bd, .013, 4)
    n = len(outline)
    verts = [(x+u*s, y+v*s, z) for s, z in section for u, v in outline]
    faces = []
    for j in range(len(section)-1):
        for k in range(n):
            q = j*n+k
            faces.append((q, j*n+(k+1) % n, (j+1)*n+(k+1) % n, q+n))
    faces.extend([tuple(reversed(range(n))), tuple((len(section)-1)*n+k for k in range(n))])
    ob = c.mesh('Concave swept oak-burl dining pedestal', verts, faces, 'wood', smooth=True)
    # Flat caps do not interpolate side normals across the broad top or bottom.
    ob.data.polygons[-1].use_smooth = False
    ob.data.polygons[-2].use_smooth = False


def dining_table(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    rel = Relief()
    round_table = sku == '50340.0'
    if round_table:
        pedestal(rel, 0, 0, .76, .76, h-.080)
        prism('Round polished oak-burl dining top', circle(w/2), h-.072, h-.006, 'wood', .002)
        # A separate shallow Lazy Susan sits inside the overall published height.
        c.lathe('Lazy Susan central rotation reveal', (0, 0, h-.006), [(0, 0), (.493, 0), (.493, .0018), (0, .0018)], 'piano', 112)
        c.lathe('Separate oak-burl Lazy Susan turntable', (0, 0, h-.0042), [(0, 0), (.490, 0), (.490, .0042), (0, .0042)], 'wood', 112)
        for radius, mat, thick in ((w/2-.012, 'piano', .0017), (w/2-.034, 'ivory', .0010),
                                   (w/2-.040, 'piano', .0012), (w/2-.059, 'gold', .0008), (.485, 'gold', .0008)):
            rel.tube([(radius*math.cos(TAU*j/112), radius*math.sin(TAU*j/112), h-.00585 if radius>.5 else h+.00015)
                      for j in range(112)], thick, mat, 5, True)
    else:
        for x in (-.58, .58):
            pedestal(rel, x, 0, .72, .85, h-.073)
        prism('Rectangular oak-burl dining tabletop', rect(w, d, .009), h-.073, h, 'wood', .002)
        for inset, mat in ((.014, 'piano'), (.034, 'ivory'), (.040, 'piano')):
            rel.tube([(x, y, h+.00015) for x, y in rect(w-2*inset, d-2*inset, .005)],
                     .001 if mat != 'ivory' else .0008, mat, 5, True)
    rel.finish('Nantes dining-table physical inlay and pedestal castings')


def scalloped_apron(rel, x, y, w, z0, z1, depth=.036, motif=True):
    """Black plinth with raised ends and a gilt lower contour."""
    left, right = -w/2, w/2
    contour = [(left, z1), (left, z0+.033), (left+.065, z0+.033)]
    contour += bezier((left+.065, z0+.033), (left+.092, z0+.032),
                      (left+.089, z0+.002), (left+.125, z0), 7)[1:]
    contour += [(right-.125, z0)]
    contour += bezier((right-.125, z0), (right-.089, z0+.002),
                      (right-.092, z0+.032), (right-.065, z0+.033), 7)[1:]
    contour += [(right, z0+.033), (right, z1)]
    ob = xz_prism('Scalloped black lacquer apron', [(u+x, z) for u, z in contour], y, y+depth, 'piano')
    bottom = contour[1:-1]
    rel.tube([(u+x, y-.0005, z+.001) for u, z in bottom], .0011, 'gold', 5)
    if motif and w > .95:
        laurel(rel, front_map(x, y-.001, (z0+z1)/2+.002), min(.30, w*.20), min(.032, (z1-z0)*.36))
    return ob


def laurel(rel, mapping, width=.28, height=.035):
    rosette(rel, mapping, height*.32, 9)
    for sign in (-1, 1):
        rel.tube([mapping(sign*t*width/2, -.003+.009*t*t, .0017) for t in [j/12 for j in range(13)]],
                 .0014, 'gold', 5)
        for j in range(7):
            u = sign*(.023+j*(width/2-.029)/7)
            for vertical in (-1, 1):
                path = bezier((u, 0), (u+sign*.007, vertical*.007),
                              (u+sign*.014, vertical*height*.55), (u+sign*.017, vertical*height*.55), 5)
                rel.leaf(mapping, path, height*.10, 'gold', .0023)


def side_inlay(rel, x, d, z0, z1, sign):
    mapping = side_map(x, 0, (z0+z1)/2, sign)
    ring(rel, mapping, d-.095, z1-z0-.100, .0011, 'ivory')
    ring(rel, mapping, d-.108, z1-z0-.113, .0007, 'piano')


def storage_shell(rel, w, d, h, bottom=.105, center=True, feet=True, apron=True, offset=0):
    """Physical timber shell; no opaque volume in display openings."""
    top = h-.034
    body0 = bottom+.075
    front = -d/2+.020
    if feet:
        for x in (-w/2+.067, w/2-.067):
            for y in (-d/2+.065, d/2-.065):
                # Upper sockets overlap the raised end of the scalloped plinth;
                # rear feet must connect to the actual case, not float below it.
                short_foot(rel, x+offset, y, bottom+.036, .037 if h<1.5 else .039)
    if apron:
        # The profile is a full-depth plinth solid, not a front decoration only.
        scalloped_apron(rel, offset, -d/2+.011, w-.024, bottom-.003, body0+.003, d-.022, center)
    # A closed wood back, base, ceiling and sides with realistic thickness.
    c.box('Oak-burl cabinet back', (offset, d/2-.023, (body0+top)/2), (w-.034, .025, top-body0), 'inside', .0006)
    c.box('Solid case bottom', (offset, 0, body0+.013), (w-.035, d-.040, .026), 'inside', .0008)
    c.box('Solid case roof under top', (offset, 0, top-.013), (w-.030, d-.035, .026), 'inside', .0008)
    for sign in (-1, 1):
        x = offset+sign*(w/2-.032)
        c.box('Oak-burl outer case side', (x, 0, (body0+top)/2), (.030, d-.040, top-body0), 'wood', .0009)
        side_inlay(rel, offset+sign*(w/2-.016), d-.030, body0, top-.020, sign)
    # Polished top and black edge; the only full product extrema in X/Y/Z.
    ob = prism('Polished figured-oak cabinet top', rect(w, d, .005), h-.034, h, 'wood', .0016)
    ob.location.x = offset
    ob = prism('Black under-top reveal', rect(w-.004, d-.004, .004), h-.038, h-.032, 'piano', .0005)
    ob.location.x = offset
    rel.tube([(x+offset, y, h+.00015) for x, y in rect(w-.020, d-.020, .004)], .001, 'piano', 5, True)
    return body0, h-.123, front


def cabinet_frame(rel, w, d, h, body0, center=True, offset=0, post=.068):
    top = h-.038
    fh = .074
    front = -d/2+.012
    zmid = top-fh/2
    # Square corner medallions at each end of the black loop frieze.
    c.box('Black upper front frieze', (offset, front+.014, zmid), (w-.026, .038, fh), 'piano', .0008)
    for x in (-w/2+post/2+.012, w/2-post/2-.012):
        c.box('Black vertical ornamental outer stile', (x+offset, front+.016, (body0+top)/2),
              (post, .039, top-body0), 'piano', .0007)
        corner(rel, front_map(x+offset, front-.005, zmid), post-.002)
        mapping = lambda u, v, r, x=x: (x+offset+v, front-.005-r, (body0+top-fh)/2+u)
        lattice(rel, mapping, top-fh-body0-.018, post*.70, .025, .00085)
    usable = w-2*post-.042
    if center:
        cw = .076
        for sign in (-1, 1):
            length = (usable-cw)/2
            xx = offset+sign*(length/2+cw/2)
            lattice(rel, front_map(xx, front-.005, zmid), length-.006, fh*.70)
        c.box('Central black fluted pilaster', (offset, front+.010, (body0+top)/2), (cw, .040, top-body0), 'piano', .0008)
        fluted_panel(rel, front_map(offset, front-.008, (body0+top)/2), cw-.021, top-body0-.010)
    else:
        lattice(rel, front_map(offset, front-.005, zmid), usable-.012, fh*.70)
    return front, top-fh-.005, post


def pull(rel, x, y, z, w=.058, h=.028):
    # Black rectangular backing and five/six fine bronze vertical handle ribs.
    c.box('Black rectangular bronze-handle escutcheon', (x, y+.004, z), (w+.010, .008, h+.008), 'piano', .0007)
    fluted_panel(rel, front_map(x, y+.001, z), w, h, max(4, round(w/.006)), 'gold')


def fixed_panel(rel, x, y, z0, z1, w, framed=False, handle=None, handle_z=None):
    c.box('Oak-burl fixed front panel | no unverified opening animation', (x, y+.017, (z0+z1)/2),
          (w, .033, z1-z0), 'wood', .0010)
    if framed:
        mapping = front_map(x, y-.001, (z0+z1)/2)
        ring(rel, mapping, w-.104, z1-z0-.119, .0026, 'ivory')
        ring(rel, mapping, w-.121, z1-z0-.136, .0009, 'gold')
        ring(rel, mapping, w-.162, z1-z0-.177, .0014, 'piano')
    if handle:
        hx = x+handle
        zz = handle_z if handle_z is not None else z1-.105
        pull(rel, hx, y-.009, zz)


def closed_storage(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    rel = Relief()
    drawers = sku in ('50382.0', '50386.0')
    body0, bodytop, front = storage_shell(rel, w, d, h, center=not drawers)
    front, bodytop, post = cabinet_frame(rel, w, d, h, body0, not drawers)
    z0, z1 = body0+.006, bodytop-.005
    if drawers:
        n = 3 if sku == '50382.0' else 5
        panelw = w-2*post-.047
        for j in range(n):
            za = z0+(z1-z0)*j/n+.001
            zb = z0+(z1-z0)*(j+1)/n-.001
            fixed_panel(rel, 0, front+.008, za, zb, panelw)
            pull(rel, 0, front-.008, (za+zb)/2, .042, .025)
    elif sku == '50361.0':
        panelw = (w-2*post-.130)/2
        for sign in (-1, 1):
            xx = sign*(panelw/2+.045)
            fixed_panel(rel, xx, front+.009, z0, z1, panelw, True)
            # Paired delicate cast key escutcheons sit close to the centre stile.
            rosette(rel, front_map(sign*.073, front-.001, (z0+z1)/2), .0085, 7)
            rel.bead((sign*.073, front-.005, (z0+z1)/2), .003, 'antique_gold')
    else:
        # Four flush doors; paired handles at the inner meeting of each pair.
        usable = (w-2*post-.127)/2
        for sign in (-1, 1):
            groupx = sign*(usable/2+.044)
            for k in (-1, 1):
                xx = groupx+k*(usable/4)
                fixed_panel(rel, xx, front+.010, z0, z1, usable/2-.002)
            for k in (-1, 1):
                pull(rel, groupx+k*.035, front-.009, z1-.110, .046, .025)
    # A real inner shelf is retained even behind the fixed reconstructed fronts.
    if not drawers:
        c.box('Interior storage shelf', (0, .004, (z0+z1)/2), (w-.12, d-.095, .022), 'inside', .0007)
    rel.finish('Nantes casework cast interlace and sycamore inlay')


def tv_furniture():
    w, d, h = [v/1000 for v in SPECS['50380.0'][1]]
    rel = Relief()
    body0, bodytop, front = storage_shell(rel, w, d, h)
    front, bodytop, post = cabinet_frame(rel, w, d, h, body0, True)
    opening_w = .405
    sidew = (w-.26)/4
    z0, z1 = body0+.004, bodytop-.006
    for sign in (-1, 1):
        # Each half contains a flush outer door and two genuine open inner cubbies.
        outerx = sign*(w/2-post-sidew/2-.025)
        fixed_panel(rel, outerx, front+.009, z0, z1, sidew-.015)
        cubbyx = sign*(opening_w/2+.048)
        dividerx = sign*(opening_w+.059)
        c.box('Vertical TV cubby divider', (dividerx, 0, (z0+z1)/2), (.022, d-.060, z1-z0), 'inside', .0006)
        c.box('TV open cubby horizontal shelf', (cubbyx, -.002, (z0+z1)/2-.018),
              (opening_w-.009, d-.071, .021), 'wood', .0008)
        pull(rel, sign*(w/2-post-sidew+.035), front-.008, z1-.12, .043, .024)
    rel.finish('Nantes TV lattice and cast details')


def glazed_cabinet():
    w, d, h = [v/1000 for v in SPECS['50343.0'][1]]
    rel = Relief()
    body0, bodytop, front = storage_shell(rel, w, d, h)
    front, bodytop, post = cabinet_frame(rel, w, d, h, body0, True, post=.077)
    z0, z1 = body0+.018, bodytop-.015
    doorw = (w-2*post-.131)/2
    for sign in (-1, 1):
        x = sign*(doorw/2+.044)
        c.box('Clear glass front door pane | fixed photographic reconstruction', (x, front+.020, (z0+z1)/2),
              (doorw-.030, .006, z1-z0-.030), 'glass', .0005)
        ring(rel, front_map(x, front+.012, (z0+z1)/2), doorw-.018, z1-z0-.018, .0012, 'gold')
        # Door timber glazing rails have real depth on every edge.
        for xx in (x-doorw/2+.005, x+doorw/2-.005):
            c.box('Slender oak-burl glazing stile', (xx, front+.026, (z0+z1)/2), (.014, .025, z1-z0), 'wood', .0005)
        for zz in (z0+.005, z1-.005):
            c.box('Slender oak-burl glazing rail', (x, front+.026, zz), (doorw, .025, .014), 'wood', .0005)
        pull(rel, sign*.075, front-.009, 1.035, .045, .031)
    # The reference shows four clear shelves, giving five display levels.
    for i in range(1, 5):
        z = z0+(z1-z0)*i/5
        c.box('True clear glass shelf %d of 4' % i, (0, .008, z), (w-.143, d-.090, .010), 'glass', .0006)
        for x in (-w/2+.052, w/2-.052):
            for y in (-d/2+.063, d/2-.066):
                c.cylinder('Small cast shelf support', (x, y, z-.009), .0045, .009, 'brass')
    rel.finish('Nantes vitrine physical bronze lattice and inlay')


def mirror(sku):
    w, d, h = [v/1000 for v in SPECS[sku][1]]
    rel = Relief()
    # Matching broad landscape and portrait mirrors share a low stepped crest.
    # Mirror opening and black border are separate physical parts.
    border = .026 if sku == '50348.0' else .029
    crest = .085 if sku == '50348.0' else .089
    lower = .064
    z0, z1 = lower, h-crest
    # The backing follows the opening, not an all-height rectangle that would
    # stick up behind the lowered outer ends of the stepped crest.
    c.box('Black mirror opening backing', (0, d/2-.007, (z0+z1)/2),
          (w-.009, .014, z1-z0+.014), 'piano', .001)
    c.box('Silvered mirror glass', (0, -.010, (z0+z1)/2), (w-2*border, .008, z1-z0), 'mirror', .0005)
    for x in (-w/2+border/2, w/2-border/2):
        c.box('Thin black mirror vertical frame', (x, -.005, (z0+z1)/2), (border, .043, z1-z0+.015), 'piano', .001)
    # Upper/lower outlines turn up at the end into a shallow, rounded step.
    a = w/2
    top_path = [(-a, h-crest+.002), (-a, h-crest+.030), (-a+.060, h-crest+.030)]
    top_path += bezier((-a+.060, h-crest+.030), (-a+.084, h-crest+.030),
                       (-a+.084, h), (-a+.114, h), 8)[1:]
    top_path += [(a-.114, h)]
    top_path += bezier((a-.114, h), (a-.084, h),
                       (a-.084, h-crest+.030), (a-.060, h-crest+.030), 8)[1:]
    top_path += [(a, h-crest+.030), (a, h-crest+.002)]
    # X/Z polygon winding does not alter geometric extents.
    xz_prism('Stepped black mirror crest', list(reversed(top_path)), -d/2+.0015, d/2-.004, 'piano')
    rel.tube([(x, -d/2+.0014, z-.0015) for x, z in top_path[1:-1]], .0011, 'gold', 5)
    lower_path = [(-a, lower+.007), (-a, lower-.018), (-a+.065, lower-.018)]
    lower_path += bezier((-a+.065, lower-.018), (-a+.087, lower-.018),
                         (-a+.087, 0), (-a+.117, 0), 8)[1:]
    lower_path += [(a-.117, 0)]
    lower_path += bezier((a-.117, 0), (a-.087, 0),
                         (a-.087, lower-.018), (a-.065, lower-.018), 8)[1:]
    lower_path += [(a, lower-.018), (a, lower+.007)]
    xz_prism('Stepped black mirror lower rail', lower_path, -d/2+.0015, d/2-.004, 'piano')
    rel.tube([(x, -d/2+.0014, z+.0010) for x, z in lower_path[1:-1]], .0010, 'gold', 5)
    ring(rel, front_map(0, -.0272, (z0+z1)/2), w-.020, z1-z0+.013, .0009, 'ivory')
    # A narrow bronze laurel spray is the only crest ornament, not a Baroque crown.
    laurel(rel, front_map(0, -d/2+.0017, h-crest*.46), min(.49, w*.43), crest*.31)
    rel.finish('Nantes mirror gilt contour and laurel crest')


def dressing_table():
    w, d, h = [v/1000 for v in SPECS['50383.0'][1]]
    rel = Relief()
    pw = .612
    knee = w-2*pw-.025
    foot_h = .092
    body0 = foot_h+.079
    top = h-.038
    front = -d/2+.013
    # True central knee opening with a rear timber modesty panel.
    c.box('Vanity knee-space back panel', (0, d/2-.031, .422), (knee+.025, .024, .494), 'wood', .0007)
    for sign in (-1, 1):
        xx = sign*(w/2-pw/2)
        # Independent shells make the central front open, not a painted black patch.
        storage_shell(rel, pw, d-.014, h-.039, foot_h, False, True, True, xx)
        post = .067
        framefront, framebottom, _ = cabinet_frame(rel, pw, d-.014, h-.039, body0, False, xx, post)
        # Lower door and short upper drawer, both visibly bordered in the source.
        pane_w = pw-2*post-.037
        split = .558
        fixed_panel(rel, xx, framefront+.010, body0+.006, split-.003, pane_w, True)
        fixed_panel(rel, xx, framefront+.010, split+.001, framebottom-.006, pane_w)
        pull(rel, xx, framefront-.008, split-.032, .042, .025)
        pull(rel, xx, framefront-.008, (split+framebottom)/2, .042, .025)
    # Single uninterrupted highly figured top, exact advertised dimensions.
    tabletop(rel, w, d, h, False)
    # Upper central apron is a broad panel of vertical gilt flutes.
    c.box('Black central vanity apron', (0, front+.014, h-.079), (knee+.031, .037, .083), 'piano', .001)
    fluted_panel(rel, front_map(0, front-.007, h-.079), knee+.013, .067, max(18, round(knee/.006)))
    rel.finish('Nantes dressing table physical castings and gilt flutes')


def create(sku, instance='main'):
    sku = str(sku)
    if sku not in SPECS:
        raise ValueError('Unknown Nantes casegoods SKU: '+sku)
    name, dimensions = SPECS[sku]
    root = c.empty(name+' | '+str(instance), props={
        'kind': 'product', 'product_id': sku, 'instance_id': str(instance),
        'dimensions_mm': list(dimensions), 'collection': 'Nantes',
        'source': 'MARINER CLASSIC_FURNITURE_CATALOG_2023.pdf | PDF 35,99-101,123-124',
        'moving_parts': 0,
        'reconstruction_note': 'Independent visual reconstruction from catalogue photography, not official manufacturer CAD. Hidden joinery and exact cast patterns are interpreted; finishes are not calibrated physical samples.',
        'origin_note': 'Floor-centred; mirror origin is bottom-centred, ready for separate wall placement.',
    })
    if sku == '50343.0':
        root['shelf_count'], root['display_levels'] = 4, 5
    if sku == '50340.0':
        root['lazy_susan'] = True
        root['lazy_susan_note'] = 'Separate physical central turntable; no unverified opening/rotation mechanism is animated.'
    if sku in ('50382.0', '50386.0'):
        root['drawer_count'] = 3 if sku == '50382.0' else 5
    if sku == '50361.0':
        root['source_note'] = 'Same SKU is shown in the dining and bedroom sections; one unique authored product, reused as needed.'
    with parent_to(root):
        if sku in ('50378.0', '50379.0', '50347.0'):
            occasional_table(sku)
        elif sku in ('50339.0', '50340.0'):
            dining_table(sku)
        elif sku in ('50342.0', '50348.0'):
            mirror(sku)
        elif sku == '50380.0':
            tv_furniture()
        elif sku == '50343.0':
            glazed_cabinet()
        elif sku == '50383.0':
            dressing_table()
        else:
            closed_storage(sku)
    return root
