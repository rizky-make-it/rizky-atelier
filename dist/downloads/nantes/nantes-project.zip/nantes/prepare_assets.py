"""Package original native renders, 22 models, room references and rebuild."""
from pathlib import Path
import sys,json,shutil,hashlib,struct,zipfile
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
sys.path.insert(0,str(ROOT/'.local/catalogue-review/packages'))
import pymupdf as fitz
DIST=ROOT/'sites/rizky-atelier/dist';ASSET=DIST/'assets/collections/nantes';DOWN=DIST/'downloads/nantes'
ASSET.mkdir(parents=True,exist_ok=True);DOWN.mkdir(parents=True,exist_ok=True)
source=json.loads((BASE/'reference/products.json').read_text(encoding='utf8'));scene=json.loads((BASE/'scene.json').read_text());proof={};copies=[]
render_run=json.loads((BASE/'render-run-audit.json').read_text());assert render_run['ok'] and not render_run['shadowErrors'] and len(render_run['completed'])==10
models=json.loads((ASSET/'products.json').read_text(encoding='utf8'))
for p in models:p['referenceNote']=next(x for x in source['products'] if x['sku']==p['sku']).get('reference_note','')
(ASSET/'products.json').write_text(json.dumps(models,indent=2),encoding='utf8')
def record(dst):
    raw=dst.read_bytes();copies.append({'destination':dst.relative_to(DIST).as_posix(),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
def copy(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);record(dst)
names=('living','living-wide','dining','dining-round','bedroom','bedroom-front','vanity','detail-burl','detail-upholstery','detail-tufting')
for name in names:
    filename=name+('.png' if name.startswith('detail') else '-4k.png');src=BASE/'renders'/filename;raw=src.read_bytes();w,h=struct.unpack('>II',raw[16:24])
    assert (w,h)==((1600,1600) if name.startswith('detail') else (3840,2160))
    settings=json.loads((BASE/'renders'/(name+'-settings.json')).read_text())
    assert settings['originalBlenderRender'] and settings['walls'] and settings['roof']
    copy(src,DOWN/filename);pix=fitz.Pixmap(str(src))
    if w>1920:pix=fitz.Pixmap(pix,1920,round(h*1920/w))
    pix.save(str(ASSET/(name+'.jpg')),jpg_quality=94)
    proof[name]={'file':filename,'width':w,'height':h,'sha256':hashlib.sha256(raw).hexdigest(),'engine':settings['engine'],'nativeScene':'nantes-interior.blend','originalBlenderRender':True,'walls':True,'roof':True}
for p in source['products']:
    src=BASE/'reference/catalogue'/(p['sku']+'.jpg');assert hashlib.sha256(src.read_bytes()).hexdigest()==p['image']['sha256'];copy(src,ASSET/'catalogue'/src.name)
for key in ('living','dining','bedroom'):copy(BASE/'reference'/('room-'+key+'.jpg'),ASSET/('original-room-'+key+'.jpg'))
copy(BASE/'nantes-interior.blend',DOWN/'nantes-interior.blend');copy(BASE/'native-audit.json',DOWN/'native-audit.json');copy(BASE/'render-run-audit.json',DOWN/'render-run-audit.json');copy(BASE/'reference/products.json',ASSET/'source-reference.json')
(DOWN/'render-proof.json').write_text(json.dumps(proof,indent=2),encoding='utf8');record(DOWN/'render-proof.json')
doc=fitz.open(source['source_pdf']);subset=fitz.open()
for page in source['source_pdf_pages']:subset.insert_pdf(doc,from_page=page-1,to_page=page-1)
subset.save(str(DOWN/'NANTES-reference-pages.pdf'),garbage=4,deflate=True);subset.close();doc.close();record(DOWN/'NANTES-reference-pages.pdf')
sources=('core.py','geometry.py','sofas.py','casegoods.py','build_scene.py','export_web.py','render_scene.py','validate_native.py','prepare_assets.py','scene.json','build-report.json','export-report.json','native-audit.json','README.md','sofas_audit.py','sofas-audit.json','casegoods_audit.py','casegoods-audit.json')
with zipfile.ZipFile(DOWN/'nantes-project.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for filename in sources:z.write(BASE/filename,'nantes/'+filename)
    for folder in ('textures','reference'):
        for p in (BASE/folder).rglob('*'):
            if p.is_file():z.write(p,'nantes/'+p.relative_to(BASE).as_posix())
    for filename in ('scripts/read_catalogue.py','scripts/render_verified.mjs','render-run-audit.json','nantes-interior.blend'):z.write(BASE/filename,'nantes/'+filename)
    z.write(DOWN/'NANTES-reference-pages.pdf','nantes/NANTES-reference-pages.pdf')
with zipfile.ZipFile(DOWN/'nantes-project.zip') as z:assert z.testzip() is None
record(DOWN/'nantes-project.zip')
for p in DOWN.iterdir():assert p.stat().st_size<95*1024*1024,('GitHub file too large',p)
prefix='assets/collections/nantes';url='https://rizky-make-it.github.io/rizky-atelier/'
def render(name,title,caption):return {'image':prefix+'/'+name+'.jpg','title':title,'caption':caption,'request':'the original NANTES Blender interior render: '+title,'sourceUrl':url+'downloads/nantes/'+proof[name]['file']}
def file(title,ext,desc,request,p):return {'title':title,'extension':ext,'description':desc,'request':request,'sourceUrl':url+p}
collection={'id':'nantes','name':'NANTES','number':'07','referenceYear':2023,'kind':'Furnished catalogue interior','layout':'furnished-interior','title':'Classical character. A place to live.','tagline':'Oak burl. Black lacquer. Classical interiors.',
 'description':'Twenty-two distinct MARINER references connect a furnished window salon, a marble dining room and an intimate charcoal bedroom. Amber oak burl, fine sycamore inlay, black lacquer framing, delicate gilt lattice and pale damask follow the supplied catalogue. Panel mouldings, banded curtains, urn lamps, chandeliers and soft textiles restore the architectural context. The connected plan and unshown construction remain authored interpretations, not a measured copy of a source building.',
 'finish':'NAN. / OF (544/55); chairs and stool NAN. (544)','hero':prefix+'/living.jpg','exhibition':prefix+'/nantes-interior.glb','scene':prefix+'/scene.json','placementCount':len(scene['placements']),'movingParts':0,'sourceSite':url+'#/collections/nantes','sourceRepo':'https://github.com/rizky-make-it/rizky-atelier','productCount':22,'palette':['#a56b34','#15120e','#d8d0bb','#b5904e'],
 'roomReferences':[{'image':prefix+'/original-room-'+k+'.jpg','title':title,'caption':'MARINER classic catalogue, PDF page '+str(page)+'. Original supplied room composition, not the reconstructed Blender render.'} for k,title,page in [('living','The original window salon',32),('dining','The original dining room',98),('bedroom','The original bedroom',122)]],
 'renders':[render('living','The window salon','Banded curtains, blue urn lamps, a curved oak-burl sofa and damask upholstery within complete greige architecture. Actual Blender render,3840×2160.'),render('living-wide','A room to gather','Paired armchairs, glass-inset coffee table and classical fireplace. Architecture and styling interpret the catalogue; they are not additional SKUs. Actual Blender render,3840×2160.'),render('dining','The marble dining room','A rectangular twin-pedestal table, shield-back chairs and broad sideboard/mirror composition. Actual enclosed-interior Blender render,3840×2160.'),render('dining-round','A second dining setting','The distinct1600mm round table includes its Lazy Susan. Actual Blender render,3840×2160.'),render('bedroom','The charcoal bedroom','Two tufted headboard fields, paired three-drawer bedsides, bench, five-drawer chest and warm urn lamps. Actual Blender render,3840×2160.'),render('bedroom-front','The upholstered suite','Pale layered bedding against a black-lacquer and gilded headboard, within charcoal panelled walls. Actual Blender render,3840×2160.'),render('vanity','The dressing corner','A separately dimensioned dressing table, portrait mirror and upholstered stool. Actual Blender render,3840×2160.'),render('detail-burl','Burl, inlay & lattice','Physical gilt oval lattice, polished black framing and authored oak-burl figuring. Actual Blender detail render,1600×1600.'),render('detail-upholstery','The botanical upholstery','Modelled seams and soft folds meet an authored damask motif and fine thread normal map. Not a scanned or calibrated manufacturer fabric. Actual Blender detail,1600×1600.'),render('detail-tufting','Two fields of tufting','Real recessed-button geometry and a ribbed gilt centre stile. Actual Blender detail,1600×1600.')],
 'materials':[{'image':prefix+'/detail-burl.jpg','title':'Oak burl & gilt lattice','description':'Authored figured veneer, actual overlapping oval relief, sycamore-tone framing and black lacquer. A model render, not a physical sample.'},{'image':prefix+'/detail-upholstery.jpg','title':'Champagne damask','description':'Reference-inspired botanical textile, micro-thread normal and physical cushion folds; exact manufacturer fabric is not certified.'},{'image':prefix+'/detail-tufting.jpg','title':'Tufting & polished framing','description':'Physical twin tufted headboard fields, gilt ribbing and piped soft upholstery, rendered from editable native geometry.'}],
 'files':[file('Native Nantes residence','.BLEND','22 unique references, complete walls/ceilings, packed maps and ten cameras.','the NANTES editable Blender furnished-interior master (.blend)','downloads/nantes/nantes-interior.blend'),file('Interior & individual models','.GLB','A furnished residence and22 full-detail individual product models.','the NANTES furnished residence GLB and22individual product GLBs',prefix+'/nantes-interior.glb'),file('Complete rebuild project','.ZIP','Native scene, source geometry, packed PBR maps, reference provenance and audit.','the complete NANTES Blender project, textures, reference evidence and rebuild scripts','downloads/nantes/nantes-project.zip'),file('Original room & product references','.PDF','Eleven supplied MARINER spreads across living, dining and bedroom.','the NANTES living, dining and bedroom source catalogue reference pages','downloads/nantes/NANTES-reference-pages.pdf'),file('Original 4K interior renders','4K PNG','Seven genuine 4K Blender room renders and three 1600-square details.','all NANTES original 4K Blender interior renders and detailed material images','downloads/nantes/render-proof.json')]}
(ASSET/'collection.json').write_text(json.dumps(collection,indent=2),encoding='utf8')
(ASSET/'asset-audit.json').write_text(json.dumps({'collection':'NANTES','sourcePDFSHA256':source['source_pdf_sha256'],'files':copies,'renderProof':proof},indent=2),encoding='utf8')
print('NANTES_PACKAGED',json.dumps({'renders':len(proof),'products':len(models),'placements':len(scene['placements']),'nativeBytes':(DOWN/'nantes-interior.blend').stat().st_size,'zipBytes':(DOWN/'nantes-project.zip').stat().st_size}),flush=True)
