# NANTES — catalogue-inspired furnished residence

Created by Muhammad Rizky for Rizky Atelier.

22 unique MARINER catalogue references connect a living room, dining room
and bedroom in a complete, enclosed architectural interior. Published on
GitHub Pages at https://rizky-make-it.github.io/rizky-atelier/#/collections/nantes.

## Native scene and rebuild

Open `nantes-interior.blend` in Blender 5.2+. All texture maps are packed.
The native scene is editable mesh/curve geometry, not product photographs
mapped to flat planes. Metres; X width, Y depth, Z up. Product fronts face
negative Y, while mirrors are anchored at bottom centre.

From this directory run Blender in background mode with `--python` and:

1. `build_scene.py` creates the native master from `core.py`, `geometry.py`,
   `sofas.py`, and `casegoods.py`.
2. Open the master and run `validate_native.py` for dimensions and packing.
3. Open the master and run `render_scene.py -- all` for seven actual 4K PNG
   renders and three 1600-square closeups. Default engine is EEVEE with
   ray tracing. Add `--use-cycles` for Cycles. `--preview` renders quarter-size.
4. Open the master and run `export_web.py` for 22 product GLBs and the
   optimized residence GLB. The native master is not overwritten.
5. Run `prepare_assets.py` with bundled Python/PyMuPDF to package sources,
   reference pages, original renders, provenance and website metadata.

`scripts/read_catalogue.py` rebuilds reference extraction from the original
user-supplied PDF path; adjust `SOURCE` if it moves. Native room rebuild
does not require the full PDF because photographs are evidence, not texture
substitutes. When outside the original workspace, export writes `web-export`.

## Scope and visual limitations

Source: user-supplied `CLASSIC_FURNITURE_CATALOG_2023.pdf`, PDF pages32–35,
98–101 and122–124. Printed millimetre dimensions, amber oak burl, black
lacquer framing, sycamore inlay, gilt lattice/rosettes and upholstery families
inform the products. The two-seat sofa shares the source three-seat photo;
its proportions use its separately printed dimensions. Commode50361.0 and
mirror50348.0 occur in two source room sections but each counts only once.

The connected floor plan is authored: the catalogue does not provide a
measured building plan. Walls, cornices, fireplace, curtains, skyline,
lamps/chandeliers, floral arrangements, rug motifs and table styling are
reference-inspired interpretations, not extra product SKUs. Exact hidden
construction, internal cabinet shelf arrangement, material substrate,
textile motif, colour calibration and opening hardware are not certified.
Storage panels are fixed, with no unverified opening animations.

The full native model retains walls and ceilings. The browser room tour also
retains them; only the explicitly labelled architectural overview removes
marked enclosure groups for a useful cutaway. Switching back to room mode
restores those groups. Earlier collections keep their previous open layouts.

Original product designs/catalogue imagery belong to MARINER and their
owners; this independent reconstruction implies no licence, manufacturer
endorsement or official CAD status. Original catalogue images are labelled
separately from authored Blender renders and are not verified real-life
product photography or physical material samples.

Website file requests open an English Muhammad Rizky profile and WhatsApp
draft to6281393177004; the application does not automatically send a message.
