"""Preserve full NANTES living, dining and bedroom source evidence."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / '.local/catalogue-review/packages'))
import pymupdf as fitz

SOURCE = Path('C:/Users/Admin/Downloads/CLASSIC_FURNITURE_CATALOG_2023.pdf')
DEST = ROOT / 'output/nantes/reference'
DEST.mkdir(parents=True, exist_ok=True)
ORIGINALS = DEST / 'originals'
ORIGINALS.mkdir(exist_ok=True)
PAGE_NUMBERS = [32,33,34,35,98,99,100,101,122,123,124]
doc = fitz.open(SOURCE)
pages = []
for pdf_page in PAGE_NUMBERS:
    page = doc[pdf_page-1]
    scale = 2400/page.rect.width
    image_path = DEST/f'page-{pdf_page:03}.jpg'
    page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False).save(image_path,jpg_quality=96)
    for image in page.get_image_info(xrefs=True):
        if image.get('xref'):
            original = doc.extract_image(image['xref'])
            (ORIGINALS/f'page-{pdf_page:03}-xref-{image["xref"]}.{original["ext"]}').write_bytes(original['image'])
    pages.append({'pdf_page':pdf_page,'rect_pdf_points':list(page.rect),
                  'text':page.get_text(sort=True),'text_blocks':page.get_text('blocks'),
                  'images':page.get_image_info(xrefs=True),'preview':image_path.name})
    print('PAGE',pdf_page,'IMAGES',[(i['xref'],i['width'],i['height'],list(i['bbox'])) for i in page.get_image_info(xrefs=True)],flush=True)
report = {'source':str(SOURCE),'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'page_count':len(doc),'metadata':doc.metadata,
          'image_classification':'Original catalogue image; not independently verified product photography',
          'pages':pages}
(DEST/'catalogue-evidence.json').write_text(json.dumps(report,indent=2,
    default=lambda value:value.hex() if isinstance(value,bytes) else str(value)),encoding='utf8')
print('PREVIEWS_READY',DEST,flush=True)

PRODUCTS = DEST/'catalogue'
DETAILS = DEST/'details'
PRODUCTS.mkdir(exist_ok=True)
DETAILS.mkdir(exist_ok=True)

def source_rect(pdf_page,xref,rect_pixels):
    info = next(i for i in doc[pdf_page-1].get_image_info(xrefs=True) if i['xref']==xref)
    x0,y0,x1,y1 = rect_pixels
    transform = fitz.Matrix(info['transform'])
    points = [fitz.Point(x/info['width'],y/info['height'])*transform for x,y in [(x0,y0),(x1,y0),(x0,y1),(x1,y1)]]
    return [min(p.x for p in points),min(p.y for p in points),max(p.x for p in points),max(p.y for p in points)]

def preserve_image(pdf_page,xref,destination,crop=None):
    original = doc.extract_image(xref)
    source_path = ORIGINALS/f'page-{pdf_page:03}-xref-{xref}.{original["ext"]}'
    source_path.write_bytes(original['image'])
    info = next(i for i in doc[pdf_page-1].get_image_info(xrefs=True) if i['xref']==xref)
    smask = next((i[1] for i in doc[pdf_page-1].get_images(full=True) if i[0]==xref),0)
    pixels = crop or [0,0,original['width'],original['height']]
    mirrored = info['transform'][0] < 0 and info['transform'][3] > 0
    evidence = {'source_pdf_page':pdf_page,'source_image_xref':xref,
                'source_native_pixels':[original['width'],original['height']],
                'crop_rect_native_pixels':pixels,'crop_rect_pdf_points':source_rect(pdf_page,xref,pixels),
                'source_image_file':source_path.relative_to(DEST).as_posix(),
                'source_image_sha256':hashlib.sha256(original['image']).hexdigest(),
                'source_image_to_pdf_transform':list(info['transform']),
                'source_pdf_horizontal_mirror':mirrored,
                'orientation_note':'Original embedded image orientation retained; the source PDF displays this image horizontally mirrored.' if mirrored else 'Original embedded image orientation matches the source PDF display.',
                'file':destination.relative_to(DEST).as_posix()}
    if crop or smask:
        composite = fitz.open()
        page = composite.new_page(width=original['width'],height=original['height'])
        if smask:
            mask = doc.extract_image(smask)
            mask_path = ORIGINALS/f'page-{pdf_page:03}-mask-{smask}.{mask["ext"]}'
            mask_path.write_bytes(mask['image'])
            page.insert_image(page.rect,stream=original['image'],mask=mask['image'])
            evidence.update({'source_soft_mask_xref':smask,'source_soft_mask_file':mask_path.relative_to(DEST).as_posix(),
                             'source_soft_mask_sha256':hashlib.sha256(mask['image']).hexdigest()})
        else:
            page.insert_image(page.rect,stream=original['image'])
        pixmap = page.get_pixmap(clip=fitz.Rect(pixels),alpha=False)
        pixmap.save(destination,jpg_quality=96)
        evidence['output_pixels'] = [pixmap.width,pixmap.height]
        evidence['transformation'] = ('Native-density rectangular crop; ' if crop else '') + ('original embedded JPEG with its original PDF soft mask faithfully composited over the original white page background; no new segmentation, upscaling or subject alteration' if smask else 'original embedded JPEG rendered at native pixel density; no upscaling or subject alteration')
        composite.close()
    else:
        destination.write_bytes(original['image'])
        evidence['output_pixels'] = [original['width'],original['height']]
        evidence['transformation'] = 'Exact original embedded JPEG bytes, no resizing or visual modification'
    evidence['sha256'] = hashlib.sha256(destination.read_bytes()).hexdigest()
    return evidence

COMMON = ['Amber-brown oak burl veneer with sycamore inlaid borders',
          'Glossy black framing with narrow gold edge detail',
          'Overlapping oval gold lattice ornament on black rails with tiny warm-red centres',
          'Gold square corner rosettes and cast-bronze foliate accents']
SEATING = ['Continuous rounded wraparound wooden outer back and sides with inset veneer panels',
           'Pale silver-greige floral upholstery, one continuous broad seat cushion and loose pillows',
           'Tall narrow gold oval-lattice front uprights with square rosettes at their tops',
           'Low glossy black front apron with central gold leaf-and-rosette motif',
           'Short black feet below ribbed gold collars; no tall tapered sofa legs']
definitions = [
 {'sku':'50375.0','name':'Nantes Three-seat Sofa','type':'Sofa','room':'Living room','dimensions_mm':[2500,920,780],'weight_kg':108,'source_pdf_page':34,'xref':174,'fabric_codes':['241.186','241.184'],'fabric_statement':'Suggested Fabric: 241.186 / 241.184','visible_details':SEATING,'imageShared':True,'imageSharedWith':['50376.0'],'reference_note':'Original three-seat front view also serves as the explicitly disclosed shared family reference for separately dimensioned two-seat50376.0. Separate original rear view supports the continuous curved burl-veneered outer shell. No isolated two-seat photo is printed.'},
 {'sku':'50376.0','name':'Nantes Two-seat Sofa','type':'Sofa','room':'Living room','dimensions_mm':[1800,920,780],'weight_kg':77,'source_pdf_page':34,'xref':174,'fabric_codes':['241.186','241.184'],'fabric_statement':'Suggested Fabric: 241.186 / 241.184','visible_details':SEATING,'imageShared':True,'imageSharedWith':['50375.0'],'reference_note':'SHARED FAMILY IMAGE: source prints SKU/dimensions for the two-seat variant but provides no isolated two-seat front photo. The unaltered original three-seat50375.0 image is shared as a family reference, not represented as a true two-seat photograph. Width and pillow arrangement in reconstruction are dimension-led interpretations.'},
 {'sku':'50377.0','name':'Nantes Lounge Armchair','type':'Armchair','room':'Living room','dimensions_mm':[1090,920,780],'weight_kg':40,'source_pdf_page':34,'xref':179,'fabric_codes':['241.186','241.184'],'fabric_statement':'Suggested Fabric: 241.186 / 241.184','visible_details':SEATING+['Single broad floral seat and one pale loose pillow; round backed tub silhouette'],'reference_note':'Separate original rear photograph confirms curved oak-burl shell and fine inlaid panel perimeter. Upholstered tub chair is distinct from the dining armchair50345.0.'},
 {'sku':'50378.0','name':'Nantes Square Coffee Table','type':'Coffee table','room':'Living room','dimensions_mm':[1300,1300,470],'weight_kg':85,'source_pdf_page':35,'xref':189,'visible_details':['Square inset transparent glass tabletop surrounded by a wide polished burl-wood border','Full solid lower burl-wood shelf with subtly concave outer edges','Four short tapered black legs with ribbed gold upper collars','Gold overlapping-oval lattice on black apron, square corner rosettes and fluted centre plaques'],'reference_note':'Glass inset is visible in the source; lower shelf is solid wood, not an open stretcher assembly. Tabletop furnishings are styling only.'},
 {'sku':'50379.0','name':'Nantes Square Side Table','type':'Side table','room':'Living room','dimensions_mm':[700,700,650],'weight_kg':31,'source_pdf_page':35,'xref':187,'visible_details':['Square solid oak-burl tabletop with fine rectangular inlay perimeter','Four tall tapered glossy black legs with ribbed gold collars below the apron','Full solid lower wood shelf with inward-curving sides','Gold oval-lattice black apron and four square corner rosettes'],'reference_note':'Separate lifestyle close-up page35 supplies richer ornament/wood/shelf evidence than the small original isolated image. Original isolated image is227x199pixels; it is not upscaled.'},
 {'sku':'50380.0','name':'Nantes TV Cabinet','type':'TV furniture','room':'Living room','dimensions_mm':[2190,480,760],'weight_kg':143,'source_pdf_page':35,'xref':185,'visible_details':['Long burl top with narrow dark edge','Two outer burl cabinet panels flanking a central open equipment bay','Horizontal shelf across centre bay creates two storage levels','Central fluted gold vertical divider and paired square gold pull details','Narrow oval-lattice top apron and side uprights; black lower apron with central gold leaf motif','Short black feet with gold fluted collars'],'reference_note':'Original product composition includes television, books and equipment as styling, not additional catalogue SKUs. No opening or electronics mechanism is verified.'},
 {'sku':'50339.0','name':'Nantes Rectangular Dining Table','type':'Dining table','room':'Dining room','dimensions_mm':[2500,1300,760],'weight_kg':212,'source_pdf_page':99,'xref':594,'visible_details':['Long rectangular polished burl top with dark perimeter and fine inlay border','Two substantial flared burl pedestal supports, not four legs','Each pedestal terminates in stepped rectangular plinth base','Black pedestal base fascia with gold overlapping-oval lattice and square rosettes'],'reference_note':'Dining lifestyle scene and close-up corroborate the two-pedestal construction. Any under-top joinery is interpretative.'},
 {'sku':'50340.0','name':'Nantes Round Dining Table with Lazy Susan','type':'Dining table','room':'Dining room','dimensions_mm':[1600,1600,810],'diameter_mm':1600,'weight_kg':135,'source_pdf_page':99,'xref':596,'visible_details':['Round polished burl top with concentric fine sycamore/dark inlay perimeter','Single flared burl pedestal on stepped square base','Gold overlapping-oval lattice and corner rosettes around black pedestal base','Lazy Susan specified in catalogue'],'reference_note':'Catalogue explicitly states With Lazy Susan but does not dimension its diameter, bearing, rotation speed or exact construction; any separated rotating centre is interpretative.'},
 {'sku':'50343.0','name':'Nantes Glazed Display Cabinet','type':'Cabinet','room':'Dining room','dimensions_mm':[1590,500,2180],'weight_kg':205,'source_pdf_page':100,'xref':601,'crop':[25,135,590,975],'visible_details':['Tall double-door glazed cabinet with warm burl interior and glazed side panels','Multiple transparent glass shelves and four visibly staged groups of tableware','Central tall fluted gold divider and two square gold pulls','Gold oval-lattice front uprights and top band; square corner rosettes','Broad black lower apron with central gold foliate motif and short feet with gold collars'],'reference_note':'Native-density rectangular crop of original lifestyle image; surrounding wall/floor/reflections retained. Wine glasses and tableware are styling. Reflections and overlapping edges make the exact interior glass-shelf count ambiguous; the printed specification does not state that count. Interior shelving, hinges, opening motion and lighting systems are not manufacturer-verified.'},
 {'sku':'50344.0','name':'Nantes Dining Side Chair','type':'Dining chair','room':'Dining room','dimensions_mm':[550,580,970],'weight_kg':7,'source_pdf_page':100,'xref':603,'finish':'NAN. (544)','fabric_codes':['241.185'],'fabric_statement':'Suggested Fabric: 241.185','visible_details':['Glossy black four-leg chair without arms','Shield-like silver-grey floral upholstered upper back, narrowing to a rounded point','Open lower back with intertwined gold double-loop ornament','Soft upholstered seat with narrow gold piping and black apron','Tapered black front legs with ribbed gold upper collars and tiny gold toes']},
 {'sku':'50345.0','name':'Nantes Dining Armchair','type':'Dining armchair','room':'Dining room','dimensions_mm':[630,580,970],'weight_kg':8,'source_pdf_page':100,'xref':605,'finish':'NAN. (544)','fabric_codes':['241.185'],'fabric_statement':'Suggested Fabric: 241.185','visible_details':['Glossy black four-leg dining chair with narrow swept curved arms and front arm uprights','Shield-like silver-grey floral upholstered upper back, narrowing to a rounded point','Open lower back with intertwined gold double-loop ornament','Soft upholstered seat with narrow gold piping','Tapered black front legs with ribbed gold upper collars and tiny gold toes'],'reference_note':'This open-frame dining chair has arms; it is not the upholstered tub-style living armchair50377.0.'},
 {'sku':'50342.0','name':'Nantes Landscape Mirror','type':'Mirror','room':'Dining room','dimensions_mm':[2100,60,1060],'weight_kg':68,'source_pdf_page':101,'xref':610,'visible_details':['Wide landscape rectangular mirror with narrow black side rails','Broad black top and bottom rails with shaped stepped/curved outer shoulders','Gold edge pinstripe and central gold leaf-and-rosette crest above top','Large clear mirrored centre'],'reference_note':'This is the wide landscape mirror, not portrait50348.0. Exact mounting hardware and optical finish are not specified.'},
 {'sku':'50341.0','name':'Nantes Wide Sideboard','type':'Sideboard','room':'Dining room','dimensions_mm':[2390,520,990],'weight_kg':220,'source_pdf_page':101,'xref':612,'visible_details':['Very wide burl cabinet with four front door panels arranged as two pairs','Paired rectangular gold handles above door mid-height','Central fluted gold divider, gold oval-lattice top band and outer uprights','Broad black lower apron with central gold leaf-and-rosette motif','Short decorated black feet with ribbed gold collars'],'reference_note':'Front door seams and handles are visible; internal shelving, hinge type and opening range are not evidenced.'},
 {'sku':'50361.0','name':'Nantes Commode','type':'Commode','room':'Dining room / Bedroom','rooms':['Dining room','Bedroom'],'dimensions_mm':[1640,530,960],'weight_kg':98,'source_pdf_page':123,'sourcePages':[101,123],'xref':734,'visible_details':['Two burl front doors with nested rectangular dark and pale inlay borders','Small decorative gold escutcheons or pulls near centre seam','Central fluted gold divider, oval-lattice outer uprights and top rail','Black lower apron with central gold leaf motif and short black/gold feet'],'reference_note':'Same50361.0 appears in dining PDF101 and bedroom PDF123; counted once. Original bedroom image chosen; dining original retained as additional evidence. It is a two-door commode, not a drawer chest.'},
 {'sku':'50348.0','name':'Nantes Portrait Mirror','type':'Mirror','room':'Dining room / Bedroom','rooms':['Dining room','Bedroom'],'dimensions_mm':[940,60,1040],'weight_kg':26,'source_pdf_page':124,'sourcePages':[101,124],'xref':739,'crop':[210,270,510,645],'visible_details':['Portrait rectangular mirrored centre with narrow glossy black side rails','Broad shaped black upper rail with gold leaf-and-rosette crest','Broad glossy black lower rail with narrow gold edge'],'reference_note':'Same50348.0 appears over the dining console on PDF101 and bedroom dressing table on PDF124; counted once. Native-density original lifestyle crop retains actual reflections and small objects; mirror is not a fabricated isolated photograph. Original PDF soft mask is preserved.'},
 {'sku':'50347.0','name':'Nantes Console','type':'Console','room':'Dining room','dimensions_mm':[1690,460,910],'weight_kg':50,'source_pdf_page':101,'xref':615,'crop':[35,465,595,835],'visible_details':['Long narrow polished burl top with black edge pinstripe','Fine oval-lattice black apron, square gold corner rosettes and central fluted plaque','Four long tapered black legs with gold fluted upper collars and small gold toes','Open lower curved wood stretcher links, not a solid shelf'],'reference_note':'Native-density lifestyle crop retains lamp, wall/floor and styling. The original embedded image is horizontally mirrored in the source PDF. No drawer or hidden mechanism is evidenced.'},
 {'sku':'50381.0','name':'Nantes Tufted Bed','type':'Bed','room':'Bedroom','dimensions_mm':[2180,2180,1600],'weight_kg':135,'source_pdf_page':123,'xref':728,'fabric_codes':['243.135'],'fabric_statement':'Suggested Fabric: 243.135','visible_details':['Tall rectangular headboard containing TWO separate pale diamond-button-tufted panels','Central fluted gold vertical divider and oval-lattice gold top/side black framing','Broad stepped glossy-black headboard crest outlined in gold','Low rectangular oak-burl footboard and side rails above black shaped lower plinth','Short black feet with gold fluted collars; pale bedding with dark taupe runner and striped/dark pillows'],'reference_note':'Printed overall width/depth are both218cm; do not infer mattress standard from the image. Bedding is styling. Catalogue image includes a printed decorative M pillow, not a separate product; reconstructed styling can omit this mark.'},
 {'sku':'50382.0','name':'Nantes Three-drawer Nightstand','type':'Nightstand','room':'Bedroom','dimensions_mm':[780,450,790],'weight_kg':55,'source_pdf_page':123,'xref':730,'visible_details':['THREE stacked full-width burl drawers, each with a small rectangular black-framed gold pull','Polished burl top with dark edge and fine perimeter inlay','Gold overlapping-oval lattice on top band and both black outer uprights','Broad shaped black lower apron and short black feet with ribbed gold collars'],'reference_note':'Three drawer count is visible in both product and lifestyle views. Drawer internals, rail mechanics and opening travel are not manufacturer-verified.'},
 {'sku':'50384.0','name':'Nantes Upholstered Bedroom Bench','type':'Bench','room':'Bedroom','dimensions_mm':[1520,540,520],'weight_kg':26,'source_pdf_page':123,'xref':732,'fabric_codes':['243.135'],'fabric_statement':'Suggested Fabric:243.135','visible_details':['Long rectangular pale silver-beige upholstered cushion with subtle perimeter piping','Broad glossy black shaped apron with central gold leaf-and-rosette motif','Four tapered black legs with ribbed gold collars and small gold toes'],'reference_note':'Bench is upholstered, not a burl top. Lifestyle throw blanket is styling only.'},
 {'sku':'50383.0','name':'Nantes Dressing Table','type':'Dressing table','room':'Bedroom','dimensions_mm':[2100,480,800],'weight_kg':127,'source_pdf_page':124,'xref':739,'crop':[10,685,730,1010],'visible_details':['Wide polished burl top with two flanking storage pedestals and open central knee recess','Each pedestal front shows one shallow upper drawer and one larger lower panel with small rectangular gold pulls','Central top rail is fluted gold, flanked by oval-lattice black bands and corner rosettes','Outer vertical gold oval-lattice borders and inset rectangular door/panel details','Low black shaped plinths on short gold-collared black feet'],'reference_note':'Native-density crop of original lifestyle image. Stool partly overlaps centre recess and lower front and remains visible. Front seams/pulls guide reconstruction; hidden storage, drawer depth and mechanisms are unverified.'},
 {'sku':'50385.0','name':'Nantes Upholstered Stool','type':'Stool','room':'Bedroom','dimensions_mm':[540,540,430],'weight_kg':13,'source_pdf_page':124,'xref':739,'crop':[325,815,590,1030],'finish':'NAN (544)','fabric_codes':['243.135'],'fabric_statement':'Suggested Fabric: 243.135','visible_details':['Compact square pale upholstered stool with upper cushion seam and upholstered lower block','Low glossy-black shaped apron with narrow gold edge','Four short black feet with wide ribbed gold collars'],'reference_note':'Original lifestyle crop, not an isolated white-background product photo. Adjacent dressing-table surfaces remain behind the stool and no missing surface has been synthesized.'},
 {'sku':'50386.0','name':'Nantes Five-drawer Chest','type':'Chest of drawers','room':'Bedroom','dimensions_mm':[780,450,1340],'weight_kg':105,'source_pdf_page':124,'xref':741,'visible_details':['FIVE stacked full-width burl drawers each with small rectangular gold/black handle','Gold oval-lattice black top band and outer uprights with square top-corner rosettes','Fine framed inlay detail on side panels','Shaped black lower plinth outlined in gold and short feet with ribbed gold collars'],'reference_note':'Five-drawer count visible in isolated product source and bedroom lifestyle image. Drawer internals and opening mechanisms are unverified.'},
]

for product in definitions:
    product['image'] = preserve_image(product['source_pdf_page'],product['xref'],PRODUCTS/f'{product["sku"]}.jpg',product.get('crop'))
    product.update({'collection':'NANTES','catalogue_brand':'MARINER','sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023','sourceBrand':'MARINER',
                    'sourcePage':product['source_pdf_page'],'sourcePages':product.get('sourcePages',[product['source_pdf_page']]),
                    'category':product['type'],'rooms':product.get('rooms',[product['room']]),
                    'finish':product.get('finish','NAN. / OF (544/ 55)' if product['room']=='Living room' else 'NAN. /OF (544/55)'),
                    'imageShared':product.get('imageShared',False),
                    'materials':['Oak burl veneer','Sycamore inlays','Cast bronze ornaments']+(['Upholstery with original printed fabric codes recorded separately'] if product.get('fabric_codes') else []),
                    'dimensions_order':'width, depth, height','source_printed_pages':f'{(product["source_pdf_page"]-1)*2}-{(product["source_pdf_page"]-1)*2+1}',
                    'image_classification':'Original catalogue image; not independently verified product photography'})
    product['source_printed_dimensions_cm'] = {'width':product['dimensions_mm'][0]/10,'depth':product['dimensions_mm'][1]/10,'height':product['dimensions_mm'][2]/10}
    source_text = doc[product['source_pdf_page']-1].get_text()
    product['source_product_text_blocks'] = [block[4] for block in doc[product['source_pdf_page']-1].get_text('blocks') if product['sku'] in block[4]]
    if product.get('diameter_mm'):
        product['source_printed_dimensions_cm'].pop('depth')
        product['source_printed_dimensions_cm'].pop('width')
        product['source_printed_dimensions_cm']['diameter'] = product['diameter_mm']/10
    product.pop('xref',None)
    product.pop('crop',None)

supporting = [
 (32,166,'room-living',None,'Living room','Original full living room including pale panelled walls, marble fireplace, crystal chandelier, blue urn lamps, grey rug'),
 (33,169,'original-living-window-left',None,'Living room','Original left-half room window/seating image'),
 (33,170,'original-living-window-right',None,'Living room','Original right-half room window/seating image; complementary full-height city window and striped curtains'),
 (34,175,'original-sofa-rear',None,'Living room','Original continuous curved oak-burl sofa shell and inlay borders'),
 (34,177,'original-armchair-rear',None,'Living room','Original rounded armchair shell/back'),
 (35,183,'original-side-table-lifestyle',None,'Living room','Original side-table detail, lamp, curtains and city window'),
 (98,590,'room-dining',None,'Dining room','Original dining room with grey panel walls, marble floor, plum rug and gold chandelier'),
 (99,597,'original-dining-table-lifestyle',None,'Dining room','Original close-up two-pedestal dining table, table settings and floral centrepiece'),
 (100,601,'original-cabinet-lifestyle',None,'Dining room','Original glazed cabinet and adjacent dining armchair'),
 (101,614,'original-commode-dining',None,'Dining room','Original second published view of commode50361.0'),
 (101,615,'original-console-and-mirror',None,'Dining room','Original console50347.0 and portrait mirror50348.0 lifestyle composition'),
 (122,725,'room-bedroom',None,'Bedroom','Original charcoal panelled bedroom with ornate cream cornice, chandelier, pale marble floor and beige rug'),
 (124,739,'original-dressing-table-mirror-and-stool',None,'Bedroom','Original dressing table50383.0, portrait mirror50348.0 and stool50385.0 lifestyle composition; original PDF soft mask preserved'),
 (35,183,'details/original-oval-lattice-and-collar',[65,505,710,1000],'Living room','Native source close-up of oval-lattice rail, gold collars and solid lower shelf'),
 (122,725,'details/original-headboard',[180,450,675,725],'Bedroom','Native source crop of two-panel diamond-tufted bed headboard'),
]
supporting_images = []
for pdf_page,xref,name,crop,room,description in supporting:
    evidence = preserve_image(pdf_page,xref,DEST/f'{name}.jpg',crop)
    evidence.update({'room':room,'description':description})
    supporting_images.append(evidence)

manifest = {'collection':'NANTES','catalogue_brand':'MARINER','catalogue_title':SOURCE.name,
            'sourceCatalogue':'CLASSIC FURNITURE CATALOG 2023','sourceBrand':'MARINER',
            'source_pdf':str(SOURCE),'source_pdf_sha256':report['source_sha256'],'source_pdf_page_count':len(doc),
            'source_pdf_pages':PAGE_NUMBERS,'dimensions_unit':'millimetres','dimensions_order':'width, depth, height',
            'source_material_statement':'OAK BURL VENEER, SYCAMORE INLAYS & CASTED BRONZE.',
            'source_variant_note':'Three-seat50375.0 and separately dimensioned two-seat50376.0 share the catalogue three-seat front photograph; no isolated two-seat photo exists in the NANTES source pages. This is explicitly disclosed. Commode50361.0 and portrait mirror50348.0 repeat across dining/bedroom sections and are each counted once.',
            'scope_note':'Full NANTES suite: living PDF32-35, dining PDF98-101, bedroom PDF122-124.22 unique product SKUs:6 living,10 dining,6 new bedroom;2 dining products repeat in bedroom. Original lighting, flowers, bedding, tableware, television, rugs and architecture are styling references, not extra product SKUs.',
            'provenance_note':'Source images are exact embedded JPEG bytes, documented native-density rectangular crops, or faithful composites of original JPEGs with their original PDF soft masks over the original white page background. Raw originals, masks, xrefs, pixel sizes, transforms and SHA256 hashes are retained. No AI substitution, super-resolution, new subject segmentation, missing-product synthesis or subject alteration was performed. Original embedded orientation is retained and any source-PDF horizontal mirroring explicitly recorded.',
            'reconstruction_caveat':'Printed dimensions and visibly documented details are source evidence. Hidden joinery, material substrate, exact finish/colour calibration, textile weave, storage internals and opening mechanisms remain interpretative. Source imagery is not independently verified as photography. Original styling is reference for a furnished interior, not a freestanding exhibition.',
            'rights_note':'User-supplied MARINER catalogue; original designs and images remain the rights of their owners. Extraction conveys no commercial reuse licence or manufacturer endorsement.',
            'room_reference_notes':{'Living room':'Pale greige panel-moulded walls, ornate pale marble fireplace, crystal/brass chandelier, tall city windows, ivory curtains with double black bottom bands, blue/gold urn lamps, dark vintage rug.',
                                    'Dining room':'Grey panel-moulded walls, polished pale veined marble floor, plum vintage rug, cream banded curtains, gilt chandelier, broad mirror over sideboard.',
                                    'Bedroom':'Charcoal walls with white rectangular moulding, ornate cream cornice/coffered ceiling, pale veined marble floor, beige/gold vintage rug, black/gold urn lamps and gilt chandelier.'},
            'products':definitions,'supporting_images':supporting_images}
assert len(definitions)==22 and len({p['sku'] for p in definitions})==22
for product in definitions:
    assert all(v>0 for v in product['dimensions_mm'])
    assert product['image']['output_pixels'][0] <= product['image']['source_native_pixels'][0]
    assert product['image']['output_pixels'][1] <= product['image']['source_native_pixels'][1]
(DEST/'products.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf8')
audited = []
for evidence in [p['image'] for p in definitions]+supporting_images:
    path = DEST/evidence['file']
    pixmap = fitz.Pixmap(str(path))
    assert [pixmap.width,pixmap.height] == evidence['output_pixels']
    assert hashlib.sha256(path.read_bytes()).hexdigest() == evidence['sha256']
    original_path = DEST/evidence['source_image_file']
    assert hashlib.sha256(original_path.read_bytes()).hexdigest() == evidence['source_image_sha256']
    if evidence.get('source_soft_mask_file'):
        assert hashlib.sha256((DEST/evidence['source_soft_mask_file']).read_bytes()).hexdigest() == evidence['source_soft_mask_sha256']
    audited.append({'file':evidence['file'],'pixels':evidence['output_pixels'],'bytes':path.stat().st_size,'sha256':evidence['sha256']})
(DEST/'reference-audit.json').write_text(json.dumps({'status':'passed','source_pdf_sha256':report['source_sha256'],'unique_products':len(definitions),'living_unique_products':6,'dining_unique_products':10,'new_bedroom_unique_products':6,'bedroom_shared_with_dining':['50361.0','50348.0'],'original_source_page_previews':PAGE_NUMBERS,'audited_images':audited,'assertions':['All output pixel sizes match decoded image sizes','No source image is upscaled','All output, original and mask SHA256 hashes verified','22 unique source product SKUs']},indent=2),encoding='utf8')
print('PRODUCT_REFERENCES_READY',len(definitions),DEST/'products.json',flush=True)
doc.close()

