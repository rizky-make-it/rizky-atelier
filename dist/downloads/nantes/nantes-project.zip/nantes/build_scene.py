"""NANTES furnished residence: three catalogue-inspired connected interiors.

Native scene retains complete walls and ceilings. Web overview alone uses a
labelled architectural cutaway; room tour restores the complete enclosure.
"""
import bpy,math,sys,json,random,time,hashlib
from pathlib import Path
from mathutils import Vector
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
import core as c
import sofas,casegoods
started=time.perf_counter();random.seed(54455)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.materials();scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='METERS'
scene['collection']='NANTES';scene['layout']='furnished-interior';scene['walls']=True;scene['roof']=True
scene['reference']='MARINER classic catalogue: PDF32-35,98-101,122-124'
c.set_parent(None);staging=c.empty('NANTES | catalogue-inspired residence',props={'kind':'interior-staging','walls':True,'roof':True})
c.set_parent(staging)
H=3.65
colliders=[]
def branch(name,cutaway=False):
    c.set_parent(staging);root=c.empty(name,props={'kind':'architectural-surface','cutaway':cutaway});c.set_parent(root);return root
def panel(name,x,y,z,w,h,plane='back',mat='plaster'):
    pts=[(-w/2,0,-h/2),(w/2,0,-h/2),(w/2,0,h/2),(-w/2,0,h/2)]
    if plane=='left':pts=[(0,a,b) for a,_,b in pts]
    for inset,r in ((0,.009),(.027,.004)):
        q=[]
        for a,b,d in pts:
            if plane=='left':q.append((x,y+b-math.copysign(inset,b),z+d-math.copysign(inset,d)))
            else:q.append((x+a-math.copysign(inset,a),y,z+d-math.copysign(inset,d)))
        c.curve(name,q,r,mat,True)
def cornice(x0,x1,y):
    for z,d,h in ((3.49,.065,.07),(3.55,.10,.055),(3.60,.15,.045)):
        c.box('Layered plaster cornice',(x0+(x1-x0)/2,y,z),(x1-x0,d,h),'plaster',.009)
    for x in [x0+.25+i*.25 for i in range(int((x1-x0-.4)/.25))]:
        c.box('Classical cornice dentil',(x,y-.045,3.485),(.09,.065,.06),'plaster',.006)

# Polished, truly modelled slab joints. No photographed floor is used.
branch('Pale marble floor and slab seams')
for i in range(14):
    for j in range(7):c.box('Honed pale marble slab',(i*1.5+.75,j*1.5+.75,-.066),(1.497,1.497,.13),'stone',.002)

# Exterior back facade, windows, cream curtains and architectural detail.
for room,x0,wallmat,window in [('living',0,'wall',(2.2,5.5)),('dining',7,'wall',(7.65,9.35)),('bedroom',14,'wall_dark',(19.65,20.65))]:
    x1=x0+7;wa,wb=window
    branch(room+' enclosed back wall')
    for a,b in ((x0,wa),(wb,x1)):
        c.box(room+' solid rear plaster wall',((a+b)/2,10.08,H/2),(b-a,.20,H),wallmat,.006)
        if b-a>.7:
            panel('Tall recessed rear wall molding',(a+b)/2,9.965,1.98,b-a-.30,2.5)
    for z,h in ((.28,.56),(3.45,.4)):c.box('Window head/sill wall',((wa+wb)/2,10.08,z),(wb-wa,.2,h),wallmat,.006)
    c.box('White stone window sill',((wa+wb)/2,9.90,.57),(wb-wa+.12,.37,.06),'plaster',.01)
    for x in (wa,wb,(wa+wb)/2):c.box('Window vertical painted frame',(x,9.985,1.99),(.065,.08,2.84),'plaster',.006)
    for z in (.59,3.36):c.box('Window painted horizontal frame',((wa+wb)/2,9.985,z),(wb-wa+.07,.08,.065),'plaster',.005)
    c.box('Daylight window glass',((wa+wb)/2,10.02,1.98),(wb-wa-.02,.009,2.75),'window',0)
    cornice(x0,x1,9.91)
    for z,w,h in ((.09,.085,.18),(.84,.045,.025),(.89,.035,.02)):
        for a,b in ((x0,wa),(wb,x1)):c.box('Wainscot and skirting',((a+b)/2,9.94,z),(b-a,w,h),'plaster',.005)
    # Native pleated curtain geometry, with the characteristic dark bands.
    for edge in (wa-.05,wb+.05):
        width=.52 if room!='bedroom' else .35
        verts=[];faces=[];N=90
        for j,z in enumerate((.04,.18,.27,.40,.48,3.34)):
            for i in range(N+1):
                t=i/N;verts.append((edge+(t-.5)*width,9.79+.05*math.cos(t*math.tau*7),z))
        for j in range(5):
            for i in range(N):a=j*(N+1)+i;faces.append((a,a+1,a+N+2,a+N+1))
        ob=c.mesh('Full-length pleated cream curtain',verts,faces,'curtain',smooth=True)
        ob.data.materials.append(c.M['curtain_dark'])
        for p in ob.data.polygons:
            if p.index//N in (1,3):p.material_index=1
        c.rod('Curtain brass rail',(edge-width/2-.10,9.76,3.36),(edge+width/2+.10,9.76,3.36),.012,'brass')
    c.set_parent(None)
    c.light(room+' daylight through actual window','AREA',((wa+wb)/2,9.72,2.35),700,(.82,.89,1),target=(x0+3.5,5.5,.7),size=2.6)
    c.set_parent(staging)

# Connected rooms; each partition has a real 1.6m clear doorway, not a wall
# hidden for the walking tour. Door jambs and lintels remain physical solids.
for x,mat in ((0,'wall'),(7,'wall'),(14,'wall_dark'),(21,'wall_dark')):
    branch('Side and partition enclosure '+str(x),True)
    spans=[(0,10)] if x in (0,21) else [(0,1.2),(2.8,10)]
    for a,b in spans:
        c.box('Solid room partition',(x,(a+b)/2,H/2),(.18,b-a,H),mat,.005);colliders.append([x-.10,a,x+.10,b])
        for side in (-1,1):
            sx=x+side*.104
            c.box('Partition skirting',(sx,(a+b)/2,.09),(.045,b-a,.18),'plaster',.005)
            c.box('Partition upper cornice',(sx,(a+b)/2,3.54),(.15,b-a,.13),'plaster',.006)
            if b-a>2:
                for cy in [a+1+i*1.65 for i in range(int((b-a-.4)/1.65))]:panel('Side wall raised plaster panel',sx,cy,1.98,1.35,2.45,'left')
    if x not in (0,21):
        c.box('Doorway lintel',(x,2,3.2),(.18,1.6,.9),mat,.004)
        for y in (1.17,2.83):c.box('Doorway painted jamb',(x,y,1.38),(.24,.075,2.76),'plaster',.006)
        c.box('Doorway architrave',(x,2,2.80),(.26,1.75,.12),'plaster',.007)
        colliders.append([x-.10,0,x+.10,1.2]);colliders.append([x-.10,2.8,x+.10,10])

branch('Complete front facade',True)
for x0,mat in ((0,'wall'),(7,'wall'),(14,'wall_dark')):
    c.box('Enclosed front plaster wall',(x0+3.5,-.08,H/2),(7,.2,H),mat,.005)
    for x in (x0+1.3,x0+3.5,x0+5.7):panel('Front panel molding',x,.032,2,1.7,2.5)
    cornice(x0,x0+7,.06)
    c.box('Front skirting',(x0+3.5,.04,.09),(7,.08,.18),'plaster',.005)

branch('Complete plaster ceiling with coffer and rose',True)
for x0 in (0,7,14):
    c.box('Full plaster ceiling',(x0+3.5,5,3.72),(7,10,.16),'plaster',.01)
    for x in (x0+.35,x0+6.65):c.box('Ceiling inset perimeter',(x,5,3.61),(.08,9.3,.065),'white',.008)
    for y in (.35,9.65):c.box('Ceiling inset perimeter',(x0+3.5,y,3.61),(6.3,.08,.065),'white',.008)
    for r in (.28,.37,.43):c.curve('Chandelier ceiling rose',[(x0+3.5+math.cos(a)*r,6.5+math.sin(a)*r,3.60) for a in [i*math.tau/64 for i in range(64)]],.018,'plaster',True)
c.set_parent(staging)

# A stylised distant architectural skyline, outside the windows. The exact
# reference city background is not claimed to have been reconstructed.
branch('Distant interpreted skyline')
c.box('Soft daylight background',(10.5,12.9,3.6),(24,.08,8),'sky',0)
cityv=[];cityf=[]
for i in range(35):
    x=-1+i*.68;height=.8+random.random()*2.2
    c.box('Distant city building',(x,12.2,height/2),(.40+random.random()*.22,.35,height),'city',.006)
    if i%4==0:c.box('Distant stepped tower crown',(x,12.2,height+.08),(.25,.25,.16),'city',.004)
    for row in range(int(height/.14)):
        for col in range(3):
            wx=x-.15+col*.115;z=.04+row*.14;a=len(cityv)
            cityv.extend([(wx,12.016,z),(wx+.079,12.016,z),(wx+.079,12.016,z+.099),(wx,12.016,z+.099)]);cityf.append((a,a+1,a+2,a+3))
c.mesh('Distant facade window grid',cityv,cityf,'cityglass')

def rug(name,x,y,w,d,mat='rug'):
    c.set_parent(staging);c.box(name,(x,y,.013),(w,d,.025),mat,.012)
    for inset in (.04,.08,.13):c.curve('Woven rug border',[(x-w/2+inset,y-d/2+inset,.028),(x+w/2-inset,y-d/2+inset,.028),(x+w/2-inset,y+d/2-inset,.028),(x-w/2+inset,y+d/2-inset,.028)],.002,'cloth_gold',True)
    # Tiny fringes remain genuine physical strands.
    for sx in (-1,1):
        for j in range(int(d/.025)):c.curve('Hand-knotted carpet fringe',[(x+sx*w/2,y-d/2+.025*j,.016),(x+sx*(w/2+.04),y-d/2+.025*j+.004,.008)],.0011,'ivory')
rug('Dark vintage salon rug',3.5,7.0,5.8,4.8)
rug('Muted plum dining rug',10.5,6.5,5.3,4.1,'plum_rug')
rug('Warm gold bedroom rug',17.5,7.35,5.1,4.3)

placements=[]
def place(sku,room,position,rotation=0):
    c.set_parent(None);module=sofas if sku in sofas.SPECS else casegoods
    root=module.create(sku,instance=room+'-'+str(len(placements)+1));root.location=position;root.rotation_euler.z=math.radians(rotation);root['room']=room
    placements.append({'sku':sku,'room':room,'position':list(position),'rotation':rotation,'instance':root['instance_id']});c.set_parent(staging);return root

# Living composition follows the large window/sofa/paired urn-lamp photograph.
place('50375.0','living',(3.5,8.9,.028));place('50379.0','living',(1.8,8.9,0));place('50379.0','living',(5.2,8.9,0))
place('50377.0','living',(1.38,6.25,.028),55);place('50377.0','living',(5.62,6.25,.028),-55)
place('50378.0','living',(3.5,6.9,.028));place('50376.0','living',(.65,3.95,0),90)
place('50380.0','living',(3.5,.42,0),180)
# Dining has the full sideboard/mirror composition and distinct table variants.
place('50339.0','dining',(10.5,6.5,.028))
for x in (9.7,10.5,11.3):
    place('50344.0','dining',(x,5.48,.028),180);place('50344.0','dining',(x,7.52,.028))
place('50345.0','dining',(8.8,6.5,.028),90);place('50345.0','dining',(12.2,6.5,.028),-90)
place('50341.0','dining',(11.2,9.57,0));place('50342.0','dining',(11.2,9.88,1.16))
place('50343.0','dining',(13.61,8.20,0),-90)
place('50340.0','dining',(10.5,3.0,0));place('50344.0','dining',(9.25,3.0,0),90);place('50344.0','dining',(11.75,3.0,0),-90)
place('50347.0','dining',(7.40,4.25,0),90);place('50348.0','dining',(7.12,4.25,1.06),90)
place('50361.0','dining',(12.5,.4,0),180)
# Bedroom: central tufted bed, paired THREEdrawer bedsides, bench and FIVEdrawer chest.
place('50381.0','bedroom',(17.5,8.45,.028));place('50382.0','bedroom',(15.84,9.03,0));place('50382.0','bedroom',(19.16,9.03,0))
place('50384.0','bedroom',(17.5,6.65,.028));place('50386.0','bedroom',(20.53,7.6,0),-90)
place('50383.0','bedroom',(17.5,.38,0),180);place('50348.0','bedroom',(17.5,.12,1.0),180);place('50385.0','bedroom',(17.5,1.2,0),180)
place('50361.0','bedroom',(14.43,5.4,0),90)

# Soft knitted throw falling over the reference bench. This is removable
# styling, independent of the dimensioned manufacturer furniture root.
c.set_parent(staging);throw=c.empty('Removable draped bench throw',props={'kind':'styling'});c.set_parent(throw)
tv=[];tf=[];tu=[];NX=55;NY=75
for j in range(NY+1):
    v=j/NY;y=6.89-1.03*v
    for i in range(NX+1):
        u=i/NX;x=16.77+.73*u+.035*math.sin(v*5+u*3)
        fall=max(0,(v-.48)/.52)
        z=.575-.48*(fall**.65)+.027*math.sin(u*math.tau*5+v*5)+.010*math.sin(u*43-v*24)
        tv.append((x,y,z));tu.append((u,v))
for j in range(NY):
    for i in range(NX):q=j*(NX+1)+i;tf.append((q,q+1,q+NX+2,q+NX+1))
cloth=c.mesh('Folded charcoal wool with actual drape',tv,tf,'cloth_dark',tu,True)
solid=cloth.modifiers.new('Knitted throw thickness','SOLIDIFY');solid.thickness=.003
for row in (0,NY):c.curve('Throw sewn end binding',tv[row*(NX+1):(row+1)*(NX+1)],.0025,'stitch')
c.set_parent(staging)

def lamp(x,y,z,blue=True):
    c.set_parent(staging)
    c.lathe('Classical urn lamp gilded foot',(x,y,z),[(0,0),(.12,0),(.12,.025),(.09,.05),(.07,.075),(.07,.10),(.035,.14)],'gold',40)
    c.lathe('Classical fluted porcelain lamp urn',(x,y,z+.14),[(.035,0),(.055,.02),(.085,.30),(.10,.33),(.065,.38),(.045,.41),(.06,.43)],'ceramic' if blue else 'piano',48)
    for i in range(16):
        a=i*math.tau/16;c.curve('Gilt urn fluting',[(x+math.cos(a)*(.045+.035*t),y+math.sin(a)*(.045+.035*t),z+.16+t*.30) for t in [j/9 for j in range(10)]],.0015,'brass')
    c.lathe('Gilt lamp collar',(x,y,z+.54),[(.045,0),(.075,.01),(.075,.03),(.04,.05)],'gold',40)
    verts=[];faces=[];N=128
    for r,h in ((.25,.58),(.15,.91)):
        for i in range(N):
            a=i*math.tau/N;rad=r+(.008 if i%2 else -.008);verts.append((x+rad*math.cos(a),y+rad*math.sin(a),z+h))
    for i in range(N):j=(i+1)%N;faces.append((i,j,N+j,N+i))
    c.mesh('Pleated ivory lampshade',verts,faces,'curtain')
    for r,h in ((.25,.58),(.15,.91)):c.curve('Shade dark piping',[(x+r*math.cos(a),y+r*math.sin(a),z+h) for a in [i*math.tau/64 for i in range(64)]],.0023,'piano',True)
    c.set_parent(None);c.light('Warm shaded urn light','POINT',(x,y,z+.72),48,(1,.72,.43));c.set_parent(staging)
for p in [(1.8,8.9,.65),(5.2,8.9,.65),(15.84,9.03,.79),(19.16,9.03,.79),(10.45,9.55,.99)]:lamp(*p,blue=p[0]<7)

def chandelier(x,y):
    c.set_parent(staging)
    c.rod('Chandelier suspension',(x,y,3.58),(x,y,2.81),.014,'gold')
    c.lathe('Sculpted chandelier central vase',(x,y,2.52),[(0,0),(.08,.03),(.12,.12),(.065,.22),(.04,.30),(.075,.35)],'gold',48)
    for i in range(8):
        a=i*math.tau/8;rad=.58;ex=x+math.cos(a)*rad;ey=y+math.sin(a)*rad
        c.curve('Curved chandelier bronze arm',[(x+math.cos(a)*r,y+math.sin(a)*r,2.64+.25*(2*t-1)**2) for t,r in [(j/24,.09+j/24*(rad-.09)) for j in range(25)]],.011,'gold')
        c.lathe('Chandelier candle cup',(ex,ey,2.84),[(0,0),(.065,0),(.073,.018),(.045,.045),(.035,.055)],'gold',24)
        c.cylinder('Ivory candle sleeve',(ex,ey,2.99),.018,.23,'ivory');c.sphere('Glowing candle bulb',(ex,ey,3.13),(.024,.024,.047),'light',16,8)
        for j in range(5):
            b=a+(j-2)*.12;px=x+math.cos(b)*.43;py=y+math.sin(b)*.43;z=2.64-abs(j-2)*.018
            c.curve('Crystal bead swag',[(px,py,z),(ex,ey,2.88)],.002,'brass')
            c.sphere('Faceted chandelier crystal',(px,py,z-.07),(.017,.017,.07),'glass',8,4)
    c.set_parent(None);c.light('Warm chandelier pool','POINT',(x,y,2.68),125,(1,.82,.58));c.set_parent(staging)
for x in (3.5,10.5,17.5):chandelier(x,6.5)

def flowers(x,y,z):
    c.set_parent(staging)
    c.lathe('Clear floral vase',(x,y,z),[(0,0),(.09,0),(.10,.02),(.08,.19),(.075,.23),(.07,.23),(.07,.20)],'glass',32)
    for i in range(17):
        a=i*2.4;px=x+math.cos(a)*(.08+.009*i);py=y+math.sin(a)*(.08+.009*i);h=.35+random.random()*.15
        c.rod('Real stem',(x,y,z+.08),(px,py,z+h),.0016,'leaf')
        for j in range(5):
            b=j*math.tau/5;c.sphere('Sculpted ivory rose petal',(px+.018*math.cos(b),py+.018*math.sin(b),z+h),(.025,.017,.014),'ivory',12,6)
        leaf=c.sphere('Flower leaf',((x+px)/2+.03,(y+py)/2,z+h*.65),(.065,.022,.004),'leaf',12,6);leaf.rotation_euler=(.2,.4,a)
flowers(10.5,6.5,.788);flowers(12.0,9.5,.99);flowers(20.53,7.6,1.34)

def glassware(x,y,z):
    c.lathe('Wine glass foot',(x,y,z),[(0,0),(.032,0),(.036,.004),(.008,.009),(.005,.012),(.005,.085),(.008,.09)],'glass',24)
    c.lathe('Thin wine glass bowl',(x,y,z+.09),[(.006,0),(.034,.027),(.041,.065),(.035,.105),(.033,.105),(.038,.064),(.030,.03),(.006,.005)],'glass',32)
for x in (9.7,10.5,11.3):
    for y in (6.0,7.0):
        c.lathe('Porcelain dinner plate',(x,y,.79),[(0,0),(.12,0),(.14,.006),(.145,.012),(.13,.018),(.11,.008),(0,.008)],'ivory',40)
        c.curve('Fine gilt plate rim',[(x+.138*math.cos(a),y+.138*math.sin(a),.805) for a in [i*math.tau/48 for i in range(48)]],.0012,'gold',True)
        glassware(x+.19,y,.79)
        c.rod('Silver table knife',(x+.18,y-.10,.805),(x+.18,y+.08,.805),.003,'mirror')

# Reference fireplace and wall art: authored staging, not additional SKUs.
c.set_parent(staging)
fire=c.empty('Interpreted white classical fireplace',props={'kind':'styling'});c.set_parent(fire)
c.box('Fireplace black firebox',(.18,7.5,.45),(.08,1.20,.85),'piano',.01)
for y in (6.78,8.22):c.box('Carved fireplace jamb',(.29,y,.49),(.48,.19,.98),'plaster',.012)
c.box('Classical fireplace mantel',(.32,7.5,1.02),(.64,1.72,.12),'plaster',.014)
c.box('Fireplace hearth',(.37,7.5,.04),(.74,1.75,.08),'stone',.008)
for y in (7.2,7.45,7.7):
    c.rod('Fireplace log',(.30,y,.17),(.19,y+.25,.15),.048,'wood_dark')
    c.sphere('Soft interpreted flame',(.24,y,.28),(.025,.06,.15),'fire',16,8)
c.set_parent(None);c.light('Fireplace glow','POINT',(.5,7.5,.32),25,(1,.35,.06));c.set_parent(staging)
# Abstract painting to the left of the salon window, avoiding logos/text.
c.box('Abstract artwork black frame',(1.05,9.91,2.05),(.86,.055,1.10),'piano',.009)
c.box('Abstract artwork warm ground',(1.05,9.875,2.05),(.77,.008,1.01),'cloth_gold',.001)
for i in range(9):
    a0=.15+i*.03;c.curve('Authored abstract circular brushstroke',[(1.05+(.23+i*.006)*math.cos(a),9.865,2.05+(.33+i*.003)*math.sin(a)) for a in [a0+j*4.6/58 for j in range(59)]],.007,'piano')

c.set_parent(None)
world=bpy.data.worlds.new('NANTES soft exterior daylight');scene.world=world;world.use_nodes=True
world.node_tree.nodes['Background'].inputs['Color'].default_value=(.68,.75,.82,1);world.node_tree.nodes['Background'].inputs['Strength'].default_value=.28
for x in (3.5,10.5,17.5):
    c.light('Large soft interior bounce','AREA',(x,4.1,3.35),460,(1,.91,.78),target=(x,7.5,.7),size=4)
    c.light('Soft front camera fill','AREA',(x,1.0,2.7),300,(.91,.95,1),target=(x,6.5,1),size=4)
sun=c.light('Afternoon exterior daylight','SUN',(-4,13,10),1.0,(1,.94,.84),target=(7,3,0));sun.data.angle=.12

cameras={
 'living':((3.5,5.0,1.60),(3.5,8.8,1.05),28),
 'living-wide':((6.3,3.05,1.80),(3.4,7.25,1.05),30),
 'dining':((8.1,3.30,1.78),(10.8,7.3,1.00),29),
 'dining-round':((12.8,1.3,1.72),(10.3,4.1,.80),33),
 'bedroom':((20.35,4.4,1.72),(17.6,8.55,1.02),31),
 'bedroom-front':((17.5,4.25,1.62),(17.5,8.65,1.0),31),
 'vanity':((19.2,3.8,1.55),(17.5,.4,.9),37),
 'detail-burl':((5.85,8.0,.89),(5.18,8.65,.59),65),
 'detail-upholstery':((4.8,7.75,1.03),(4.33,8.6,.65),70),
 'detail-tufting':((18.4,7.30,1.75),(17.9,9.3,1.18),65),
}
for key,(loc,target,lens) in cameras.items():
    data=bpy.data.cameras.new('Lens '+key);obj=bpy.data.objects.new('Camera '+key,data);scene.collection.objects.link(obj);obj.location=loc;obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler();data.lens=lens;data.clip_start=.025;data.clip_end=120
    if key.startswith('detail'):data.dof.use_dof=True;data.dof.focus_distance=(Vector(target)-Vector(loc)).length;data.dof.aperture_fstop=7.1
scene.camera=bpy.data.objects['Camera living'];scene.render.engine='CYCLES';scene.cycles.samples=128;scene.cycles.use_denoising=True
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8';scene.render.image_settings.compression=25
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.render.film_transparent=False
zones={
 'living':{'name':'The window salon','bounds':[.2,.2,6.8,9.8],'camera':[[3.9,3.9,1.65],[3.5,8.25,1.0],55]},
 'dining':{'name':'The marble dining room','bounds':[7.2,.2,13.8,9.8],'camera':[[8.1,3.3,1.65],[10.8,7.3,1.0],55]},
 'bedroom':{'name':'The charcoal bedroom','bounds':[14.2,.2,20.8,9.8],'camera':[[20.35,4.4,1.65],[17.6,8.55,1.0],55]},
 'round':{'name':'The round dining setting','camera':[[12.8,1.3,1.65],[10.3,4.1,.80],55]},
 'vanity':{'name':'The dressing corner','camera':[[19.2,3.8,1.65],[17.5,.4,.9],55]},
}
info={'collection':'NANTES','units':'metres','layout':'furnished-interior','walls':True,'roof':True,'defaultRoom':'living','overviewCutaway':True,'guideTransitionY':2.0,'floorBounds':[.2,.2,20.8,9.8],'rooms':zones,'placements':placements,'colliders':colliders,
 'overview':{'position':[26,18,23],'target':[10.5,1,-5],'fov':45},'source':'CLASSIC_FURNITURE_CATALOG_2023.pdf','sourcePages':[32,33,34,35,98,99,100,101,122,123,124],'finish':'NAN. / OF (544/55)',
 'interpretations':['Connected floor plan links independent catalogue compositions; it is not a measured source building','Complete room shell is retained; only architectural overview removes marked walls and ceilings','Reference-inspired lamps, chandelier, fireplace, curtains, artwork, flowers, skyline and table styling are not additional manufacturer SKUs','Unseen joinery and exact fabric motif/finish calibration are interpretations','Two-seat sofa proportions follow printed dimensions; its source image is shared with three-seat','Fixed cabinetry: source does not establish functional opening hardware']}
scene['web_scene_info']=json.dumps(info);(BASE/'scene.json').write_text(json.dumps(info,indent=2),encoding='utf8')
scene['rebuild_source_sha256']=json.dumps({name:hashlib.sha256((BASE/name).read_bytes()).hexdigest() for name in ('core.py','geometry.py','sofas.py','casegoods.py','build_scene.py')})
for mat in bpy.data.materials:mat.use_fake_user=True
for im in bpy.data.images:
    if im.source=='FILE':im.use_fake_user=True
bpy.ops.file.pack_all()
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.region_3d.view_camera_zoom=0;area.spaces.active.shading.type='MATERIAL'
report={'collection':'NANTES','products':len(set(p['sku'] for p in placements)),'placements':len(placements),'movingParts':0,'objects':len(scene.objects),'meshes':sum(o.type=='MESH' for o in scene.objects),'walls':True,'roof':True,'layout':'furnished-interior','seconds':round(time.perf_counter()-started,2)}
(BASE/'build-report.json').write_text(json.dumps(report,indent=2))
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'nantes-interior.blend'),compress=True)
print('NANTES_BUILD_COMPLETE',json.dumps(report),flush=True)
