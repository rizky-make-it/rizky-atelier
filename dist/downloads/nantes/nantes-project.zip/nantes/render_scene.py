"""Genuine Blender renders: -- [all|camera] [--preview] [--cycles]."""
import bpy,sys,time,json
from pathlib import Path
BASE=Path(__file__).resolve().parent;args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else ['all']
name=args[0] if args else 'all';preview='--preview' in args;scene=bpy.context.scene
assert scene.get('collection')=='NANTES'
scene.timeline_markers.clear();scene.render.engine='CYCLES' if '--use-cycles' in args else 'BLENDER_EEVEE'
scene.cycles.samples=24 if preview else 96;scene.eevee.taa_render_samples=16 if preview else 64
scene.render.resolution_x=3840;scene.render.resolution_y=2160;scene.render.resolution_percentage=25 if preview else 100
scene.eevee.use_raytracing=True
scene.eevee.shadow_pool_size='1024'
scene.eevee.shadow_resolution_scale=.75
out=BASE/'renders';out.mkdir(exist_ok=True)
for key in (['living','living-wide','dining','dining-round','bedroom','bedroom-front','vanity','detail-burl','detail-upholstery','detail-tufting'] if name=='all' else [name]):
    started=time.perf_counter();scene.camera=bpy.data.objects['Camera '+key]
    hidden=[]
    # Unseen rooms do not contribute direct illumination through solid walls.
    # Keeping their shadow atlases allocated at4K exhausts the EEVEE pool.
    # Isolate light calculation only; all architecture/product geometry stays.
    x0=14 if key.startswith('bedroom') or key in ('vanity','detail-tufting') else 7 if key.startswith('dining') else 0
    for obj in scene.objects:
        if obj.type=='LIGHT' and obj.data.type!='SUN' and not x0<=obj.location.x<x0+7:
            hidden.append((obj,obj.hide_render));obj.hide_render=True
    scene.render.resolution_x=1600 if key.startswith('detail') else 3840
    scene.render.resolution_y=1600 if key.startswith('detail') else 2160
    filename=key+('-preview.png' if preview else '.png' if key.startswith('detail') else '-4k.png')
    scene.render.filepath=str(out/filename);bpy.ops.render.render(write_still=True)
    report={'camera':key,'collection':'NANTES','engine':scene.render.engine,'samples':scene.cycles.samples if scene.render.engine=='CYCLES' else scene.eevee.taa_render_samples,'shadowPoolMB':1024,'shadowResolutionScale':.75,'width':round(scene.render.resolution_x*scene.render.resolution_percentage/100),'height':round(scene.render.resolution_y*scene.render.resolution_percentage/100),'seconds':round(time.perf_counter()-started,2),'walls':True,'roof':True,'originalBlenderRender':True}
    (out/(key+('-preview' if preview else '')+'-settings.json')).write_text(json.dumps(report,indent=2))
    for obj,state in hidden:obj.hide_render=state
    print('NANTES_RENDER_COMPLETE',json.dumps(report),flush=True)
