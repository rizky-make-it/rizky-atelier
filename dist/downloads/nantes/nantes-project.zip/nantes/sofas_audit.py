"""Native Blender audit and independent contact sheet for eight Nantes SKUs."""
import json,sys,math
from pathlib import Path
import bpy
from mathutils import Vector
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE))
import core as c
import sofas

bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
c.set_parent(None);c.materials()
result=[]
for i,(sku,spec) in enumerate(sofas.SPECS.items()):
    root=sofas.create(sku,'audit')
    bpy.context.view_layer.update();graph=bpy.context.evaluated_depsgraph_get();inv=root.matrix_world.inverted();points=[];triangles=0;objects=0
    for ob in root.children_recursive:
        if ob.type!='MESH':continue
        ev=ob.evaluated_get(graph);points.extend(inv@ev.matrix_world@v.co for v in ev.data.vertices)
        ev.data.calc_loop_triangles();triangles+=len(ev.data.loop_triangles);objects+=1
    lo=[min(p[k] for p in points) for k in range(3)];hi=[max(p[k] for p in points) for k in range(3)]
    dims=[hi[k]-lo[k] for k in range(3)];delta=[abs(dims[k]-spec[k])*1000 for k in range(3)]
    assert max(delta)<3,(sku,dims,delta)
    result.append({'sku':sku,'dimensions_m':dims,'error_mm':delta,'min':lo,'max':hi,'triangles':triangles,'mesh_objects':objects,'normalization_scale':list(root['normalization_scale'])})
    root.location=((i%4-1.5)*3.5,(i//4-.5)*4.1,0)
    c.set_parent(None)
    text=bpy.data.curves.new('Audit label','FONT');text.body=sku;text.size=.20
    ob=bpy.data.objects.new('Audit label '+sku,text);bpy.context.scene.collection.objects.link(ob);ob.location=(root.location.x-1.0,root.location.y-1.40,.002)
    text.materials.append(c.M['piano'])

(BASE/'sofas-audit.json').write_text(json.dumps({'products':result,'total_triangles':sum(x['triangles'] for x in result),'passed':True},indent=2),encoding='utf-8')
print('NANTES_UPHOLSTERY_AUDIT',json.dumps(result))
c.box('Contact sheet ground',(0,0,-.055),(24,17,.1),'stone',0)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=20
scene.cycles.use_denoising=True
scene.render.threads_mode='FIXED';scene.render.threads=4
scene.world.color=(.20,.20,.20)
c.light('Large frontal key','AREA',(2,-7,10),2500,(1,.91,.79),target=(0,0,.7),size=9)
c.light('Large left fill','AREA',(-8,0,7),1500,(.80,.88,1),target=(0,0,.7),size=7)
c.light('Back rim','AREA',(0,7,7),2200,(1,.92,.81),target=(0,0,.7),size=7)
camdata=bpy.data.cameras.new('Upholstery audit overview');cam=bpy.data.objects.new('Upholstery audit overview',camdata);scene.collection.objects.link(cam)
cam.location=(7,-15,14);cam.rotation_euler=(Vector((0,0,.45))-cam.location).to_track_quat('-Z','Y').to_euler();camdata.type='ORTHO';camdata.ortho_scale=16.5
scene.camera=cam;scene.render.resolution_x=2400;scene.render.resolution_y=1500;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.render.image_settings.file_format='PNG';scene.render.filepath=str(BASE/'sofas-preview.png')
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'sofas-audit.blend'))
bpy.ops.render.render(write_still=True)
